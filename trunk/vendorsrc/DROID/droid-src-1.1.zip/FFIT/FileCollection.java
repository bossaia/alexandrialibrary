/*
 * � The National Archives 2005-2006.  All rights reserved.
 * See Licence.txt for full licence details.
 *
 * Developed by:
 * Tessella Support Services plc
 * 3 Vineyard Chambers
 * Abingdon, OX14 3PX
 * United Kingdom
 * http://www.tessella.com
 *
 * Tessella/NPD/4305
 * PRONOM 4
 *
 * $Id: FileCollection.java,v 1.7 2006/03/13 15:15:25 linb Exp $
 * 
 * $Log: FileCollection.java,v $
 * Revision 1.7  2006/03/13 15:15:25  linb
 * Changed copyright holder from Crown Copyright to The National Archives.
 * Added reference to licence.txt
 * Changed dates to 2005-2006
 *
 * Revision 1.6  2006/02/09 13:17:41  linb
 * Changed StreamByteReader to InputStreamByteReader
 * Refactored common code from UrlByteReader and InputStreamByteReader into new class StreamByteReader, from which they both inherit
 * Updated javadoc
 *
 * Revision 1.5  2006/02/08 11:42:24  linb
 * - make saveConfiguration throw an IOException
 *
 * Revision 1.4  2006/02/08 08:56:35  linb
 * - Added header comments
 *
 *
 * *$History: FileCollection.java $
 *
 * *****************  Version 13  *****************
 * User: Walm         Date: 6/06/05    Time: 17:04
 * Updated in $/PRONOM4/FFIT_SOURCE
 * remove a print to system.out line
 *
 * *****************  Version 12  *****************
 * User: Walm         Date: 6/06/05    Time: 10:11
 * Updated in $/PRONOM4/FFIT_SOURCE
 * JIRA: PRON-16: do not allow empty CD drive to be added as if it were a
 * file
 *
 * *****************  Version 11  *****************
 * User: Walm         Date: 3/06/05    Time: 18:12
 * Updated in $/PRONOM4/FFIT_SOURCE
 * deal with errors cleanly in addFile method
 * In particular cope with folders for which user does not have read
 * permission
 *
 * *****************  Version 10  *****************
 * User: Mals         Date: 19/04/05   Time: 9:42
 * Updated in $/PRONOM4/FFIT_SOURCE
 * Looks for attribute "DROIDVersion" instead of "FFITVersion"
 *
 * *****************  Version 9  *****************
 * User: Walm         Date: 29/03/05   Time: 12:05
 * Updated in $/PRONOM4/FFIT_SOURCE
 * Display warning if the file collection file that is read was generated
 * with a different FFIT version a different signature file version to
 * those for the current application
 *
 * *****************  Version 8  *****************
 * User: Walm         Date: 29/03/05   Time: 11:07
 * Updated in $/PRONOM4/FFIT_SOURCE
 * Read in results from a hit collection file
 *
 * *****************  Version 7  *****************
 * User: Walm         Date: 24/03/05   Time: 11:17
 * Updated in $/PRONOM4/FFIT_SOURCE
 * no need to check for whether a file exists at time of adding
 *
 * *****************  Version 6  *****************
 * User: Mals         Date: 15/03/05   Time: 15:13
 * Updated in $/PRONOM4/FFIT_SOURCE
 * Add remove file using index method
 *
 * *****************  Version 5  *****************
 * User: Mals         Date: 11/03/05   Time: 17:12
 * Updated in $/PRONOM4/FFIT_SOURCE
 *
 * *****************  Version 4  *****************
 * User: Mals         Date: 11/03/05   Time: 15:06
 * Updated in $/PRONOM4/FFIT_SOURCE
 * Change to hold IdentificationFile objects instead of strings
 */

package FFIT;

import FFIT.binFileReader.InputStreamByteReader;
import FFIT.binFileReader.UrlByteReader;
import java.util.*;
import FFIT.xmlReader.SimpleElement;

/**
 * Class to hold configuration data for the FFIT.
 * Elements of this collection are IdentificationFile objects.
 * This data is read from and saved to an XML configuration file.
 *
 * @author  Martin Waller
 * @version 1.0.0
 */
public class FileCollection extends SimpleElement {
    
    /** file path to store file list */
    private String myFileName ;
    /** Holds IdentificationFile objects */
    private List myFiles;
    
    /** Signature file version for a file that is read in -
     * only used to check it is the same as currently loaded */
    private int mySigFileVersion = 0;
    
    /**
     *Creates a FileCollection object
     */
    public FileCollection(){
        myFileName = AnalysisController.FILE_LIST_FILE_NAME;
        myFiles = new ArrayList();
    }
    
    /**
     *  Specify the file path for where to store the file list
     *  @param  theFileName     path of where to save the file
     */
    public void setFileName(String theFileName) {
        myFileName = theFileName;
    }
    
    /**
     *  Adds an element/elements to the collection
     *  If filepath is a path to file then add that file
     *  If filepath is a folder path then add contents of the folder
     *
     *  @param  theFile     Filepath of file or folder
     *  @param  isRecursive if true add all subfolders and subsubfolders , etc
     */
    public void addFile(String theFile, boolean isRecursive) {
        
        if (UrlByteReader.isURL(theFile)) {
            if (!this.isDuplicate(theFile)){
                //File object is a URL: add if it isn't a duplicate
                myFiles.add(new IdentificationFile(theFile));
            }
            return;
        }
        
        if (InputStreamByteReader.isInputStream(theFile)) {
            if (!this.isDuplicate(theFile)) {
                // File is a the input stram: add if it isn't a duplicate
                myFiles.add(new IdentificationFile(theFile));
            }
        }
        
        try {
            java.io.File f = new java.io.File(theFile) ;
            
            //Is file object a directory or file?
            if (f.isDirectory()){
                
                //File object is a directory/folder
                //Iterate through directory ,create IdentificationFile objects
                //and add them to the collection
                java.io.File[] folderFiles = f.listFiles() ;
                int numFiles = 0;
                try {
                    numFiles = folderFiles.length;
                }catch(Exception e) {
                    messageDisplay.generalWarning("Unable to read directory "+theFile+"\nThis may be because you do not have the correct permissions.");
                }
                for (int m=0 ; m<numFiles ; m++ ){
                    if (folderFiles[m].isFile() ) {
                        //If file exists and not duplicate then add
                        if(!this.isDuplicate(folderFiles[m].getPath())) {
                            IdentificationFile idFile = new IdentificationFile(folderFiles[m].getPath());
                            myFiles.add(idFile ) ;
                        }
                        
                    }else if (folderFiles[m].isDirectory() && isRecursive){
                        //If subdirectory found and recursive is on add contents of that folder
                        addFile(folderFiles[m].getPath() , isRecursive ) ;
                    }
                }
                
            } else if (f.isFile()) {
                if (!this.isDuplicate(f.getPath())){
                    //File object is a File then add file if it isn't a duplicate
                    IdentificationFile idFile = new IdentificationFile(f.getPath());
                    myFiles.add(idFile ) ;
                }
            }
            
        } catch(Exception e) {
            messageDisplay.generalWarning("The following error occured while adding "+theFile+":\n"+e.toString());
        }
        
    }
    
    
    /**
     *Checks whether the file already exists in file collection
     *@param theFileName Full file name of file
     */
    private boolean isDuplicate(String theFileName) {
        for(int i=0; i<myFiles.size(); i++) {
            if(this.getFile(i).getFilePath().equalsIgnoreCase(theFileName)) {
                return true;
            }
        }
        return false;
    }
    
    
    /**
     *  Add a single file or folder to the collection
     *  @param  theFile path to file or folder
     */
    public void setFile(String theFile) {
        this.addFile(theFile, false);
    }
    
    
    /**
     *Remove file from the file list
     *@param theFileName Full file name of file to remove
     */
    public void removeFile(String theFileName){
        for(int i=0; i<this.getNumFiles(); i++) {
            if(this.getFile(i).getFilePath().equals(theFileName)) {
                this.removeFile(i);
            }
        }
    }
    
    /**
     *Remove file from the file list
     *@param theFileIndex Index of file to remove
     */
    public void removeFile(int theFileIndex) {
        if(theFileIndex<myFiles.size()) {
            myFiles.remove(theFileIndex);
        }
    }
    
    /**
     * Empty file list
     */
    public void removeAll() {
        myFiles.clear();
    }
    
    /**
     *  Gets the file name where file list stored
     *  @return file name where file list stored
     */
    public String getFileName() { return myFileName; }
    /**
     *  Gets the IdentificationFile object by position in collection
     *  @param theIndex position of element in collection
     *  @return Specified IdentificationFile object
     */
    public IdentificationFile getFile(int theIndex) { return (IdentificationFile)myFiles.get(theIndex); }
    
    /**
     *Remove file from the file list
     *@param theFileName Full file name of file to remove
     */
    public IdentificationFile getFile(String theFileName){
        for(int i=0; i<this.getNumFiles(); i++) {
            if(this.getFile(i).getFilePath().equals(theFileName)) {
                return this.getFile(i);
            }
        }
        
        return null;
    }
    
    /**
     *  Get the number of files in the collection
     *  @return no. of files in the collection
     */
    public int getNumFiles() { return myFiles.size(); }
    
    /**
     *  Add a new identification file to list (used when reading in an XML file collection file)
     *  @param theFile A new IdentificationFile object which will be populated from file
     */
    public void addIdentificationFile(IdentificationFile theFile) {
        myFiles.add(theFile);
    }
    
    
    /**
     *  Populates the details of the FileCollection when read in from XML file
     *  @param theName Name of the attribute read in
     *  @param theValue Value of the attribute read in
     */
    public void setAttributeValue( String theName, String theValue ) {
        if ( theName.equals(FFIT.AnalysisController.LABEL_APPLICATION_VERSION) ) {
            setDROIDVersion(theValue);
        } else if ( theName.equals("SigFileVersion") ) {
            setSignatureFileVersion(theValue);
        } else if ( theName.equals(FFIT.AnalysisController.LABEL_DATE_CREATED) ) {
            setDateCreated(theValue);
        } else {
            messageDisplay.unknownAttributeWarning(theName, this.getElementName());
        }
    }
    
    public void setDROIDVersion(String value) {
        if ( ! value.equals(AnalysisController.getFFITVersion())) {
            messageDisplay.generalWarning("This file was generated with DROID version "+value+".  Current version is "+AnalysisController.getFFITVersion());
        }
    }
    
    public void setSignatureFileVersion(String value) {
        try {
            mySigFileVersion = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            messageDisplay.generalWarning("The SigFileVersion attribute should be an integer");
        }
    }
    
    public void setDateCreated(String value) {
        // Ignore the contents of this element
    }
    
    /**
     * returns the signature file version recorded in the file collection file
     */
    public int getLoadedFileSigFileVersion() {
        return mySigFileVersion;
    }
    
}
