//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormEditSettings.cs,v 1.2 2006/07/02 14:45:50 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet {
    /// <summary>
    /// Form to edit the settings
    /// </summary>
    public partial class FormEditSettings : Form
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public FormEditSettings() {
            InitializeComponent();
        }

        private void FormEditSettings_Load(object sender, EventArgs e) {
            ResetSettings();
        }

        private void ResetSettings() {
            // Input
            tbxInputDirectory.Text = Variables.InitialInputDirectory;

            // Output
            tbxOutputDirectory.Text = Variables.InitialOutputDirectory;

            // Ramps
            lbxPredefinedRamps.Items.Clear();
            lbxPredefinedRamps.Items.AddRange(Variables.DefaultRamps.ToArray());
            lbxValidCharacters.Items.Clear();
            lbxValidCharacters.Items.AddRange(Variables.DefaultValidCharacters.ToArray());


            // FormConvertImage
            //cbInputBrightnessContrast.Checked = Variables.
            cbConfirmClose.Checked = Variables.ConfirmOnClose;
        }

        private void btnInputDirectory_Click(object sender, EventArgs e) {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK) {
                tbxInputDirectory.Text = folderBrowserDialog1.SelectedPath;
            }
        }
    }
}