//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: AboutDialog.cs,v 1.10 2006/12/24 18:38:12 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for FormAbout.
	/// </summary>
	public class AboutDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.PictureBox pbxIcon;
		private System.Windows.Forms.LinkLabel lblJMSoftwareLink;
		private System.Windows.Forms.LinkLabel lblSourceForgeLink;
		private System.Windows.Forms.Label lblVersion;
		private System.Windows.Forms.TextBox tbxLicence;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructor
		/// </summary>
		public AboutDialog()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			UpdateUI();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutDialog));
            this.tbxLicence = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.pbxIcon = new System.Windows.Forms.PictureBox();
            this.lblJMSoftwareLink = new System.Windows.Forms.LinkLabel();
            this.lblSourceForgeLink = new System.Windows.Forms.LinkLabel();
            this.lblVersion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxLicence
            // 
            this.tbxLicence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxLicence.Location = new System.Drawing.Point(16, 96);
            this.tbxLicence.Multiline = true;
            this.tbxLicence.Name = "tbxLicence";
            this.tbxLicence.ReadOnly = true;
            this.tbxLicence.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbxLicence.Size = new System.Drawing.Size(344, 78);
            this.tbxLicence.TabIndex = 0;
            this.tbxLicence.TabStop = false;
            this.tbxLicence.Text = resources.GetString("tbxLicence.Text");
            this.tbxLicence.Resize += new System.EventHandler(this.tbxLicence_Resize);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(88, 24);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(280, 24);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "lblTitle";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(256, 190);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(101, 32);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "btnOk";
            this.btnOk.UseVisualStyleBackColor = false;
            // 
            // pbxIcon
            // 
            this.pbxIcon.BackColor = System.Drawing.Color.White;
            this.pbxIcon.Image = ((System.Drawing.Image)(resources.GetObject("pbxIcon.Image")));
            this.pbxIcon.Location = new System.Drawing.Point(16, 16);
            this.pbxIcon.Name = "pbxIcon";
            this.pbxIcon.Size = new System.Drawing.Size(64, 64);
            this.pbxIcon.TabIndex = 3;
            this.pbxIcon.TabStop = false;
            // 
            // lblJMSoftwareLink
            // 
            this.lblJMSoftwareLink.Location = new System.Drawing.Point(96, 56);
            this.lblJMSoftwareLink.Name = "lblJMSoftwareLink";
            this.lblJMSoftwareLink.Size = new System.Drawing.Size(120, 16);
            this.lblJMSoftwareLink.TabIndex = 4;
            this.lblJMSoftwareLink.TabStop = true;
            this.lblJMSoftwareLink.Text = "www.jmsoftware.co.uk";
            this.lblJMSoftwareLink.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblJMSoftwareLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblJMSoftwareLink_LinkClicked);
            // 
            // lblSourceForgeLink
            // 
            this.lblSourceForgeLink.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSourceForgeLink.Location = new System.Drawing.Point(224, 56);
            this.lblSourceForgeLink.Name = "lblSourceForgeLink";
            this.lblSourceForgeLink.Size = new System.Drawing.Size(130, 16);
            this.lblSourceForgeLink.TabIndex = 5;
            this.lblSourceForgeLink.TabStop = true;
            this.lblSourceForgeLink.Text = "ascgen2.sourceforge.net";
            this.lblSourceForgeLink.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblSourceForgeLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSourceForgeLink_LinkClicked);
            // 
            // lblVersion
            // 
            this.lblVersion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVersion.Location = new System.Drawing.Point(16, 190);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(232, 32);
            this.lblVersion.TabIndex = 6;
            this.lblVersion.Text = "lblVersion";
            this.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AboutDialog
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnOk;
            this.ClientSize = new System.Drawing.Size(376, 238);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblJMSoftwareLink);
            this.Controls.Add(this.pbxIcon);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.tbxLicence);
            this.Controls.Add(this.lblSourceForgeLink);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(376, 208);
            this.Name = "AboutDialog";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            ((System.ComponentModel.ISupportInitialize)(this.pbxIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void lblJMSoftwareLink_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e) {
			lblJMSoftwareLink.LinkVisited = true;

			System.Diagnostics.Process.Start("http://ascgendotnet.jmsoftware.co.uk/");
		}

		private void lblSourceForgeLink_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e) {
			lblSourceForgeLink.LinkVisited = true;

			System.Diagnostics.Process.Start("http://ascgen2.sourceforge.net/");
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			lblVersion.Text = Variables.ProgramName + " - " + Resource.GetString("Version")
                + " " + Variables.Version.GetVersion();

			lblTitle.Text = Variables.ProgramName;

			btnOk.Text = Resource.GetString("&Ok");
		}

		private void tbxLicence_Resize(object sender, System.EventArgs e) {
			tbxLicence.Invalidate();
		}
	}
}