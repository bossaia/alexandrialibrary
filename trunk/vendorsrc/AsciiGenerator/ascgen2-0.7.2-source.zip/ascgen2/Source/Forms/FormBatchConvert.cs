//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormBatchConvert.cs,v 1.44 2006/12/24 18:38:12 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using JMSoftware.AsciiConversion;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	partial class FormBatchConvert : System.Windows.Forms.Form {
		/// <summary>
		/// Constructor
		/// </summary>
		public FormBatchConvert() {
			InitializeComponent();

			_settings = new TextProcessingSettings();

			cmbImageType.SelectedIndex = 1;

			if (_settings.Width == -1 && _settings.Height == -1) {
				tbxHeight.Text = String.Empty;
				tbxWidth.Text = "150";
				cbxLocked.Checked = true;
			}
			else {
				if (_settings.Width > 0 && _settings.Height > 0) {
					cbxLocked.Checked = false;
					tbxHeight.Text = _settings.Height.ToString(Variables.Culture);
					tbxWidth.Text = _settings.Width.ToString(Variables.Culture);
				}
				else {
					cbxLocked.Checked = true;

					if (_settings.Height > 0) {
						tbxHeight.Text = _settings.Height.ToString(Variables.Culture);
					}

					if (_settings.Width > 0) {
						tbxWidth.Text = _settings.Width.ToString(Variables.Culture);
					}
				}
			}
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="settings">Settings to use for the images</param>
		public FormBatchConvert(TextProcessingSettings settings) {
			InitializeComponent();

			_settings = settings;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void FormBatchConvert_Load(object sender, System.EventArgs e) {
			UpdateUI();

			tbxOutputDirectory.Text = Variables.InitialOutputDirectory;
			dialogAddDirectory.SelectedPath = dialogAddFiles.InitialDirectory = Variables.InitialInputDirectory;
		}

		private void FormBatchConvert_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			if (_Thread != null && _Thread.IsAlive) {
				_Thread.Abort();
			}
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			this.Text = Resource.GetString("Batch Conversion");
			btnAddFile.Text = cmenuFileAdd.Text = Resource.GetString("&Add File") + "...";
			btnRemove.Text = cmenuFilesRemove.Text = Resource.GetString("&Remove");
			cmenuFilesRemoveAll.Text = Resource.GetString("Remove All");
			cmenuFilesRemoveAfter.Text = Resource.GetString("Remove File After Conversion");
			btnAddDirectory.Text = cmenuFilesAddDirectory.Text = Resource.GetString("Add &Directory") + "...";
			lblOutputSize.Text = Resource.GetString("Output Size") + ":";
			btnSettings.Text = Resource.GetString("&Settings") + "...";
			lblFiles.Text = Resource.GetString("Files to be converted") + ":";
			lblOutput.Text = Resource.GetString("Output Directory") + ":";
			btnConvert.Text = Resource.GetString("&Convert");
			btnCancel.Text = Resource.GetString("&Cancel");
			btnClose.Text = Resource.GetString("C&lose");
			lblOutputAs.Text = Resource.GetString("Output as") + ":";

			cmenuFilesSelectAll.Text = Resource.GetString("Select All");
			cmenuFilesSelectNone.Text = Resource.GetString("Select None");
			cmenuFilesInvertSelection.Text = Resource.GetString("Invert Selection");
			cmenuFilesShowPath.Text = Resource.GetString("Show Full Path");
			cmenuFilesShowExtension.Text = Resource.GetString("Show Extension");

			cmenuLogClear.Text = Resource.GetString("Clear");
			cmenuLogSaveAs.Text = Resource.GetString("Save Log As") + "...";

			dialogAddFiles.Filter =
				Resource.GetString("Image Files") + "|*.bmp;*.rle;*.dib;*.exif;*.gif;*.jpg;*.jpeg;*.jpe;*.png;*.tif;*.tiff;*.wmf;*.emf|" +
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("Exchangeable Image Files") + " (*.exif)|*.exif|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" +
				Resource.GetString("Windows Metafile Images") + " (*.emf, *.wmf)|*.emf;*.wmf|" +
				Resource.GetString("Image Files") + " (*.*)|*.*";

			dialogOpenDirectory.Description = Resource.GetString("Select the directory in which to save the converted images");
			dialogAddDirectory.Description = Resource.GetString("Select a directory from which to import image files");
		}

		private void btnAddFile_Click(object sender, System.EventArgs e) {
			AddFiles();
		}

		/// <summary>Show the add files dialog and process the results</summary>
		private void AddFiles() {
			if (dialogAddFiles.ShowDialog() == DialogResult.OK) {
				foreach (string s in dialogAddFiles.FileNames) {
					if (!lbxFiles.Items.Contains(s))
						lbxFiles.Items.Add(s);
				}

				UpdateConvertButton();
			}
		}

		private void btnAddDirectory_Click(object sender, System.EventArgs e) {
			AddDirectory();
		}

		private void AddDirectory() {
			if (dialogAddDirectory.ShowDialog() == DialogResult.OK) {
				lbxFiles.SuspendLayout();

				string[] Files = Directory.GetFiles(dialogAddDirectory.SelectedPath);

				foreach (string str in Files) {
					string s = Path.GetExtension(str).ToLower(Variables.Culture);

					if (s == ".bmp" || s == ".rle" || s == ".dib" || s == ".exif" || s == ".gif" ||
							s == ".jpg" || s == ".jpeg" || s == ".jpe" || s == ".png" ||
							s == ".tif" || s == ".tiff" || s == ".wmf" || s == ".emf") {
						if (!lbxFiles.Items.Contains(str)) {
							lbxFiles.Items.Add(str);
						}
					}
				}

				lbxFiles.ResumeLayout();

				UpdateConvertButton();
			}
		}

		private void btnClose_Click(object sender, System.EventArgs e) {
			Close();
		}

		private void btnConvert_Click(object sender, System.EventArgs e) {
			if (tbxOutputDirectory.Text.Length == 0) {
				MessageBox.Show(Resource.GetString("Please enter an output directory"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				tbxOutputDirectory.Focus();
				return;
			}

			if (!System.IO.Directory.Exists(tbxOutputDirectory.Text)) {
				MessageBox.Show(Resource.GetString("Invalid Output Directory"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				tbxOutputDirectory.Focus();
				return;
			}

			ProcessBatch();
		}

		private void btnSettings_Click(object sender, System.EventArgs e) {
			FormTextSettings settingsDialog = new FormTextSettings(_settings);

			settingsDialog.Prefix = _Prefix;
			settingsDialog.Suffix = _Suffix;
			settingsDialog.SuffixType = _SuffixType;

			if (settingsDialog.ShowDialog() == DialogResult.OK) {
				_settings = settingsDialog.Settings;
				_Prefix = settingsDialog.Prefix;
				_Suffix = settingsDialog.Suffix;
				_SuffixType = settingsDialog.SuffixType;
			}
		}

		private void ProcessBatch() {
			if (tbxOutputDirectory.Text == null || tbxOutputDirectory.Text.Length == 0 || !System.IO.Directory.Exists(tbxOutputDirectory.Text)
				|| lbxFiles.Items == null)
				return;

			if ((cbxLocked.Checked && (_outputSize.Width < 1 && _outputSize.Height < 1)) ||
				(!cbxLocked.Checked && (_outputSize.Width < 1 || _outputSize.Height < 1))) {
				MessageBox.Show(Resource.GetString("Invalid Output Size"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				return;
			}

			_Thread = new Thread(new ThreadStart(ConversionThread));
			_Thread.Name = String.Format(Variables.Culture, "BatchConversionThread{0:HHmmss}", DateTime.Now);
			_Thread.Start();
		}

		private void ConversionThread() {
            CheckForIllegalCrossThreadCalls = false;
			pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = false;
			btnCancel.Enabled = true;

			progressConversion.Value = 0;
			progressConversion.Maximum = lbxFiles.Items.Count;

			int Errors = 0;
			int NumberConverted = 0;
			int Count = 0;

			if (lbxLog.Items.Count > 0) {
				AddLogString("");
			}
			else {
				AddLogString("ASCII Generator dotNET " + Variables.Version.GetVersion() + " Batch Conversion Log");
			}

			AddLogString("----------------------------------------------------------");

			AddLogString("Batch conversion started, " + String.Format(Variables.Culture, "{0} file(s) to process.", lbxFiles.Items.Count));

			AddLogString("Output directory: " + tbxOutputDirectory.Text);
			AddLogString("Saving output as " + (rbOutputAsText.Checked ? "txt" : cmbImageType.SelectedItem) + " files");

			if (rbOutputAsImage.Checked) {
				if (_ImageScalePercent < 100) {
					AddLogString(" (shrunk to " + _ImageScalePercent.ToString(Variables.Culture) + "%)", true);
				}
			}

			AddLogString("Target Font: " + _settings.Font.Name + " " + _settings.Font.Size.ToString(Variables.Culture) +
				"pt" + (_settings.Font.Bold ? ", bold" : "") + (_settings.Font.Italic ? ", italic" : "") +
				(_settings.Font.Underline ? ", underline" : "") + (_settings.Font.Strikeout ? ", strikeout" : "") + ".");

			AddLogString("Target Character Size: " + _settings.CharacterSize.Width.ToString(Variables.Culture) + "x" +
				_settings.CharacterSize.Height.ToString(Variables.Culture) + " pixels" +
				(_settings.CalculateCharacterSize ? " (automatically calculated)." : "."));

			AddLogString("ASCII Ramp" + (_settings.IsGeneratedRamp ? " (Generated)" : "") + ": " + _settings.Ramp);

			AddLogString(String.Format(Variables.Culture, "Text Brightness: {0}, Text Contrast: {1}", _settings.Brightness, _settings.Contrast));
			AddLogString(String.Format(Variables.Culture, "Output Levels - Minimum: {0}, Median: {1}, Maximum: {2}",
				_settings.Levels.Minimum, _settings.Levels.Median, _settings.Levels.Maximum));

			AddLogString("Effects: " + (_settings.IsBlackTextOnWhite ? "Black Text on White Background" : "White Text on Black Background") +
				(_settings.Stretch ? ", Stretched" : "") +
				(_settings.Sharpen ? ", Sharpened" : "") + (_settings.Unsharp ? ", Unsharp Mask" : "") +
				(_settings.FlipHorizontally ? ", Flipped Horizontally" : "") +
				(_settings.FlipVertically ? ", Flipped Vertically" : "") + ".");

			if (!cbxLocked.Checked) {
				AddLogString(String.Format(Variables.Culture,
					"Output Size: {0}x{1} characters", _outputSize.Width, _outputSize.Height));
			}

			AddLogString("----------------------------------------------------------");

			Image image;
			string outputfilename;

			StringCollection files = new StringCollection();

			// copy the strings into the new collection so we can remove them from the listbox
			foreach (string s in lbxFiles.Items) {
				files.Add(s);
			}

			foreach (string s in files) {
				Count++;
				progressConversion.Value++;

				AddLogString(Count.ToString(Variables.Culture) + ". " + Path.GetFileName(s) + ": ");

				outputfilename = tbxOutputDirectory.Text;

				if (outputfilename[outputfilename.Length - 1] != Path.DirectorySeparatorChar) {
					outputfilename += Path.DirectorySeparatorChar;
				}

				outputfilename += _Prefix + Path.GetFileNameWithoutExtension(s);
				
				switch (_SuffixType) {
					case FormTextSettings.SuffixTypes.UserDefined:
					default:
						outputfilename += _Suffix;
						break;

					case FormTextSettings.SuffixTypes.Random:
						outputfilename += "-" + GetRandomString(6);
						break;

					case FormTextSettings.SuffixTypes.DateTime:
						outputfilename += String.Format(Variables.Culture, "-{0:yyyyMMddHHmmss}", DateTime.Now);
						break;
				}

				outputfilename += rbOutputAsText.Checked ? ".txt" : "." + cmbImageType.SelectedItem;

				if (System.IO.File.Exists(outputfilename)) {
					// TODO: If outputfilename exists create one that doesn't
					AddLogString("Error (" + outputfilename + " already exists)");
					Errors++;
					continue;
				}

				AddLogString("Loading... ", true);

				try {
					image = Image.FromFile(s);
				}
				catch (System.IO.FileNotFoundException) {
					AddLogString("Error: file not found.", true);
					Errors++;
					continue;
				}
				catch (System.OutOfMemoryException) {
					AddLogString("Error: Invalid or unsupported file.", true);
					Errors++;
					continue;
				}

				AddLogString("Converting", true);

				// if width not set XOR height not set...
				if (_outputSize.Width == -1 ^ _outputSize.Height == -1) {
					if (_outputSize.Height == -1) {
						_settings.Width = _outputSize.Width;

						_settings.Height = AscgenConverter.CalculateOtherDimension(_settings.Width,
							image.Width, image.Height, _settings.CharacterSize.Width, _settings.CharacterSize.Height);
					}
					else { // (_outputSize.Width == -1)
						_settings.Height = _outputSize.Height;

						_settings.Width = AscgenConverter.CalculateOtherDimension(_settings.Height,
							image.Height, image.Width, _settings.CharacterSize.Height, _settings.CharacterSize.Width);
					}

					AddLogString(String.Format(Variables.Culture,
						" ({0}x{1})", _settings.Width, _settings.Height), true);
				}
				else {
					_settings.Size = _outputSize;
				}

				AddLogString("... ", true);

				string[] text = AscgenConverter.Convert(image, _settings);

				image.Dispose();

				if (text == null) {
					AddLogString("Error converting the image");
					Errors++;
				}
				else {

					AddLogString("Saving... ", true);

					bool Saved = false;

					if (rbOutputAsText.Checked) {
						StreamWriter writer = new StreamWriter(outputfilename);

						foreach (string line in text) {
							writer.WriteLine(line);
						}

						writer.Close();

						Saved = true;
					}
					else {
                        System.Text.StringBuilder builder = new System.Text.StringBuilder();

                        foreach (string str in text) {
                            builder.AppendLine(str);
                        }

						Saved = AscgenConverter.SaveTextAsImage(builder.ToString(), outputfilename, _settings.Font,
							_settings.IsBlackTextOnWhite ? Color.Black : Color.White,
							_settings.IsBlackTextOnWhite ? Color.White : Color.Black,
							(float)_ImageScalePercent, true);
					}

					if (Saved) {
						AddLogString(" - " + Path.GetFileName(outputfilename) + " saved.");
					}
					else {
						AddLogString(" * Error saving " + Path.GetFileName(outputfilename));
					}

					NumberConverted++;

					if (cmenuFilesRemoveAfter.Checked)
						lbxFiles.Items.Remove(s);
				}
			}

			AddLogString("----------------------------------------------------------");
			AddLogString("Batch finished, " +
				String.Format(Variables.Culture, "{0} file(s) converted, {1} error(s)", NumberConverted, Errors));

			pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = true;
			btnCancel.Enabled = false;

			if (cmenuFilesRemoveAfter.Checked)
				UpdateConvertButton();

            CheckForIllegalCrossThreadCalls = true;
		}

		private void btnCancel_Click(object sender, System.EventArgs e) {
			if (_Thread != null && _Thread.IsAlive) {
				_Thread.Abort();
				AddLogString("*** Batch conversion cancelled ***");

				pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = true;
				btnCancel.Enabled = false;
			}
		}

		private void btnOutputDirectory_Click(object sender, System.EventArgs e) {
			dialogOpenDirectory.SelectedPath = tbxOutputDirectory.Text;

			if (dialogOpenDirectory.ShowDialog() == DialogResult.OK) {
				tbxOutputDirectory.Text = dialogOpenDirectory.SelectedPath;
			}
		}

		/// <summary>
		/// Add a string to the listbox log
		/// </summary>
		/// <param name="s">String to add</param>
		private void AddLogString(string s) {
			AddLogString(s, false);
		}

		/// <summary>
		/// Add a string to the listbox log
		/// </summary>
		/// <param name="s">String to add</param>
		/// <param name="append">Append the string on to the end of last line</param>
		private void AddLogString(string s, bool append) {
			if (append) {
				lbxLog.Items[lbxLog.Items.Count - 1] = lbxLog.Items[lbxLog.Items.Count - 1].ToString() + s;
			}
			else {
				lbxLog.Items.Add(s);
			}

			lbxLog.TopIndex = lbxLog.Items.Count - 1;
		}

		private void btnRemove_Click(object sender, System.EventArgs e) {
			RemoveSelectedFiles();
		}

		/// <summary>Remove all selected files from the list</summary>
		private void RemoveSelectedFiles() {
			while (lbxFiles.SelectedItems.Count > 0) {
				if (lbxFiles.Items.Count == 1)	// workaround removing last item problem
					lbxFiles.Items.Clear();
				else
					lbxFiles.Items.Remove(lbxFiles.SelectedItem);
			}

			btnRemove.Enabled = false;

			UpdateConvertButton();
		}

		private void lbxFiles_SelectedIndexChanged(object sender, System.EventArgs e) {
			btnRemove.Enabled = (lbxFiles.SelectedItems.Count > 0);
			btnRemove.Refresh();
		}

		private void tbxWidth_TextChanged(object sender, System.EventArgs e) {
			if (!_sizeChanging) {
				_sizeChanging = true;

				_widthChangedLast = true;

				try {
					_outputSize.Width = Convert.ToInt32(tbxWidth.Text, Variables.Culture);
				}
				catch (FormatException) {
					_outputSize.Width = -1;
				}

				if (cbxLocked.Checked) {
					_outputSize.Height = -1;
					tbxHeight.Text = String.Empty;

					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Control;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}

				UpdateConvertButton();

				_sizeChanging = false;
			}
		}

		private void tbxHeight_TextChanged(object sender, System.EventArgs e) {
			if (!_sizeChanging) {
				_sizeChanging = true;

				_widthChangedLast = false;

				try {
					_outputSize.Height = Convert.ToInt32(tbxHeight.Text, Variables.Culture);
				}
				catch (FormatException) {
					_outputSize.Height = -1;
				}

				if (cbxLocked.Checked) {
					_outputSize.Width = -1;
					tbxWidth.Text = String.Empty;

					tbxWidth.BackColor = System.Drawing.SystemColors.Control;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}

				UpdateConvertButton();

				_sizeChanging = false;
			}		
		}

		private void cbxLocked_CheckedChanged(object sender, System.EventArgs e) {
			if (cbxLocked.Checked) {
				if (_widthChangedLast) {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Control;

					_sizeChanging = true;
					tbxHeight.Text = String.Empty;
					_outputSize.Height = -1;
					_sizeChanging = false;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Control;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;

					_sizeChanging = true;
					tbxWidth.Text = String.Empty;
					_outputSize.Width = -1;
					_sizeChanging = false;
				}
			}
			else {
				tbxWidth.BackColor = System.Drawing.SystemColors.Window;
				tbxHeight.BackColor = System.Drawing.SystemColors.Window;
			}

			UpdateConvertButton();
		}

		/// <summary>
		/// Check and update the Convert button Enabled property
		/// </summary>
		private void UpdateConvertButton() {
			bool Result = lbxFiles.Items.Count > 0 && tbxOutputDirectory.Text.Length > 0;

			if (cbxLocked.Checked) {
				Result = Result && ((_outputSize.Width > 0 && _outputSize.Height == -1) ||
					(_outputSize.Width == -1 && _outputSize.Height > 0));
			}
			else {
				Result = Result && (_outputSize.Width > 0 && _outputSize.Height > 0);
			}

			if (rbOutputAsImage.Checked) {
				Result = Result && (_ImageScalePercent > 0);
			}

			btnConvert.Enabled = Result;
		}

		private void tbxOutputDirectory_TextChanged(object sender, System.EventArgs e) {
			UpdateConvertButton();
		}

		private void lbxFiles_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			string[] filenames = (string[])e.Data.GetData(DataFormats.FileDrop);

			foreach (string s in filenames) {
				if (!lbxFiles.Items.Contains(s))
					lbxFiles.Items.Add(s);
			}

			UpdateConvertButton();
		}

		private void lbxFiles_DragOver(object sender, System.Windows.Forms.DragEventArgs e) {
			e.Effect = DragDropEffects.Copy;
		}

		private void cmenuFiles_Popup(object sender, System.EventArgs e) {
			cmenuFilesShowExtension.Checked = lbxFiles.DisplayExtension;
			cmenuFilesShowPath.Checked = lbxFiles.DisplayPath;

			cmenuFilesSelectNone.Enabled = cmenuFilesRemove.Enabled =
				lbxFiles.SelectedItems.Count > 0;

			cmenuFilesRemoveAll.Enabled = cmenuFilesInvertSelection.Enabled = lbxFiles.Items.Count > 0;

			cmenuFilesSelectAll.Enabled = lbxFiles.SelectedItems.Count < lbxFiles.Items.Count;
		}

		private void cmenuFilesAdd_Click(object sender, System.EventArgs e) {
			AddFiles();
		}

		private void cmenuFilesAddDirectory_Click(object sender, System.EventArgs e) {
			AddDirectory();
		}

		private void cmenuFilesRemove_Click(object sender, System.EventArgs e) {
			RemoveSelectedFiles();
		}

		private void cmenuFilesRemoveAll_Click(object sender, System.EventArgs e) {
			lbxFiles.Items.Clear();
			UpdateConvertButton();
		}

		private void cmenuFilesSelectAll_Click(object sender, System.EventArgs e) {
			for (int i = 0; i < lbxFiles.Items.Count; i++) {
				lbxFiles.SetSelected(i, true);
			}
		}

		private void cmenuFilesSelectNone_Click(object sender, System.EventArgs e) {
			lbxFiles.ClearSelected();
		}

		private void cmenuFilesInvertSelection_Click(object sender, System.EventArgs e) {
			for (int i = 0; i < lbxFiles.Items.Count; i++) {
				lbxFiles.SetSelected(i, !lbxFiles.GetSelected(i));
			}
		}

		private void cmenuFilesShowPath_Click(object sender, System.EventArgs e) {
			lbxFiles.DisplayPath = !lbxFiles.DisplayPath;
		}

		private void cmenuFilesShowExtension_Click(object sender, System.EventArgs e) {
			lbxFiles.DisplayExtension = !lbxFiles.DisplayExtension;
		}

		private void cmenuLog_Popup(object sender, System.EventArgs e) {
			cmenuLogClear.Enabled = cmenuLogSaveAs.Enabled = (lbxLog.Items.Count > 0 && !_Thread.IsAlive);
		}

		private void cmenuLogClear_Click(object sender, System.EventArgs e) {
			lbxLog.Items.Clear();
		}

		private void cmenuLogSaveAs_Click(object sender, System.EventArgs e) {
			dialogSaveLog.FileName = String.Format(Variables.Culture, "Log{0:yyyyMMddHHmmss}", System.DateTime.Now);

			if (dialogSaveLog.ShowDialog() == DialogResult.OK) {
				StreamWriter logwriter = new StreamWriter(dialogSaveLog.FileName);

				foreach (string s in lbxLog.Items) {
					logwriter.WriteLine(s);
				}
							
				logwriter.Close();
			}
		}

		private void cmenuFilesRemoveAfter_Click(object sender, System.EventArgs e) {
			cmenuFilesRemoveAfter.Checked = !cmenuFilesRemoveAfter.Checked;
		}

		private void rbOutputAsImage_CheckedChanged(object sender, System.EventArgs e) {
			cmbImageType.Enabled = tbxPercent.Enabled = rbOutputAsImage.Checked;

			UpdateConvertButton();
		}

		private void tbxPercent_TextChanged(object sender, System.EventArgs e) {
			try {
				_ImageScalePercent = Convert.ToInt32(tbxPercent.Text, Variables.Culture);

				if (_ImageScalePercent < 1 || _ImageScalePercent > 100) {
					_ImageScalePercent = -1;
				}
			}
			catch (FormatException) {
				_ImageScalePercent = -1;
			}

			UpdateConvertButton();
		}

		private string GetRandomString(int length) {
			string RandomString = String.Empty;
			string validchars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

			System.Random random = new Random();

			for (int i = 0; i < length; i++) {
				RandomString += validchars[random.Next(validchars.Length - 1)];
			}

			return RandomString;
		}

		#region Properties and Variables

		private TextProcessingSettings _settings;

		/// <summary>Size of the output images (-1 to calculate the dimension)</summary>
		private Size _outputSize = new Size(Variables.DefaultWidth, Variables.DefaultHeight);

		private bool _sizeChanging;

		private bool _widthChangedLast = true;

		private Thread _Thread;

		private string _Prefix = Variables.Prefix;

		private string _Suffix = String.Empty;

		private int _ImageScalePercent = 75;

		private FormTextSettings.SuffixTypes _SuffixType = FormTextSettings.SuffixTypes.UserDefined;

		#endregion
	}
}