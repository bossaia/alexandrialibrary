//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormEditSettings.Designer.cs,v 1.2 2006/07/02 14:45:50 wardog_uk Exp $
//----------------------------------------------------------------------------
namespace JMSoftware.AsciiGeneratorDotNet
{
    partial class FormEditSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tabSettings = new System.Windows.Forms.TabControl();
            this.tabPageInput = new System.Windows.Forms.TabPage();
            this.gbxInputBrightnessContrast = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.cbxLoadInputBC = new System.Windows.Forms.CheckBox();
            this.lblInputBrightness = new System.Windows.Forms.Label();
            this.lblInputContrast = new System.Windows.Forms.Label();
            this.btnInputDirectory = new System.Windows.Forms.Button();
            this.tbxInputDirectory = new System.Windows.Forms.TextBox();
            this.lblInputDirectory = new System.Windows.Forms.Label();
            this.tabPageOutput = new System.Windows.Forms.TabPage();
            this.cbxInvert = new System.Windows.Forms.CheckBox();
            this.gbxOutputLevels = new System.Windows.Forms.GroupBox();
            this.tbxMed = new System.Windows.Forms.TextBox();
            this.lblMed = new System.Windows.Forms.Label();
            this.tbxMin = new System.Windows.Forms.TextBox();
            this.tbxMax = new System.Windows.Forms.TextBox();
            this.cbxLoadOutputLevels = new System.Windows.Forms.CheckBox();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.gbxOutputBrightnessContrast = new System.Windows.Forms.GroupBox();
            this.tbxOutputBrightness = new System.Windows.Forms.TextBox();
            this.tbxOutputContrast = new System.Windows.Forms.TextBox();
            this.cbxLoadOutputBC = new System.Windows.Forms.CheckBox();
            this.lblOutputBrightness = new System.Windows.Forms.Label();
            this.lblOutputContrast = new System.Windows.Forms.Label();
            this.btnFont = new System.Windows.Forms.Button();
            this.tbxOutputDirectory = new System.Windows.Forms.TextBox();
            this.lblOutputDirectory = new System.Windows.Forms.Label();
            this.btnOutputDirectory = new System.Windows.Forms.Button();
            this.gbxSize = new System.Windows.Forms.GroupBox();
            this.tbxHeight = new System.Windows.Forms.TextBox();
            this.cbxLoadSize = new System.Windows.Forms.CheckBox();
            this.tbxWidth = new System.Windows.Forms.TextBox();
            this.tabPageRamps = new System.Windows.Forms.TabPage();
            this.lbxValidCharacters = new System.Windows.Forms.ListBox();
            this.lbxPredefinedRamps = new System.Windows.Forms.ListBox();
            this.tabPageConvertImageForm = new System.Windows.Forms.TabPage();
            this.gbxSelectionArea = new System.Windows.Forms.GroupBox();
            this.gbWidgets = new System.Windows.Forms.GroupBox();
            this.cbOutputLevels = new System.Windows.Forms.CheckBox();
            this.cbOutputBrightnessContrast = new System.Windows.Forms.CheckBox();
            this.cbInputBrightnessContrast = new System.Windows.Forms.CheckBox();
            this.cbConfirmClose = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cbxFlipHorizontally = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.gbxFlip = new System.Windows.Forms.GroupBox();
            this.lblPrefix = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.btnFillColor = new System.Windows.Forms.Button();
            this.btnBorderColor = new System.Windows.Forms.Button();
            this.tabSettings.SuspendLayout();
            this.tabPageInput.SuspendLayout();
            this.gbxInputBrightnessContrast.SuspendLayout();
            this.tabPageOutput.SuspendLayout();
            this.gbxOutputLevels.SuspendLayout();
            this.gbxOutputBrightnessContrast.SuspendLayout();
            this.gbxSize.SuspendLayout();
            this.tabPageRamps.SuspendLayout();
            this.tabPageConvertImageForm.SuspendLayout();
            this.gbxSelectionArea.SuspendLayout();
            this.gbWidgets.SuspendLayout();
            this.gbxFlip.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(12, 239);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "btnOk";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(336, 239);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // tabSettings
            // 
            this.tabSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabSettings.Controls.Add(this.tabPageInput);
            this.tabSettings.Controls.Add(this.tabPageOutput);
            this.tabSettings.Controls.Add(this.tabPageRamps);
            this.tabSettings.Controls.Add(this.tabPageConvertImageForm);
            this.tabSettings.HotTrack = true;
            this.tabSettings.Location = new System.Drawing.Point(12, 12);
            this.tabSettings.Name = "tabSettings";
            this.tabSettings.SelectedIndex = 0;
            this.tabSettings.Size = new System.Drawing.Size(399, 221);
            this.tabSettings.TabIndex = 2;
            // 
            // tabPageInput
            // 
            this.tabPageInput.Controls.Add(this.gbxInputBrightnessContrast);
            this.tabPageInput.Controls.Add(this.btnInputDirectory);
            this.tabPageInput.Controls.Add(this.tbxInputDirectory);
            this.tabPageInput.Controls.Add(this.lblInputDirectory);
            this.tabPageInput.Location = new System.Drawing.Point(4, 22);
            this.tabPageInput.Name = "tabPageInput";
            this.tabPageInput.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInput.Size = new System.Drawing.Size(391, 195);
            this.tabPageInput.TabIndex = 0;
            this.tabPageInput.Text = "tabPageInput";
            this.tabPageInput.UseVisualStyleBackColor = true;
            // 
            // gbxInputBrightnessContrast
            // 
            this.gbxInputBrightnessContrast.Controls.Add(this.textBox2);
            this.gbxInputBrightnessContrast.Controls.Add(this.textBox3);
            this.gbxInputBrightnessContrast.Controls.Add(this.cbxLoadInputBC);
            this.gbxInputBrightnessContrast.Controls.Add(this.lblInputBrightness);
            this.gbxInputBrightnessContrast.Controls.Add(this.lblInputContrast);
            this.gbxInputBrightnessContrast.Location = new System.Drawing.Point(6, 104);
            this.gbxInputBrightnessContrast.Name = "gbxInputBrightnessContrast";
            this.gbxInputBrightnessContrast.Size = new System.Drawing.Size(379, 38);
            this.gbxInputBrightnessContrast.TabIndex = 11;
            this.gbxInputBrightnessContrast.TabStop = false;
            this.gbxInputBrightnessContrast.Text = "gbxInputBrightnessContrast";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(81, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(46, 20);
            this.textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(218, 13);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(46, 20);
            this.textBox3.TabIndex = 7;
            // 
            // cbxLoadInputBC
            // 
            this.cbxLoadInputBC.AutoSize = true;
            this.cbxLoadInputBC.Location = new System.Drawing.Point(284, 15);
            this.cbxLoadInputBC.Name = "cbxLoadInputBC";
            this.cbxLoadInputBC.Size = new System.Drawing.Size(105, 17);
            this.cbxLoadInputBC.TabIndex = 8;
            this.cbxLoadInputBC.Text = "cbxLoadInputBC";
            this.cbxLoadInputBC.UseVisualStyleBackColor = true;
            // 
            // lblInputBrightness
            // 
            this.lblInputBrightness.AutoSize = true;
            this.lblInputBrightness.Location = new System.Drawing.Point(9, 16);
            this.lblInputBrightness.Name = "lblInputBrightness";
            this.lblInputBrightness.Size = new System.Drawing.Size(90, 13);
            this.lblInputBrightness.TabIndex = 4;
            this.lblInputBrightness.Text = "lblInputBrightness";
            // 
            // lblInputContrast
            // 
            this.lblInputContrast.AutoSize = true;
            this.lblInputContrast.Location = new System.Drawing.Point(156, 16);
            this.lblInputContrast.Name = "lblInputContrast";
            this.lblInputContrast.Size = new System.Drawing.Size(80, 13);
            this.lblInputContrast.TabIndex = 6;
            this.lblInputContrast.Text = "lblInputContrast";
            // 
            // btnInputDirectory
            // 
            this.btnInputDirectory.Image = global::AscGenDotNet.Properties.Resources.folder;
            this.btnInputDirectory.Location = new System.Drawing.Point(326, 52);
            this.btnInputDirectory.Name = "btnInputDirectory";
            this.btnInputDirectory.Size = new System.Drawing.Size(30, 23);
            this.btnInputDirectory.TabIndex = 5;
            this.btnInputDirectory.UseVisualStyleBackColor = true;
            this.btnInputDirectory.Click += new System.EventHandler(this.btnInputDirectory_Click);
            // 
            // tbxInputDirectory
            // 
            this.tbxInputDirectory.Location = new System.Drawing.Point(120, 54);
            this.tbxInputDirectory.Name = "tbxInputDirectory";
            this.tbxInputDirectory.Size = new System.Drawing.Size(200, 20);
            this.tbxInputDirectory.TabIndex = 4;
            // 
            // lblInputDirectory
            // 
            this.lblInputDirectory.AutoSize = true;
            this.lblInputDirectory.Location = new System.Drawing.Point(35, 57);
            this.lblInputDirectory.Name = "lblInputDirectory";
            this.lblInputDirectory.Size = new System.Drawing.Size(79, 13);
            this.lblInputDirectory.TabIndex = 3;
            this.lblInputDirectory.Text = "Input Directory:";
            // 
            // tabPageOutput
            // 
            this.tabPageOutput.Controls.Add(this.comboBox1);
            this.tabPageOutput.Controls.Add(this.textBox1);
            this.tabPageOutput.Controls.Add(this.lblPrefix);
            this.tabPageOutput.Controls.Add(this.gbxFlip);
            this.tabPageOutput.Controls.Add(this.checkBox1);
            this.tabPageOutput.Controls.Add(this.cbxInvert);
            this.tabPageOutput.Controls.Add(this.gbxOutputLevels);
            this.tabPageOutput.Controls.Add(this.gbxOutputBrightnessContrast);
            this.tabPageOutput.Controls.Add(this.btnFont);
            this.tabPageOutput.Controls.Add(this.tbxOutputDirectory);
            this.tabPageOutput.Controls.Add(this.lblOutputDirectory);
            this.tabPageOutput.Controls.Add(this.btnOutputDirectory);
            this.tabPageOutput.Controls.Add(this.gbxSize);
            this.tabPageOutput.Location = new System.Drawing.Point(4, 22);
            this.tabPageOutput.Name = "tabPageOutput";
            this.tabPageOutput.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOutput.Size = new System.Drawing.Size(391, 195);
            this.tabPageOutput.TabIndex = 1;
            this.tabPageOutput.Text = "tabPageOutput";
            this.tabPageOutput.UseVisualStyleBackColor = true;
            // 
            // cbxInvert
            // 
            this.cbxInvert.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbxInvert.Image = global::AscGenDotNet.Properties.Resources.contrast_high;
            this.cbxInvert.Location = new System.Drawing.Point(355, 6);
            this.cbxInvert.Name = "cbxInvert";
            this.cbxInvert.Size = new System.Drawing.Size(30, 23);
            this.cbxInvert.TabIndex = 12;
            this.cbxInvert.UseVisualStyleBackColor = true;
            // 
            // gbxOutputLevels
            // 
            this.gbxOutputLevels.Controls.Add(this.tbxMed);
            this.gbxOutputLevels.Controls.Add(this.lblMed);
            this.gbxOutputLevels.Controls.Add(this.tbxMin);
            this.gbxOutputLevels.Controls.Add(this.tbxMax);
            this.gbxOutputLevels.Controls.Add(this.cbxLoadOutputLevels);
            this.gbxOutputLevels.Controls.Add(this.lblMin);
            this.gbxOutputLevels.Controls.Add(this.lblMax);
            this.gbxOutputLevels.Location = new System.Drawing.Point(6, 79);
            this.gbxOutputLevels.Name = "gbxOutputLevels";
            this.gbxOutputLevels.Size = new System.Drawing.Size(379, 38);
            this.gbxOutputLevels.TabIndex = 11;
            this.gbxOutputLevels.TabStop = false;
            this.gbxOutputLevels.Text = "gbxOutputLevels";
            // 
            // tbxMed
            // 
            this.tbxMed.Location = new System.Drawing.Point(227, 13);
            this.tbxMed.Name = "tbxMed";
            this.tbxMed.Size = new System.Drawing.Size(46, 20);
            this.tbxMed.TabIndex = 10;
            // 
            // lblMed
            // 
            this.lblMed.AutoSize = true;
            this.lblMed.Location = new System.Drawing.Point(190, 16);
            this.lblMed.Name = "lblMed";
            this.lblMed.Size = new System.Drawing.Size(38, 13);
            this.lblMed.TabIndex = 9;
            this.lblMed.Text = "lblMed";
            // 
            // tbxMin
            // 
            this.tbxMin.Location = new System.Drawing.Point(49, 13);
            this.tbxMin.Name = "tbxMin";
            this.tbxMin.Size = new System.Drawing.Size(46, 20);
            this.tbxMin.TabIndex = 5;
            // 
            // tbxMax
            // 
            this.tbxMax.Location = new System.Drawing.Point(138, 13);
            this.tbxMax.Name = "tbxMax";
            this.tbxMax.Size = new System.Drawing.Size(46, 20);
            this.tbxMax.TabIndex = 7;
            // 
            // cbxLoadOutputLevels
            // 
            this.cbxLoadOutputLevels.AutoSize = true;
            this.cbxLoadOutputLevels.Location = new System.Drawing.Point(284, 15);
            this.cbxLoadOutputLevels.Name = "cbxLoadOutputLevels";
            this.cbxLoadOutputLevels.Size = new System.Drawing.Size(130, 17);
            this.cbxLoadOutputLevels.TabIndex = 8;
            this.cbxLoadOutputLevels.Text = "cbxLoadOutputLevels";
            this.cbxLoadOutputLevels.UseVisualStyleBackColor = true;
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(9, 16);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(34, 13);
            this.lblMin.TabIndex = 4;
            this.lblMin.Text = "lblMin";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(101, 16);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(37, 13);
            this.lblMax.TabIndex = 6;
            this.lblMax.Text = "lblMax";
            // 
            // gbxOutputBrightnessContrast
            // 
            this.gbxOutputBrightnessContrast.Controls.Add(this.tbxOutputBrightness);
            this.gbxOutputBrightnessContrast.Controls.Add(this.tbxOutputContrast);
            this.gbxOutputBrightnessContrast.Controls.Add(this.cbxLoadOutputBC);
            this.gbxOutputBrightnessContrast.Controls.Add(this.lblOutputBrightness);
            this.gbxOutputBrightnessContrast.Controls.Add(this.lblOutputContrast);
            this.gbxOutputBrightnessContrast.Location = new System.Drawing.Point(6, 35);
            this.gbxOutputBrightnessContrast.Name = "gbxOutputBrightnessContrast";
            this.gbxOutputBrightnessContrast.Size = new System.Drawing.Size(379, 38);
            this.gbxOutputBrightnessContrast.TabIndex = 10;
            this.gbxOutputBrightnessContrast.TabStop = false;
            this.gbxOutputBrightnessContrast.Text = "gbxOutputBrightnessContrast";
            // 
            // tbxOutputBrightness
            // 
            this.tbxOutputBrightness.Location = new System.Drawing.Point(81, 13);
            this.tbxOutputBrightness.Name = "tbxOutputBrightness";
            this.tbxOutputBrightness.Size = new System.Drawing.Size(46, 20);
            this.tbxOutputBrightness.TabIndex = 5;
            // 
            // tbxOutputContrast
            // 
            this.tbxOutputContrast.Location = new System.Drawing.Point(233, 13);
            this.tbxOutputContrast.Name = "tbxOutputContrast";
            this.tbxOutputContrast.Size = new System.Drawing.Size(46, 20);
            this.tbxOutputContrast.TabIndex = 7;
            // 
            // cbxLoadOutputBC
            // 
            this.cbxLoadOutputBC.AutoSize = true;
            this.cbxLoadOutputBC.Location = new System.Drawing.Point(323, 15);
            this.cbxLoadOutputBC.Name = "cbxLoadOutputBC";
            this.cbxLoadOutputBC.Size = new System.Drawing.Size(113, 17);
            this.cbxLoadOutputBC.TabIndex = 8;
            this.cbxLoadOutputBC.Text = "cbxLoadOutputBC";
            this.cbxLoadOutputBC.UseVisualStyleBackColor = true;
            // 
            // lblOutputBrightness
            // 
            this.lblOutputBrightness.AutoSize = true;
            this.lblOutputBrightness.Location = new System.Drawing.Point(9, 16);
            this.lblOutputBrightness.Name = "lblOutputBrightness";
            this.lblOutputBrightness.Size = new System.Drawing.Size(98, 13);
            this.lblOutputBrightness.TabIndex = 4;
            this.lblOutputBrightness.Text = "lblOutputBrightness";
            // 
            // lblOutputContrast
            // 
            this.lblOutputContrast.AutoSize = true;
            this.lblOutputContrast.Location = new System.Drawing.Point(171, 16);
            this.lblOutputContrast.Name = "lblOutputContrast";
            this.lblOutputContrast.Size = new System.Drawing.Size(88, 13);
            this.lblOutputContrast.TabIndex = 6;
            this.lblOutputContrast.Text = "lblOutputContrast";
            // 
            // btnFont
            // 
            this.btnFont.Location = new System.Drawing.Point(245, 6);
            this.btnFont.Name = "btnFont";
            this.btnFont.Size = new System.Drawing.Size(75, 23);
            this.btnFont.TabIndex = 3;
            this.btnFont.Text = "btnFont";
            this.btnFont.UseVisualStyleBackColor = true;
            // 
            // tbxOutputDirectory
            // 
            this.tbxOutputDirectory.Location = new System.Drawing.Point(64, 8);
            this.tbxOutputDirectory.Name = "tbxOutputDirectory";
            this.tbxOutputDirectory.Size = new System.Drawing.Size(110, 20);
            this.tbxOutputDirectory.TabIndex = 1;
            // 
            // lblOutputDirectory
            // 
            this.lblOutputDirectory.AutoSize = true;
            this.lblOutputDirectory.Location = new System.Drawing.Point(6, 11);
            this.lblOutputDirectory.Name = "lblOutputDirectory";
            this.lblOutputDirectory.Size = new System.Drawing.Size(52, 13);
            this.lblOutputDirectory.TabIndex = 0;
            this.lblOutputDirectory.Text = "Directory:";
            // 
            // btnOutputDirectory
            // 
            this.btnOutputDirectory.Image = global::AscGenDotNet.Properties.Resources.folder;
            this.btnOutputDirectory.Location = new System.Drawing.Point(180, 6);
            this.btnOutputDirectory.Name = "btnOutputDirectory";
            this.btnOutputDirectory.Size = new System.Drawing.Size(30, 23);
            this.btnOutputDirectory.TabIndex = 2;
            this.btnOutputDirectory.UseVisualStyleBackColor = true;
            // 
            // gbxSize
            // 
            this.gbxSize.Controls.Add(this.tbxHeight);
            this.gbxSize.Controls.Add(this.cbxLoadSize);
            this.gbxSize.Controls.Add(this.tbxWidth);
            this.gbxSize.Location = new System.Drawing.Point(116, 123);
            this.gbxSize.Name = "gbxSize";
            this.gbxSize.Size = new System.Drawing.Size(166, 38);
            this.gbxSize.TabIndex = 9;
            this.gbxSize.TabStop = false;
            this.gbxSize.Text = "gbxSize";
            // 
            // tbxHeight
            // 
            this.tbxHeight.Location = new System.Drawing.Point(58, 13);
            this.tbxHeight.Name = "tbxHeight";
            this.tbxHeight.Size = new System.Drawing.Size(46, 20);
            this.tbxHeight.TabIndex = 7;
            // 
            // cbxLoadSize
            // 
            this.cbxLoadSize.AutoSize = true;
            this.cbxLoadSize.Location = new System.Drawing.Point(110, 15);
            this.cbxLoadSize.Name = "cbxLoadSize";
            this.cbxLoadSize.Size = new System.Drawing.Size(87, 17);
            this.cbxLoadSize.TabIndex = 8;
            this.cbxLoadSize.Text = "cbxLoadSize";
            this.cbxLoadSize.UseVisualStyleBackColor = true;
            // 
            // tbxWidth
            // 
            this.tbxWidth.Location = new System.Drawing.Point(6, 13);
            this.tbxWidth.Name = "tbxWidth";
            this.tbxWidth.Size = new System.Drawing.Size(46, 20);
            this.tbxWidth.TabIndex = 5;
            // 
            // tabPageRamps
            // 
            this.tabPageRamps.Controls.Add(this.lbxValidCharacters);
            this.tabPageRamps.Controls.Add(this.lbxPredefinedRamps);
            this.tabPageRamps.Location = new System.Drawing.Point(4, 22);
            this.tabPageRamps.Name = "tabPageRamps";
            this.tabPageRamps.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRamps.Size = new System.Drawing.Size(391, 195);
            this.tabPageRamps.TabIndex = 2;
            this.tabPageRamps.Text = "tabPageRamps";
            this.tabPageRamps.UseVisualStyleBackColor = true;
            // 
            // lbxValidCharacters
            // 
            this.lbxValidCharacters.FormattingEnabled = true;
            this.lbxValidCharacters.Location = new System.Drawing.Point(3, 110);
            this.lbxValidCharacters.Name = "lbxValidCharacters";
            this.lbxValidCharacters.Size = new System.Drawing.Size(351, 56);
            this.lbxValidCharacters.TabIndex = 1;
            // 
            // lbxPredefinedRamps
            // 
            this.lbxPredefinedRamps.FormattingEnabled = true;
            this.lbxPredefinedRamps.Location = new System.Drawing.Point(3, 25);
            this.lbxPredefinedRamps.Name = "lbxPredefinedRamps";
            this.lbxPredefinedRamps.Size = new System.Drawing.Size(351, 56);
            this.lbxPredefinedRamps.TabIndex = 0;
            // 
            // tabPageConvertImageForm
            // 
            this.tabPageConvertImageForm.Controls.Add(this.gbxSelectionArea);
            this.tabPageConvertImageForm.Controls.Add(this.gbWidgets);
            this.tabPageConvertImageForm.Controls.Add(this.cbConfirmClose);
            this.tabPageConvertImageForm.Location = new System.Drawing.Point(4, 22);
            this.tabPageConvertImageForm.Name = "tabPageConvertImageForm";
            this.tabPageConvertImageForm.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageConvertImageForm.Size = new System.Drawing.Size(391, 195);
            this.tabPageConvertImageForm.TabIndex = 3;
            this.tabPageConvertImageForm.Text = "tabPageConvertImageForm";
            this.tabPageConvertImageForm.UseVisualStyleBackColor = true;
            // 
            // gbxSelectionArea
            // 
            this.gbxSelectionArea.Controls.Add(this.btnBorderColor);
            this.gbxSelectionArea.Controls.Add(this.btnFillColor);
            this.gbxSelectionArea.Location = new System.Drawing.Point(6, 121);
            this.gbxSelectionArea.Name = "gbxSelectionArea";
            this.gbxSelectionArea.Size = new System.Drawing.Size(379, 48);
            this.gbxSelectionArea.TabIndex = 3;
            this.gbxSelectionArea.TabStop = false;
            this.gbxSelectionArea.Text = "gbxSelectionArea";
            // 
            // gbWidgets
            // 
            this.gbWidgets.Controls.Add(this.cbOutputLevels);
            this.gbWidgets.Controls.Add(this.cbOutputBrightnessContrast);
            this.gbWidgets.Controls.Add(this.cbInputBrightnessContrast);
            this.gbWidgets.Location = new System.Drawing.Point(6, 49);
            this.gbWidgets.Name = "gbWidgets";
            this.gbWidgets.Size = new System.Drawing.Size(379, 66);
            this.gbWidgets.TabIndex = 2;
            this.gbWidgets.TabStop = false;
            this.gbWidgets.Text = "gbWidgets";
            // 
            // cbOutputLevels
            // 
            this.cbOutputLevels.AutoSize = true;
            this.cbOutputLevels.Location = new System.Drawing.Point(186, 42);
            this.cbOutputLevels.Name = "cbOutputLevels";
            this.cbOutputLevels.Size = new System.Drawing.Size(92, 17);
            this.cbOutputLevels.TabIndex = 3;
            this.cbOutputLevels.Text = "Output Levels";
            this.cbOutputLevels.UseVisualStyleBackColor = true;
            // 
            // cbOutputBrightnessContrast
            // 
            this.cbOutputBrightnessContrast.AutoSize = true;
            this.cbOutputBrightnessContrast.Location = new System.Drawing.Point(6, 42);
            this.cbOutputBrightnessContrast.Name = "cbOutputBrightnessContrast";
            this.cbOutputBrightnessContrast.Size = new System.Drawing.Size(154, 17);
            this.cbOutputBrightnessContrast.TabIndex = 2;
            this.cbOutputBrightnessContrast.Text = "Output Brightness/Contrast";
            this.cbOutputBrightnessContrast.UseVisualStyleBackColor = true;
            // 
            // cbInputBrightnessContrast
            // 
            this.cbInputBrightnessContrast.AutoSize = true;
            this.cbInputBrightnessContrast.Location = new System.Drawing.Point(6, 19);
            this.cbInputBrightnessContrast.Name = "cbInputBrightnessContrast";
            this.cbInputBrightnessContrast.Size = new System.Drawing.Size(146, 17);
            this.cbInputBrightnessContrast.TabIndex = 1;
            this.cbInputBrightnessContrast.Text = "Input Brightness/Contrast";
            this.cbInputBrightnessContrast.UseVisualStyleBackColor = true;
            // 
            // cbConfirmClose
            // 
            this.cbConfirmClose.AutoSize = true;
            this.cbConfirmClose.Location = new System.Drawing.Point(71, 26);
            this.cbConfirmClose.Name = "cbConfirmClose";
            this.cbConfirmClose.Size = new System.Drawing.Size(248, 17);
            this.cbConfirmClose.TabIndex = 0;
            this.cbConfirmClose.Text = "Confirm close when output has not been saved";
            this.cbConfirmClose.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.Location = new System.Drawing.Point(174, 239);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "btnSave";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnDefault
            // 
            this.btnDefault.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDefault.Location = new System.Drawing.Point(255, 239);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(75, 23);
            this.btnDefault.TabIndex = 4;
            this.btnDefault.Text = "btnDefault";
            this.btnDefault.UseVisualStyleBackColor = true;
            // 
            // btnLoad
            // 
            this.btnLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLoad.Location = new System.Drawing.Point(93, 239);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 23);
            this.btnLoad.TabIndex = 5;
            this.btnLoad.Text = "btnLoad";
            this.btnLoad.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 170);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(77, 17);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "cbxStretch";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // cbxFlipHorizontally
            // 
            this.cbxFlipHorizontally.AutoSize = true;
            this.cbxFlipHorizontally.Location = new System.Drawing.Point(7, 19);
            this.cbxFlipHorizontally.Name = "cbxFlipHorizontally";
            this.cbxFlipHorizontally.Size = new System.Drawing.Size(113, 17);
            this.cbxFlipHorizontally.TabIndex = 14;
            this.cbxFlipHorizontally.Text = "cbxFlipHorizontally";
            this.cbxFlipHorizontally.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(6, 42);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(101, 17);
            this.checkBox3.TabIndex = 15;
            this.checkBox3.Text = "cbxFlipVertically";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // gbxFlip
            // 
            this.gbxFlip.Controls.Add(this.checkBox3);
            this.gbxFlip.Controls.Add(this.cbxFlipHorizontally);
            this.gbxFlip.Location = new System.Drawing.Point(288, 123);
            this.gbxFlip.Name = "gbxFlip";
            this.gbxFlip.Size = new System.Drawing.Size(97, 65);
            this.gbxFlip.TabIndex = 16;
            this.gbxFlip.TabStop = false;
            this.gbxFlip.Text = "gbxFlip";
            // 
            // lblPrefix
            // 
            this.lblPrefix.AutoSize = true;
            this.lblPrefix.Location = new System.Drawing.Point(119, 171);
            this.lblPrefix.Name = "lblPrefix";
            this.lblPrefix.Size = new System.Drawing.Size(43, 13);
            this.lblPrefix.TabIndex = 17;
            this.lblPrefix.Text = "lblPrefix";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(158, 168);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 18;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "None",
            "Sharpen",
            "Unsharp Mask"});
            this.comboBox1.Location = new System.Drawing.Point(6, 136);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(104, 21);
            this.comboBox1.TabIndex = 19;
            // 
            // btnFillColor
            // 
            this.btnFillColor.Location = new System.Drawing.Point(58, 19);
            this.btnFillColor.Name = "btnFillColor";
            this.btnFillColor.Size = new System.Drawing.Size(100, 23);
            this.btnFillColor.TabIndex = 0;
            this.btnFillColor.Text = "btnFillColor";
            this.btnFillColor.UseVisualStyleBackColor = true;
            // 
            // btnBorderColor
            // 
            this.btnBorderColor.Location = new System.Drawing.Point(220, 19);
            this.btnBorderColor.Name = "btnBorderColor";
            this.btnBorderColor.Size = new System.Drawing.Size(100, 23);
            this.btnBorderColor.TabIndex = 1;
            this.btnBorderColor.Text = "btnBorderColor";
            this.btnBorderColor.UseVisualStyleBackColor = true;
            // 
            // FormEditSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(423, 274);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.tabSettings);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormEditSettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormEditSettings";
            this.Load += new System.EventHandler(this.FormEditSettings_Load);
            this.tabSettings.ResumeLayout(false);
            this.tabPageInput.ResumeLayout(false);
            this.tabPageInput.PerformLayout();
            this.gbxInputBrightnessContrast.ResumeLayout(false);
            this.gbxInputBrightnessContrast.PerformLayout();
            this.tabPageOutput.ResumeLayout(false);
            this.tabPageOutput.PerformLayout();
            this.gbxOutputLevels.ResumeLayout(false);
            this.gbxOutputLevels.PerformLayout();
            this.gbxOutputBrightnessContrast.ResumeLayout(false);
            this.gbxOutputBrightnessContrast.PerformLayout();
            this.gbxSize.ResumeLayout(false);
            this.gbxSize.PerformLayout();
            this.tabPageRamps.ResumeLayout(false);
            this.tabPageConvertImageForm.ResumeLayout(false);
            this.tabPageConvertImageForm.PerformLayout();
            this.gbxSelectionArea.ResumeLayout(false);
            this.gbWidgets.ResumeLayout(false);
            this.gbWidgets.PerformLayout();
            this.gbxFlip.ResumeLayout(false);
            this.gbxFlip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TabControl tabSettings;
        private System.Windows.Forms.TabPage tabPageInput;
        private System.Windows.Forms.TabPage tabPageOutput;
        private System.Windows.Forms.TabPage tabPageRamps;
        private System.Windows.Forms.TabPage tabPageConvertImageForm;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Label lblOutputDirectory;
        private System.Windows.Forms.Button btnOutputDirectory;
        private System.Windows.Forms.TextBox tbxOutputDirectory;
        private System.Windows.Forms.CheckBox cbInputBrightnessContrast;
        private System.Windows.Forms.CheckBox cbConfirmClose;
        private System.Windows.Forms.GroupBox gbxSelectionArea;
        private System.Windows.Forms.GroupBox gbWidgets;
        private System.Windows.Forms.CheckBox cbOutputLevels;
        private System.Windows.Forms.CheckBox cbOutputBrightnessContrast;
        private System.Windows.Forms.Button btnInputDirectory;
        private System.Windows.Forms.TextBox tbxInputDirectory;
        private System.Windows.Forms.Label lblInputDirectory;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.ListBox lbxPredefinedRamps;
        private System.Windows.Forms.ListBox lbxValidCharacters;
        private System.Windows.Forms.Button btnFont;
        private System.Windows.Forms.GroupBox gbxSize;
        private System.Windows.Forms.TextBox tbxHeight;
        private System.Windows.Forms.CheckBox cbxLoadSize;
        private System.Windows.Forms.TextBox tbxWidth;
        private System.Windows.Forms.GroupBox gbxOutputBrightnessContrast;
        private System.Windows.Forms.TextBox tbxOutputContrast;
        private System.Windows.Forms.CheckBox cbxLoadOutputBC;
        private System.Windows.Forms.Label lblOutputBrightness;
        private System.Windows.Forms.TextBox tbxOutputBrightness;
        private System.Windows.Forms.Label lblOutputContrast;
        private System.Windows.Forms.GroupBox gbxInputBrightnessContrast;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox cbxLoadInputBC;
        private System.Windows.Forms.Label lblInputBrightness;
        private System.Windows.Forms.Label lblInputContrast;
        private System.Windows.Forms.GroupBox gbxOutputLevels;
        private System.Windows.Forms.TextBox tbxMed;
        private System.Windows.Forms.Label lblMed;
        private System.Windows.Forms.TextBox tbxMin;
        private System.Windows.Forms.TextBox tbxMax;
        private System.Windows.Forms.CheckBox cbxLoadOutputLevels;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.CheckBox cbxInvert;
        private System.Windows.Forms.CheckBox cbxFlipHorizontally;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox gbxFlip;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblPrefix;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button btnFillColor;
        private System.Windows.Forms.Button btnBorderColor;
    }
}