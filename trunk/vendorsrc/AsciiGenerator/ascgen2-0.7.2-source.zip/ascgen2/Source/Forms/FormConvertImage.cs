//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2007 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormConvertImage.cs,v 1.212 2007/01/26 20:01:08 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Xml;
using System.Net;
using System.Text;
using System.Threading;
using JMSoftware.CustomControl;
using JMSoftware.Widgets;
using JMSoftware.AsciiConversion;
using JMSoftware.AsciiConversion.Filters;

namespace JMSoftware.AsciiGeneratorDotNet {
	/// <summary>
	/// Main conversion form
	/// </summary>
	partial class FormConvertImage : System.Windows.Forms.Form {
        /// <summary>
        /// Constructor
        /// </summary>
        public FormConvertImage(string[] args) {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            _Args = args;
        }

        private void formMain_Load(object sender, System.EventArgs e) {
			BCWidgetImage.Visible = true;
			BCWidgetText.Visible = false;
			LevelsWidget.Visible = false;

			ReadXML(Path.GetFileNameWithoutExtension(Application.ExecutablePath) + ".xml");

			_BatchConverter = new FormBatchConvert();

			TextSettings = new TextProcessingSettings();

			Text = Variables.ProgramName + " v" + Variables.Version.GetVersion();

			pbxMain.AllowDrop = true;

			chkBlackOnWhite.Checked = !Variables.BlackTextOnWhite;
			rtbxConvertedText.BackColor = (TextSettings.IsBlackTextOnWhite) ? Color.White : Color.Black;
			rtbxConvertedText.ForeColor = (TextSettings.IsBlackTextOnWhite) ? Color.Black : Color.White;

			TextSettings.Ramp = cmbRamp.Text;

			dialogChooseFont.Font = Variables.DefaultFont;

            // remove and readd the toolstrips to get the desired layout (it adds from the bottom up)
            toolStripContainer1.TopToolStripPanel.Controls.Clear();
            toolStripContainer1.TopToolStripPanel.Join(mainMenu1);
            toolStripContainer1.TopToolStripPanel.Join(tstripButtons, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripRamp, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripCharacters, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripOutputSize, 1);

            UpdateFonts();

            cmbRamp.Items.Clear();
			cmbRamp.Items.AddRange(Variables.DefaultRamps.ToArray());

			if (Variables.CurrentSelectedRamp == -1) {
				cmbRamp.Text = Variables.CurrentRamp;
			}
			else {
				cmbRamp.SelectedIndex = Variables.CurrentSelectedRamp;
			}

			cmbRamp.Select(0, 0);	// make sure the text isn't selected
			chkGenerate.Checked = Variables.UseGeneratedRamp;

			cmbCharacters.Items.Clear();
			cmbCharacters.Items.AddRange(Variables.DefaultValidCharacters.ToArray());

			if (Variables.CurrentSelectedValidCharacters == -1) {
				cmbCharacters.Text = Variables.CurrentCharacters;
			}
			else {
				cmbCharacters.SelectedIndex = Variables.CurrentSelectedValidCharacters;
			}

			cmbCharacters.Select(0, 0);	// make sure the text isn't selected

			BCWidgetImage.BrightnessChanged +=
				new WidgetBrightnessContrast.DelegatedFunction(ApplyImageBrightness);
			BCWidgetImage.ContrastChanged +=
				new WidgetBrightnessContrast.DelegatedFunction(ApplyImageContrast);

			BCWidgetImage.Left = pnlMain.Width - BCWidgetImage.Width - 4;
			BCWidgetImage.Top = pnlMain.Height - BCWidgetImage.Height - 4;
			BCWidgetImage.MaximumBrightness = 200;
			BCWidgetImage.MinimumBrightness = -200;
			BCWidgetImage.MaximumContrast = 100;
			BCWidgetImage.MinimumContrast = -100;
			BCWidgetImage.Brightness = Variables.DefaultImageBrightness;
			BCWidgetImage.Contrast = Variables.DefaultImageContrast;

			// check if an image was loaded in the constructor
			BCWidgetImage.Enabled = pbxMain.Image != null;

			BCWidgetText.BrightnessChanged +=
				new WidgetBrightnessContrast.DelegatedFunction(ApplyTextBrightness);
			BCWidgetText.ContrastChanged +=
				new WidgetBrightnessContrast.DelegatedFunction(ApplyTextContrast);

			BCWidgetText.Left = 4;
			BCWidgetText.MaximumBrightness = 200;
			BCWidgetText.MinimumBrightness = -200;
			BCWidgetText.MaximumContrast = 100;
			BCWidgetText.MinimumContrast = -100;
			BCWidgetText.Brightness = Variables.DefaultTextBrightness;
			BCWidgetText.Contrast = Variables.DefaultTextContrast;
			BCWidgetText.Enabled = false;

			LevelsWidget.Left = 4;
			LevelsWidget.Top = pnlMain.Height - LevelsWidget.Height - 4;
			LevelsWidget.BringToFront();
			LevelsWidget.Enabled = false;
			LevelsWidget.ValueChanged += new WidgetLevels.ValueChangedEventHandler(LevelsChanged);
			LevelsWidget.Minimum = Variables.DefaultMinLevel;
			LevelsWidget.Maximum = Variables.DefaultMaxLevel;
			LevelsWidget.Median = Variables.DefaultMedianLevel;

			BCWidgetText.Top = pnlMain.Height - BCWidgetText.Height - LevelsWidget.Height - 8;

			dialogLoadImage.InitialDirectory = Variables.InitialInputDirectory;
			dialogSaveImage.InitialDirectory = Variables.InitialOutputDirectory;
			dialogSaveText.InitialDirectory = Variables.InitialOutputDirectory;
            dialogSaveColour.InitialDirectory = Variables.InitialOutputDirectory;

			UpdateUI();

			pnlMain.Controls.AddRange(new Control[] {BCWidgetImage, BCWidgetText, LevelsWidget});

			tabMain.SendToBack();

			_ClientSize = pnlMain.ClientSize;

			// load a filename if one was passed
			if (_Args.Length == 1) {
				LoadImage(_Args[0]);
			}

			tabMain.Select();

            if (Variables.CheckForNewVersions) {
                _VersionCheckThread = new Thread(new ThreadStart(CheckForNewVersion));
                _VersionCheckThread.Name = String.Format(Variables.Culture, "VersionCheckThread{0:HHmmss}", DateTime.Now);
                _VersionCheckThread.Start();
            }
		}

		/// <summary>
		/// Save the current settings as XML
		/// </summary>
		/// <param name="filename">the filename to use for the output</param>
		private bool WriteXML(string filename) {
			try {
				XmlTextWriter writer = new XmlTextWriter(filename, System.Text.Encoding.Unicode);
				writer.Formatting = Formatting.Indented;

				writer.WriteStartDocument();
				writer.WriteStartElement("ascgen2");
				writer.WriteAttributeString("version", Variables.Version.GetVersion());
                writer.WriteElementString("checkfornewversions", (Variables.CheckForNewVersions).ToString(Variables.Culture));

				writer.WriteStartElement("input");
				writer.WriteElementString("initialdirectory",
					(dialogLoadImage.FileName.Length > 0 ? Path.GetDirectoryName(dialogLoadImage.FileName) :
					(Variables.InitialInputDirectory.Length > 0 ? Variables.InitialInputDirectory : String.Empty)));

				writer.WriteStartElement("brightnesscontrast");
				writer.WriteElementString("brightness", BCWidgetImage.Brightness.ToString(Variables.Culture));
				writer.WriteElementString("contrast", BCWidgetImage.Contrast.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadImageBrightnessContrast.ToString(Variables.Culture));
				writer.WriteEndElement();   //brightnesscontrast
				writer.WriteEndElement();   //input

				writer.WriteStartElement("output");
				writer.WriteElementString("initialdirectory",
					(dialogSaveText.FileName.Length > 0 ? Path.GetDirectoryName(dialogSaveText.FileName) :
					(dialogSaveImage.FileName.Length > 0 ? Path.GetDirectoryName(dialogSaveImage.FileName) :
                    (dialogSaveColour.FileName.Length > 0 ? Path.GetDirectoryName(dialogSaveColour.FileName) :
					(Variables.InitialOutputDirectory.Length > 0 ? Variables.InitialOutputDirectory : String.Empty)))));

				writer.WriteElementString("prefix", Variables.Prefix);

				writer.WriteStartElement("size");

				int width = TextSettings.Width, height = TextSettings.Height;
				if (_Locked) {
					if (_bWidthChangedLast) {
						if (width == -1) width = 150;
						height = -1;
					}
					else {
						if (height == -1) height = 150;
						width = -1;
					}
				}

				writer.WriteElementString("width", width.ToString(Variables.Culture));
				writer.WriteElementString("height", height.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadOutputSize.ToString(Variables.Culture));
				writer.WriteEndElement();   //size

				writer.WriteStartElement("font");
				writer.WriteElementString("name", TextSettings.Font.Name);
				writer.WriteElementString("size", TextSettings.Font.Size.ToString(Variables.Culture));
				writer.WriteElementString("italic", TextSettings.Font.Italic.ToString(Variables.Culture));
				writer.WriteElementString("bold", TextSettings.Font.Bold.ToString(Variables.Culture));
				writer.WriteElementString("strikeout", TextSettings.Font.Strikeout.ToString(Variables.Culture));
				writer.WriteElementString("underline", TextSettings.Font.Underline.ToString(Variables.Culture));
				writer.WriteEndElement();	//font

				writer.WriteStartElement("brightnesscontrast");
				writer.WriteElementString("brightness", TextSettings.Brightness.ToString(Variables.Culture));
				writer.WriteElementString("contrast", TextSettings.Brightness.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadTextBrightnessContrast.ToString(Variables.Culture));
				writer.WriteEndElement();   //brightnesscontrast

				writer.WriteStartElement("levels");
				writer.WriteElementString("min", TextSettings.Levels.Minimum.ToString(Variables.Culture));
				writer.WriteElementString("med", TextSettings.Levels.Median.ToString(Variables.Culture));
				writer.WriteElementString("max", TextSettings.Levels.Maximum.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadLevels.ToString(Variables.Culture));
				writer.WriteEndElement();   //levels
				writer.WriteElementString("stretch", TextSettings.Stretch.ToString(Variables.Culture));
				writer.WriteElementString("sharpen", TextSettings.Sharpen.ToString(Variables.Culture));
				writer.WriteElementString("unsharp", TextSettings.Unsharp.ToString(Variables.Culture));
				writer.WriteElementString("fliphorizontally", TextSettings.FlipHorizontally.ToString(Variables.Culture));
				writer.WriteElementString("flipvertically", TextSettings.FlipVertically.ToString(Variables.Culture));
				writer.WriteElementString("invertcolors", (!TextSettings.IsBlackTextOnWhite).ToString(Variables.Culture));
				writer.WriteEndElement();   //output

				writer.WriteStartElement("asciiramps");
				foreach (string s in cmbRamp.Items) {
					writer.WriteElementString("ramp", s);
				}

				writer.WriteElementString("selectedramp", cmbRamp.SelectedIndex.ToString(Variables.Culture));
				writer.WriteElementString("currentramp", cmbRamp.SelectedIndex == -1 ? cmbRamp.Text : String.Empty);
				writer.WriteEndElement();   //asciiramps

				writer.WriteStartElement("rampgeneration");
				writer.WriteElementString("generate", TextSettings.IsGeneratedRamp.ToString(Variables.Culture));

				foreach (string s in cmbCharacters.Items) {
					writer.WriteElementString("validcharacters", s);
				}

				writer.WriteElementString("selectedcharacters", cmbCharacters.SelectedIndex.ToString(Variables.Culture));
				writer.WriteElementString("currentcharacters", cmbCharacters.SelectedIndex == -1 ? cmbCharacters.Text : String.Empty);
				writer.WriteEndElement();   //rampgeneration

				writer.WriteStartElement(this.Name);
				writer.WriteElementString("showimagebrightnesscontrast", (!BCWidgetImage.Hidden).ToString(Variables.Culture));
				writer.WriteElementString("showtextbrightnesscontrast", (!BCWidgetText.Hidden).ToString(Variables.Culture));
				writer.WriteElementString("showtextlevels", (!LevelsWidget.Hidden).ToString(Variables.Culture));
				writer.WriteElementString("selectionbordercolor", ColorTranslator.ToHtml(pbxMain.SelectionBorderColor));
				writer.WriteElementString("selectionfillcolor", ColorTranslator.ToHtml(pbxMain.SelectionFillColor));
				writer.WriteElementString("confirmclose", (Variables.ConfirmOnClose).ToString(Variables.Culture));
				writer.WriteEndElement();   //mainform

				writer.WriteEndElement();   //ascgen2
				writer.WriteEndDocument();

				writer.Flush();
				writer.Close();

				return true;
			}
			catch (Exception e) {
				MessageBox.Show(e.Message, "Error");
				return false;
			}
		}

		/// <summary>
		/// Read the default settings from an XML file
		/// </summary>
		/// <param name="filename">the filename to read from</param>
		private bool ReadXML(string filename) {
			XmlDocument doc = new XmlDocument();

			try {
				doc.Load(filename);

				// check doc.DocumentElement.Attributes["version"]

                Variables.CheckForNewVersions = ReadNode(doc.SelectSingleNode("ascgen2/checkfornewversions"), Variables.CheckForNewVersions);

				Variables.InitialInputDirectory = ReadNode(doc.SelectSingleNode("ascgen2/input/initialdirectory"),
					Variables.InitialInputDirectory, true);

				Variables.LoadImageBrightnessContrast = ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/load"),
					Variables.LoadImageBrightnessContrast);

				if (Variables.LoadImageBrightnessContrast) {
					Variables.DefaultImageBrightness = ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/brightness"),
						-200, 200, Variables.DefaultImageBrightness);

					Variables.DefaultImageContrast = ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/contrast"),
						-100, 100, Variables.DefaultImageContrast);
				}

				Variables.InitialOutputDirectory = ReadNode(doc.SelectSingleNode("ascgen2/output/initialdirectory"),
					Variables.InitialOutputDirectory, true);

				Variables.Prefix = ReadNode(doc.SelectSingleNode("ascgen2/output/prefix"),
					Variables.Prefix, true);

				Variables.LoadOutputSize = ReadNode(doc.SelectSingleNode("ascgen2/output/size/load"),
					Variables.LoadOutputSize);

				if (Variables.LoadOutputSize) {
					Variables.DefaultWidth = ReadNode(doc.SelectSingleNode("ascgen2/output/size/width"),
						-1, 999, Variables.DefaultWidth);

					if (Variables.DefaultWidth == 0) Variables.DefaultWidth = 1;

					Variables.DefaultHeight = ReadNode(doc.SelectSingleNode("ascgen2/output/size/height"),
						-1, 999, Variables.DefaultHeight);

					if (Variables.DefaultHeight == 0) Variables.DefaultHeight = 1;

					if (Variables.DefaultWidth == -1 && Variables.DefaultHeight == -1) {
						Variables.DefaultWidth = 150;
					}
				}

				FontStyle style = FontStyle.Regular;

				if (ReadNode(doc.SelectSingleNode("ascgen2/output/font/italic"), Variables.DefaultFont.Italic)) {
					style = style | FontStyle.Italic;
				}

				if (ReadNode(doc.SelectSingleNode("ascgen2/output/font/bold"), Variables.DefaultFont.Bold)) {
					style = style | FontStyle.Bold;
				}

				if (ReadNode(doc.SelectSingleNode("ascgen2/output/font/strikeout"), Variables.DefaultFont.Strikeout)) {
					style = style | FontStyle.Strikeout;
				}

				if (ReadNode(doc.SelectSingleNode("ascgen2/output/font/underline"), Variables.DefaultFont.Underline)) {
					style = style | FontStyle.Underline;
				}

				Variables.DefaultFont = new Font(
					ReadNode(doc.SelectSingleNode("ascgen2/output/font/name"), Variables.DefaultFont.Name, false),
					ReadNode(doc.SelectSingleNode("ascgen2/output/font/size"), 1f, 200f, Variables.DefaultFont.Size),
					style);

				cbxLocked.Checked = (Variables.DefaultWidth == -1 ^ Variables.DefaultHeight == -1);

				Variables.LoadTextBrightnessContrast = ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/load"),
					Variables.LoadTextBrightnessContrast);

				if (Variables.LoadTextBrightnessContrast) {
					Variables.DefaultTextBrightness = ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/brightness"),
						-200, 200, Variables.DefaultTextBrightness);

					Variables.DefaultTextContrast = ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/contrast"),
						-100, 100, Variables.DefaultTextContrast);
				}

				Variables.LoadLevels = ReadNode(doc.SelectSingleNode("ascgen2/output/levels/load"), Variables.LoadLevels);

				if (Variables.LoadLevels) {
					Variables.DefaultMinLevel = ReadNode(doc.SelectSingleNode("ascgen2/output/levels/min"),
						0, 254, Variables.DefaultMinLevel);

					Variables.DefaultMaxLevel = ReadNode(doc.SelectSingleNode("ascgen2/output/levels/max"),
						Variables.DefaultMinLevel + 1, 255, Variables.DefaultMaxLevel);

					Variables.DefaultMedianLevel = ReadNode(doc.SelectSingleNode("ascgen2/output/levels/med"),
						0.0f, 1.0f, Variables.DefaultMedianLevel);
				}

				Variables.Stretch = ReadNode(doc.SelectSingleNode("ascgen2/output/stretch"), Variables.Stretch);

				Variables.Sharpen = ReadNode(doc.SelectSingleNode("ascgen2/output/sharpen"), Variables.Sharpen);

				Variables.UnsharpMask = ReadNode(doc.SelectSingleNode("ascgen2/output/unsharp"), Variables.UnsharpMask);

				Variables.FlipHorizontally = ReadNode(doc.SelectSingleNode("ascgen2/output/fliphorizontally"), Variables.FlipHorizontally);

				Variables.FlipVertically = ReadNode(doc.SelectSingleNode("ascgen2/output/flipvertically"), Variables.FlipVertically);

				Variables.BlackTextOnWhite = !ReadNode(doc.SelectSingleNode("ascgen2/output/invertcolors"), !Variables.BlackTextOnWhite);

				XmlNodeList nodes = doc.SelectNodes("ascgen2/asciiramps/ramp");
				if (nodes != null) {
					ArrayList ramps = new ArrayList(nodes.Count);

					foreach (XmlNode node in nodes) {
						if (node.InnerText.Length > 0) {
							ramps.Add(node.InnerText);
						}
					}

					if (ramps.Count > 0) {
						Variables.DefaultRamps = ramps;
					}
				}

				Variables.CurrentSelectedRamp = ReadNode(doc.SelectSingleNode("ascgen2/asciiramps/selectedramp"),
					-1, Variables.DefaultRamps.Count - 1, Variables.CurrentSelectedRamp);

				if (Variables.CurrentSelectedRamp == -1) {
					Variables.CurrentRamp = ReadNode(doc.SelectSingleNode("ascgen2/asciiramps/currentramp"),
						Variables.CurrentRamp, true);
				}

				if (Variables.CurrentSelectedRamp == -1 && Variables.CurrentRamp.Length == 0) {
					Variables.CurrentSelectedRamp = 0;
				}

				Variables.UseGeneratedRamp = ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/generate"), Variables.UseGeneratedRamp);

				nodes = doc.SelectNodes("ascgen2/rampgeneration/validcharacters");
				if (nodes != null) {
					ArrayList validchars = new ArrayList(nodes.Count);

					foreach (XmlNode node in nodes) {
						if (node.InnerText.Length > 0) {
							validchars.Add(node.InnerText);
						}
					}

					if (validchars.Count > 0) {
						Variables.DefaultValidCharacters = validchars;
					}
				}

				Variables.CurrentSelectedValidCharacters = ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/selectedcharacters"),
					-1, Variables.DefaultValidCharacters.Count - 1, Variables.CurrentSelectedValidCharacters);

				if (Variables.CurrentSelectedValidCharacters == -1) {
					Variables.CurrentCharacters = ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/currentcharacters"),
						Variables.CurrentCharacters, true);
				}

				if (Variables.CurrentSelectedValidCharacters == -1 && Variables.CurrentCharacters.Length == 0) {
					Variables.CurrentSelectedValidCharacters = 0;
				}

				BCWidgetImage.Hidden = !ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/showimagebrightnesscontrast"), !BCWidgetImage.Hidden);
				if (BCWidgetImage.Visible && BCWidgetImage.Hidden) BCWidgetImage.Visible = false;

				BCWidgetText.Hidden = !ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/showtextbrightnesscontrast"), !BCWidgetText.Hidden);
				if (BCWidgetText.Visible && BCWidgetText.Hidden) BCWidgetText.Visible = false;

				LevelsWidget.Hidden = !ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/showtextlevels"), !LevelsWidget.Hidden);
				if (LevelsWidget.Visible && LevelsWidget.Hidden) LevelsWidget.Visible = false;

				pbxMain.SelectionBorderColor = ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/selectionbordercolor"),
					pbxMain.SelectionBorderColor);

				pbxMain.SelectionFillColor = ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/selectionfillcolor"),
					pbxMain.SelectionFillColor);

				Variables.ConfirmOnClose = ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/confirmclose"), Variables.ConfirmOnClose);

				return true;
			}
			catch(System.Xml.XmlException) {
				MessageBox.Show(Resource.GetString("Invalid settings file. Please delete it or save a new one"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			catch (System.IO.FileNotFoundException) {
				return false;
			}
		}

		private int ReadNode(XmlNode node, int min, int max, int current) {
			int result = current;

			if (node != null) {
				try {
					result = XmlConvert.ToInt32(node.InnerText);

					if (result < min) result = min;
					if (result > max) result = max;
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		private float ReadNode(XmlNode node, float min, float max, float current) {
			float result = current;

			if (node != null) {
				try {
					result = (float)XmlConvert.ToDouble(node.InnerText);

					if (result < min) result = min;
					if (result > max) result = max;
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		private bool ReadNode(XmlNode node, bool current) {
			bool result = current;

			if (node != null) {
				try {
					result = XmlConvert.ToBoolean(node.InnerText.ToLower(Variables.Culture));
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		private string ReadNode(XmlNode node, string current, bool allowempty) {
			if (node != null) {
				return (!allowempty && (node.InnerText.Length == 0)) ? current : node.InnerText;
			}
			else {
				return current;
			}
		}

		private Color ReadNode(XmlNode node, Color current) {
			Color result = current;

			if (node != null && node.InnerText.Length > 0) {
				try {
					result = ColorTranslator.FromHtml(node.InnerText);
				}
				catch (System.Exception) {
				}
			}

			return result;
		}

		private void ApplyImageBrightness() {
			pbxMain.Brightness = (float)BCWidgetImage.Brightness / (float)255;
			_InputChanged = true;
			_ImageSaved = false;
		}

		private void ApplyImageContrast() {
			pbxMain.Contrast = ((float)BCWidgetImage.Contrast / (float)113) + 1f;
			_InputChanged = true;
			_ImageSaved = false;
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			menuFile.Text = Resource.GetString("&File");
			menuFileLoad.Text = Resource.GetString("&Load Image") + "...";
			menuFileClose.Text = Resource.GetString("&Close");
			menuFileSave.Text = Resource.GetString("&Save") + "...";
			menuFileSaveAsImage.Text = Resource.GetString("Save as an &Image") + "...";
            menuFileSaveAsColourText.Text = Resource.GetString("Save as Colour Text") + "...";
			menuFileExit.Text = Resource.GetString("E&xit");
			menuFileImportClipboard.Text = Resource.GetString("I&mport from Clipboard");
			menuFileBatchConversion.Text = Resource.GetString("Batch Conversion") + "...";

			menuEdit.Text = "&" + Resource.GetString("Edit");
			menuEditFlipHorizontal.Text = Resource.GetString("Flip Horizontally");
			menuEditFlipVertical.Text = Resource.GetString("Flip Vertically");
			menuEditOutput.Text = Resource.GetString("Output");
			menuEditSharpeningMethod.Text = Resource.GetString("Sharpening Method");
			menuEditSharpeningMethodNone.Text = Resource.GetString("None");
			menuEditSharpeningMethodSharpen.Text = Resource.GetString("Sharpen");
			menuEditSharpeningMethodUnsharp.Text = Resource.GetString("Unsharp Mask");
			menuEditFontsSpecifyCharSize.Text = Resource.GetString("Specify Character Size") + "...";
			menuEditStretch.Text = Resource.GetString("Stretch");
            menuEditRamps.Text = Resource.GetString("Ramps");
			menuEditRampsValidChars.Text = Resource.GetString("Valid Characters") + "...";
            menuEditRampsCopyRamp.Text = Resource.GetString("Copy Ramp to Clipboard");
            menuEditFontsFont.Text = Resource.GetString("Font") + "...";
            menuEditFonts.Text = Resource.GetString("Fonts");
			menuEditSaveSettings.Text = Resource.GetString("Save Settings as Default");

			menuView.Text = Resource.GetString("&View");
			menuViewImage.Text = Resource.GetString("Image");
			menuViewText.Text = Resource.GetString("Text");
			menuViewICBC.Text = Resource.GetString("Image") + " " +
				Resource.GetString("Brightness") + "/" + Resource.GetString("Contrast");
			menuViewTCBC.Text = Resource.GetString("Text") + " " +
				Resource.GetString("Brightness") + "/" + Resource.GetString("Contrast");
			menuViewLevels.Text = Resource.GetString("Levels Adjustment");
			menuViewFullScreen.Text = Resource.GetString("&Full Screen");

			menuHelp.Text = Resource.GetString("&Help");
            menuHelpDonate.Text = Resource.GetString("&Donate") + "...";
            menuHelpReportBug.Text = Resource.GetString("Report a Bug") + "...";
            menuHelpRequestFeature.Text = Resource.GetString("Request a Feature") + "...";
			menuHelpAbout.Text = Resource.GetString("&About") + "...";

			lblOutputSize.Text = Resource.GetString("Size") + ":";
			lblRamp.Text = Resource.GetString("Ramp") + ":";
			btnFont.Text = Resource.GetString("Font") + "...";
			chkGenerate.Text = Resource.GetString("Auto");

			lblCharacters.Text = Resource.GetString("Characters") + ":";

			cmenuTextCopy.Text = Resource.GetString("Copy");
			cmenuTextSelectAll.Text = Resource.GetString("Select All");
			cmenuTextSelectNone.Text = Resource.GetString("Select None");
			cmenuTextStretch.Text = Resource.GetString("Stretch");
			cmenuTextSharpening.Text = Resource.GetString("Sharpening Method");
			cmenuTextSharpeningNone.Text = Resource.GetString("None");
			cmenuTextSharpeningSharpen.Text = Resource.GetString("Sharpen");
			cmenuTextSharpeningUnsharp.Text = Resource.GetString("Unsharp Mask");
			cmenuTextFont.Text = Resource.GetString("Font") + "...";
			cmenuTextVertical.Text = Resource.GetString("Flip Vertically");
			cmenuTextHorizontal.Text = Resource.GetString("Flip Horizontally");

			cmenuImageLoad.Text =  Resource.GetString("&Load Image") + "...";
			cmenuImageSelectNone.Text = Resource.GetString("Remove Selection");
			cmenuImageSelectionLocked.Text = Resource.GetString("Lock Selected Area");
			cmenuImageSelectionShow.Text = Resource.GetString("Fill Selected Area");
			cmenuImageSelectionFillColor.Text = Resource.GetString("Selection Area Fill Colour") + "...";
			cmenuImageSelectionBorderColor.Text = Resource.GetString("Selection Area Border Colour") + "...";

			dialogSaveText.Title = Resource.GetString("Save to a Text File") + "...";

			tabPageImage.Text = Resource.GetString("Image");
			tabPageText.Text = Resource.GetString("Text");

			if (pbxMain.Image != null) {
				tabPageImage.Text += ": " + Path.GetFileName(_strFilename);
				tabPageText.Text += ": " + Variables.Prefix + Path.GetFileNameWithoutExtension(_strFilename) + ".txt";
			}

			pbxMain.Text = Resource.GetString("Doubleclick to load an image, or drag and drop an image here.") +
				Environment.NewLine + Environment.NewLine + Resource.GetString("Click and drag on an image to select an area");

			dialogLoadImage.Filter =
				Resource.GetString("Image Files") + "|*.bmp;*.rle;*.dib;*.exif;*.gif;*.jpg;*.jpeg;*.jpe;*.png;*.tif;*.tiff;*.wmf;*.emf|" +
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("Exchangeable Image Files") + " (*.exif)|*.exif|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" +
				Resource.GetString("Windows Metafile Images") + " (*.emf, *.wmf)|*.emf;*.wmf|" +
				Resource.GetString("All Files") + " (*.*)|*.*";

			dialogSaveImage.Filter =
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" + 
				Resource.GetString("All Files") + " (*.*)|*.*";

			dialogSaveImage.FilterIndex = 2;	// gif = smallest

            dialogSaveText.Filter = Resource.GetString("Plain Text") + "|*.txt|" +
                Resource.GetString("Plain Text") + " (Unicode)|*.txt|" +
                Resource.GetString("Rich Text") + "|*.rtf|" +
                "XHTML 1.1|*.html|" +
                Resource.GetString("All Files") + "|*.*";
            dialogSaveText.FilterIndex = 1;

            dialogSaveColour.Filter = "XHTML 1.1 (8-bit)|*.html|" +
                Resource.GetString("Rich Text") + " (8-bit)|*.rtf|" +
                "XHTML 1.1 (24-bit)|*.html|" +
                Resource.GetString("Rich Text") + " (24-bit)|*.rtf";
            dialogSaveColour.FilterIndex = 1;

			BCWidgetText.Text = Resource.GetString("Text");
			BCWidgetImage.Text = Resource.GetString("Image");
			LevelsWidget.Text = Resource.GetString("Adjust Levels");

			BCWidgetText.UpdateUI();
			BCWidgetImage.UpdateUI();
		}

		/// <summary>
		/// Load an image into the picturebox, and setup the form etc.
		/// </summary>
		/// <param name="image">The image to load</param>
		/// <returns>Did everything work correctly?</returns>
		public bool LoadImage(Image image) {
			if (CloseImage()) {
				pbxMain.DrawingImage = false;

				pbxMain.Image = image;

				tabPageImage.Text = Resource.GetString("Image") + ": " + Path.GetFileName(_strFilename);

				pbxMain.DrawingImage = true;

				if (tbxWidth.Text.Length == 0 && tbxHeight.Text.Length == 0) {
					if (Variables.DefaultWidth > 0 && Variables.DefaultHeight > 0) {
						cbxLocked.Checked = false;
						Locked = false;

						_bSizeChanging = true;
						tbxWidth.Text = Variables.DefaultWidth.ToString(Variables.Culture);
						TextSettings.Width = Variables.DefaultWidth;
						tbxHeight.Text = Variables.DefaultHeight.ToString(Variables.Culture);
						TextSettings.Height = Variables.DefaultHeight;
						_bSizeChanging = false;

						_bWidthChangedLast = true;
					}
					else {
						if (Variables.DefaultWidth > 0 && Variables.DefaultHeight == -1) {
							_bSizeChanging = true;
							tbxWidth.Text = Variables.DefaultWidth.ToString(Variables.Culture);
							TextSettings.Width = Variables.DefaultWidth;
							TextSettings.Height = -1;
							_bSizeChanging = false;
							_bWidthChangedLast = true;
						}
						else if (Variables.DefaultHeight > 0 && Variables.DefaultWidth == -1) {
							_bSizeChanging = true;
							tbxHeight.Text = Variables.DefaultHeight.ToString(Variables.Culture);
							TextSettings.Height = Variables.DefaultHeight;
							TextSettings.Width = -1;
							_bSizeChanging = false;
							_bWidthChangedLast = false;
						}
						else {
							MessageBox.Show(Resource.GetString("DefaultWidth and/or DefaultHeight must be > 0"),
								Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

							_bSizeChanging = true;
							tbxWidth.Text = "150";
							TextSettings.Width = 150;
							TextSettings.Height = -1;
							_bSizeChanging = false;
							_bWidthChangedLast = true;
						}

						Locked = true;
					}
				}

				UpdateValues();

				LevelsWidget.Enabled = BCWidgetImage.Enabled = BCWidgetText.Enabled = true;
				BCWidgetImage.Refresh();
				BCWidgetText.Refresh();

				return DoConvert();
			}
			else {
				return false;
			}
		}

		/// <summary>
		/// Load the specified image into the picturebox, and setup the form etc.
		/// </summary>
		/// <param name="filename">Path to the image</param>
		/// <returns>Did the image load correctly?</returns>
		public bool LoadImage(string filename) {
			try {
                Image image;

                using (Image loadedimage = Image.FromFile(filename)) {
                    Size size;

                    if (loadedimage.GetType() == typeof(Metafile)) {
                        size = new Size(1000, (int)((1000f * ((float)loadedimage.Height / (float)loadedimage.Width)) + 0.5f));
                    }
                    else {
                        size = new Size(loadedimage.Width, loadedimage.Height);
                    }

                    image = new Bitmap(size.Width, size.Height);

                    using (Graphics g = Graphics.FromImage(image)) {
                        g.Clear(Color.White);
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        g.DrawImage(loadedimage, 0, 0, size.Width, size.Height);
                    }
                }

				dialogLoadImage.FileName = _strFilename = filename;

				return LoadImage(image);
			}
			catch (OutOfMemoryException) {	// Catch any bad image files					
				MessageBox.Show(Resource.GetString("Unknown or Unsupported File"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}
			catch (FileNotFoundException) {
				MessageBox.Show(Resource.GetString("File Not Found"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}
		}

		/// <summary>
		/// Process the conversion
		/// </summary>
		/// <returns>Did the conversion succeed?</returns>
		private bool DoConvert() {
			// no image to convert
			if (pbxMain.Image == null) {
				return false;
			}

			// if conversion is unnecessary
			if(!_InputChanged) {
				return true;
			}

			if (TextSettings.Width == -1 || TextSettings.Height == -1) {
				rtbxConvertedText.Text = String.Empty;

				tbxWidth.Focus();

				return false;
			}

			Rectangle Section = (pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
				new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) : pbxMain.SelectedArea;

			// convert the image into values
			_Values = AscgenConverter.ImageToTextValues((Bitmap)pbxMain.Image,
				new Size(TextSettings.Width, TextSettings.Height),
				JMSoftware.Matrices.BrightnessContrast(pbxMain.Brightness, pbxMain.Contrast), Section);

			if (_Values == null) {
				rtbxConvertedText.Lines = new string[] {""};

				MessageBox.Show(Resource.GetString("Out of Memory, Could not convert the image"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}

			UpdateLevelsArray();

			ApplyTextEffects();

			tabPageText.Text = Resource.GetString("Text") + ": " +
				Variables.Prefix + Path.GetFileNameWithoutExtension(_strFilename) + ".txt";

			_InputChanged = false;
			_ImageSaved = false;

			return true;
		}

		private void ApplyTextEffects() {
			if (_Values == null) {
				return;
			}

			rtbxConvertedText.Lines = TextSettings.Apply(_Values);

			rtbxConvertedText.Update();
		}

		private void UpdateLevelsArray() {
			if (_Values == null) return;

			byte[,] values;

			if (TextSettings.Brightness != 0 || TextSettings.Contrast != 0) {
                BrightnessContrast filter = new BrightnessContrast(
                    TextSettings.IsBlackTextOnWhite ? TextSettings.Brightness : -TextSettings.Brightness,
                    TextSettings.IsBlackTextOnWhite ? TextSettings.Contrast : -TextSettings.Contrast);

                values = filter.Apply(_Values);
			}
			else {
				values = _Values;
			}

			if (TextSettings.Stretch) {
                Stretch filter = new Stretch();
				values = filter.Apply(values);
			}

			// Update the levels graph
			int[] Levels = new int[256];

			for (int y = 0; y < TextSettings.Height; y++) {
				for (int x = 0; x < TextSettings.Width; x++) {
					Levels[(int)values[x, y]]++;
				}
			}

			LevelsWidget.Array = Levels;
		}

		private void pbxMain_DragOver(object sender, System.Windows.Forms.DragEventArgs e) {
			// if only one filename is being dragged
			if (e.Data.GetDataPresent("FileNameW") && ((string[])e.Data.GetData(DataFormats.FileDrop)).Length == 1) {
				e.Effect = DragDropEffects.Copy;
			}
			else {
				e.Effect = DragDropEffects.None;
			}
		}

		private void pbxMain_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);

			if (fileNames.Length == 1) {
				LoadImage(fileNames[0]);
			}
		}

		private void menuFileExit_Click(object sender, System.EventArgs e) {
			Close();
		}

		private void menuFileSave_Click(object sender, System.EventArgs e) {
			SaveTextDialog();
		}

		private bool SaveTextDialog() {
			bool result = false;

			if (CheckIfSavable()) {
				tabMain.SelectedTab = tabPageText;

				dialogSaveText.FileName = Variables.Prefix + Path.GetFileNameWithoutExtension(_strFilename);

				if (dialogSaveText.ShowDialog() == DialogResult.OK) {
                    RichTextBoxStreamType StreamType = RichTextBoxStreamType.PlainText;
                    bool saved = false;

					switch (dialogSaveText.FilterIndex) {
						case 1:	// plain text
							StreamType = RichTextBoxStreamType.PlainText;
							break;

						case 2:	// plain text (unicode)
							StreamType = RichTextBoxStreamType.UnicodePlainText;
							break;

						case 3:	// rich text
							StreamType = RichTextBoxStreamType.RichText;
							break;

                        case 4: // XHTML
                            using (StreamWriter writer = new StreamWriter(dialogSaveText.FileName)) {
                                writer.Write(CreateHTML(rtbxConvertedText.Lines, null,
                                    TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black));
                            }

                            saved = true;
                            break;
					}

                    if (!saved) {
                        rtbxConvertedText.SaveFile(dialogSaveText.FileName, StreamType);
                    }

					result = true;
					_ImageSaved = true;
				}
			}

			return result;
		}

		/// <summary>
		/// Update and check if the text image is valid
		/// </summary>
		/// <returns>Is it ok for the text image to be saved?</returns>
		private bool CheckIfSavable() {
			if (!DoConvert()) {
				if (rtbxConvertedText.Text == null || rtbxConvertedText.Text.Length == 0) {
					MessageBox.Show(this, Resource.GetString("Invalid Output Size"),
						Resource.GetString("Error"),
						MessageBoxButtons.OK, MessageBoxIcon.Error);
				}

				return false;
			}
			else {
				if (TextSettings.Ramp.Length < 1) {
					MessageBox.Show(this, Resource.GetString("Invalid ASCII Ramp"),
						Resource.GetString("Error"),
						MessageBoxButtons.OK, MessageBoxIcon.Error);

					cmbRamp.Focus();

					return false;
				}
			}

			return true;
		}

		private void menuFileLoad_Click(object sender, System.EventArgs e) {
			LoadDialog();
		}

		/// <summary>
		/// Show the load dialog, and process its result
		/// </summary>
		private void LoadDialog() {
			// show the load image dialog and check its result
			if (dialogLoadImage.ShowDialog() == DialogResult.OK) {
				LoadImage(dialogLoadImage.FileName);
			}
		}

		private void cmbSharpening_SelectionChangeCommitted(object sender, System.EventArgs e) {
			ApplyTextEffects();
		}

		private void menuFileSaveAsImage_Click(object sender, System.EventArgs e) {
			if (CheckIfSavable()) {
				tabMain.SelectedTab = tabPageText;

				using (TextImageMagnificationDialog dialogChooseTextZoom = new TextImageMagnificationDialog(TextSettings.Font)) {
					dialogChooseTextZoom.TextColor = TextSettings.IsBlackTextOnWhite ? Color.Black : Color.White;
					dialogChooseTextZoom.BackgroundColor = TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black;

					dialogChooseTextZoom.InputSize =
						FontFunctions.MeasureText(rtbxConvertedText.Text, TextSettings.Font);

					if (dialogChooseTextZoom.ShowDialog() == DialogResult.OK) {
						dialogSaveImage.FileName = Variables.Prefix + Path.GetFileNameWithoutExtension(_strFilename);

						if (dialogSaveImage.ShowDialog() == DialogResult.OK) {
							string filename = dialogSaveImage.FileName;
							string extension = Path.GetExtension(filename).ToLower(Variables.Culture);

							switch (dialogSaveImage.FilterIndex) {
								case 1:
									if (extension != ".bmp" && extension != ".rle" && extension != ".dib") {
										filename += ".bmp";
									}

									break;

								case 2:
									if (extension != ".gif") {
										filename += ".gif";
									}

									break;

								case 3:
									if (extension != ".jpg" && extension != ".jpeg" && extension != ".jpe") {
										filename += ".jpg";
									}

									break;

								case 4:
									if (extension != ".png") {
										filename += ".png";
									}

									break;

								case 5:
									if (extension != ".tif") {
										filename += ".tif";
									}

									break;
							}

							AscgenConverter.SaveTextAsImage(rtbxConvertedText.Text,
								filename, TextSettings.Font,
								dialogChooseTextZoom.TextColor, dialogChooseTextZoom.BackgroundColor,
								dialogChooseTextZoom.Value, true);
						}
					}
				}
			}
		}

		private void menuHelpAbout_Click(object sender, System.EventArgs e) {
			using (AboutDialog frmAbout = new AboutDialog()) {
				frmAbout.ShowDialog();
			}
		}

		private void menuFile_Popup(object sender, System.EventArgs e) {
			menuFileSave.Enabled =
			    menuFileSaveAsImage.Enabled =
			    menuFileClose.Enabled =
                (pbxMain.Image != null);

            menuFileSaveAsColourText.Enabled = TextSettings.IsFixedWidth && pbxMain.Image != null;

            // enable the import item if an image is on the clipboard
			IDataObject data = Clipboard.GetDataObject();
			menuFileImportClipboard.Enabled = data.GetDataPresent(DataFormats.Bitmap, true);
		}

		private void tabMain_SelectedIndexChanged(object sender, System.EventArgs e) {
			if (tabMain.SelectedTab == tabPageText) {
				DoConvert();

				BCWidgetImage.Visible = false;
				BCWidgetText.Visible = (true && !BCWidgetText.Hidden);
				LevelsWidget.Visible = (true && !LevelsWidget.Hidden);
			}
			else {
				BCWidgetImage.Visible = (true && !BCWidgetImage.Hidden);
				BCWidgetText.Visible = false;
				LevelsWidget.Visible = false;
			}
		}

		private void pbxMain_DoubleClick(object sender, System.EventArgs e) {
			LoadDialog();
		}

		private void cmenuCopy_Click(object sender, System.EventArgs e) {
			rtbxConvertedText.Copy();
		}

		private void cmenuSelectAll_Click(object sender, System.EventArgs e) {
			rtbxConvertedText.SelectAll();
		}

		private void cmenuSelectNone_Click(object sender, System.EventArgs e) {
			rtbxConvertedText.Select(rtbxConvertedText.SelectionStart + rtbxConvertedText.SelectionLength, 0);
		}

		private void contextMenuText_Popup(object sender, System.EventArgs e) {
			cmenuTextCopy.Enabled = cmenuTextSelectNone.Enabled = (rtbxConvertedText.SelectionLength > 0);

			cmenuTextFont.Enabled = cmenuTextSelectAll.Enabled = (rtbxConvertedText.Lines.Length > 0);

			cmenuTextStretch.Checked = TextSettings.Stretch;

			cmenuTextStretch.Enabled = cmenuTextSharpening.Enabled =
				cmenuTextSharpeningNone.Enabled = cmenuTextSharpeningSharpen.Enabled =
				cmenuTextSharpeningUnsharp.Enabled =
				cmenuTextHorizontal.Enabled = cmenuTextVertical.Enabled =
				(pbxMain.Image != null);

			cmenuTextSharpeningNone.Checked = !TextSettings.Sharpen && !TextSettings.Unsharp;
			cmenuTextSharpeningSharpen.Checked = TextSettings.Sharpen;
			cmenuTextSharpeningUnsharp.Checked = TextSettings.Unsharp;

			cmenuTextHorizontal.Checked = TextSettings.FlipHorizontally;
			cmenuTextVertical.Checked = TextSettings.FlipVertically;
		}

		private void cmenuLoad_Click(object sender, System.EventArgs e) {
			LoadDialog();
		}

		private void cmenuTextSharpeningNone_Click(object sender, System.EventArgs e) {
			TextSettings.Unsharp = TextSettings.Sharpen = false;
			ApplyTextEffects();
		}

		private void cmenuTextSharpeningSharpen_Click(object sender, System.EventArgs e) {
			TextSettings.Sharpen = true;
			TextSettings.Unsharp = false;
			ApplyTextEffects();
		}

		private void cmenuTextSharpeningUnsharp_Click(object sender, System.EventArgs e) {
			TextSettings.Sharpen = false;
			TextSettings.Unsharp = true;
			ApplyTextEffects();
		}

		private void cmenuTextStretch_Click(object sender, System.EventArgs e) {
			TextSettings.Stretch = !TextSettings.Stretch;
			ApplyTextEffects();
			UpdateLevelsArray();
		}

		/// <summary>
		/// Overriden OnResize to handle widget positions
		/// </summary>
		/// <param name="e"></param>
		protected override void OnResize(EventArgs e) {
			if (WindowState == FormWindowState.Minimized)
				return;

			base.OnResize(e);
        }

        private void pnlMain_Resize(object sender, EventArgs e) {
            RearrangeWidgets();
        }

        /// <summary>
        /// Update the positions of the widgets
        /// </summary>
        private void RearrangeWidgets() {
			SuspendLayout();

			foreach (Control control in pnlMain.Controls) {
				if (control.GetType().BaseType == typeof(BaseWidget)) {
					if (control.Left > (_ClientSize.Width - control.Right)) {
						control.Left = pnlMain.ClientSize.Width - (_ClientSize.Width - control.Left);
					}
						
					if (control.Top > (_ClientSize.Height - control.Bottom)) {
						control.Top = pnlMain.ClientSize.Height - (_ClientSize.Height - control.Top);
					}

					control.Refresh();
				}
			}

			ResumeLayout();

			_ClientSize = pnlMain.ClientSize;
		}

		private void cmbRamp_DropDown(object sender, System.EventArgs e) {
			int iWidth = cmbRamp.Width;

			foreach (string ramp in cmbRamp.Items) {
                Size size = FontFunctions.MeasureText(ramp + "  ", cmbRamp.Font);

                if (size.Width > iWidth) {
                    iWidth = size.Width;
                }
			}

			cmbRamp.DropDownWidth = iWidth;		
		}

		private void cmenuTextFont_Click(object sender, System.EventArgs e) {
			ShowFontDialog();
		}

        private void menuEditFont_Click(object sender, EventArgs e) {
            ShowFontDialog();
        }

		/// <summary>
		/// Display the font dialog and process the result
		/// </summary>
		public void ShowFontDialog() {
			try {
				if (dialogChooseFont.ShowDialog() == DialogResult.OK) {
					UpdateFonts();

					if (TextSettings.IsFixedWidth) {
						TextSettings.Ramp = (TextSettings.IsGeneratedRamp) ?
							AsciiRampCreator.CreateRamp(TextSettings.Font, TextSettings.ValidCharacters) : cmbRamp.Text;
					}

					UpdateValues();

					DoConvert();
				}
			}
			catch (System.ArgumentException) {
				MessageBox.Show(Resource.GetString("Unable to select this font"), Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		/// <summary>Updates all controls for the current font</summary>
		private void UpdateFonts() {
			TextSettings.Font = rtbxConvertedText.Font = cmbRamp.Font = dialogChooseFont.Font;

			tstripRamp.Visible = chkGenerate.Visible = lblRamp.Visible = cmbRamp.Visible = TextSettings.IsFixedWidth;
			tstripCharacters.Visible = lblCharacters.Visible = cmbCharacters.Visible = !TextSettings.IsFixedWidth;
		}

		private void cmbRamp_SelectedIndexChanged(object sender, System.EventArgs e) {
			TextSettings.Ramp = cmbRamp.Text;

			if (TextSettings.IsFixedWidth) ApplyTextEffects();
		}

		private void cmbRamp_TextChanged(object sender, System.EventArgs e) {
			TextSettings.Ramp = cmbRamp.Text;

			if (TextSettings.IsFixedWidth) ApplyTextEffects();
		}

		private void pbxMain_SelectionChanged(object sender, System.EventArgs e) {
			UpdateValues();

			_InputChanged = true;
			_ImageSaved = false;
		}

		private Size InputSize {
			get {
				if (pbxMain.Image == null) {
					return new Size(0, 0);
				}
				else {
					if (pbxMain.SelectedArea.Width > 0 || pbxMain.SelectedArea.Height > 0) {
						return pbxMain.SelectedArea.Size;
					}
					else {
						return pbxMain.Image.Size;
					}
				}
			}
		}

		private void cmenuImageSelectNone_Click(object sender, System.EventArgs e) {
			pbxMain.SelectNothing();
		}

		private void contextMenuImage_Popup(object sender, System.EventArgs e) {
			cmenuImageSelectionLocked.Enabled =
				cmenuImageSelectionShow.Enabled =
				cmenuImageSelectNone.Enabled = (pbxMain.SelectedArea.Width > 0 || pbxMain.SelectedArea.Height > 0);

			cmenuImageSelectionLocked.Checked = pbxMain.SelectionLocked;

			cmenuImageSelectionShow.Checked = pbxMain.FillSelectionRectangle;
		}

		private void cmenuImageSelectionLocked_Click(object sender, System.EventArgs e) {
			pbxMain.SelectionLocked = !pbxMain.SelectionLocked;
		}

		private void menuView_Popup(object sender, System.EventArgs e) {
			menuViewImage.Checked = (tabMain.SelectedTab == tabPageImage);
			menuViewText.Checked = (tabMain.SelectedTab == tabPageText);
			menuViewICBC.Checked = !BCWidgetImage.Hidden;
			menuViewTCBC.Checked = !BCWidgetText.Hidden;
			menuViewLevels.Checked = !LevelsWidget.Hidden;
			menuViewFullScreen.Checked = (_PreviousFormPosition != Rectangle.Empty);
		}

		private void menuViewImage_Click(object sender, System.EventArgs e) {
			tabMain.SelectedTab = tabPageImage;
		}

		private void menuViewText_Click(object sender, System.EventArgs e) {
			tabMain.SelectedTab = tabPageText;
		}

		private void menuViewICBC_Click(object sender, System.EventArgs e) {
			BCWidgetImage.Hidden = !BCWidgetImage.Hidden;
			BCWidgetImage.Visible = (tabMain.SelectedTab == tabPageImage) && !BCWidgetImage.Hidden;
			BCWidgetImage.BringToFront();
		}

		private void menuViewTCBC_Click(object sender, System.EventArgs e) {
			BCWidgetText.Hidden = !BCWidgetText.Hidden;
			BCWidgetText.Visible = (tabMain.SelectedTab == tabPageText) && !BCWidgetText.Hidden;		
			BCWidgetText.BringToFront();
		}

		private void menuViewLevels_Click(object sender, System.EventArgs e) {
			LevelsWidget.Hidden = !LevelsWidget.Hidden;
			LevelsWidget.Visible = (tabMain.SelectedTab == tabPageText) && !LevelsWidget.Hidden;		
			LevelsWidget.BringToFront();		
		}

		private void tbxWidth_TextChanged(object sender, System.EventArgs e) {
			if (_bSizeChanging) return;

            tbxWidth.Invalidate();
            tstripOutputSize.Refresh();

			_InputChanged = true;
			_ImageSaved = false;
			_bWidthChangedLast = true;

			try {
				TextSettings.Width = Convert.ToInt32(tbxWidth.Text, Variables.Culture);

				if (TextSettings.Width < 1)
					TextSettings.Width = -1;

				if (UpdateHeight()) {
					if (tabMain.SelectedTab == tabPageText) {
						DoConvert();
					}
				}

				tbxWidth.Focus();
			}
			catch (FormatException) {
				TextSettings.Width = -1;

				if (Locked) {
					_bSizeChanging = true;
					tbxHeight.Text = string.Empty;
					TextSettings.Height = -1;
					_bSizeChanging = false;
				}
			}
		}

		private void tbxHeight_TextChanged(object sender, System.EventArgs e) {
			if (_bSizeChanging) return;

			tbxHeight.Invalidate();
            tstripOutputSize.Refresh();

			_InputChanged = true;
			_ImageSaved = false;
			_bWidthChangedLast = false;

			try {
				TextSettings.Height = Convert.ToInt32(tbxHeight.Text, Variables.Culture);

				if (TextSettings.Height < 1)
					TextSettings.Height = -1;

				if (UpdateWidth()) {
					if (tabMain.SelectedTab == tabPageText) {
						DoConvert();
					}
				}

				tbxHeight.Focus();
			}
			catch (FormatException) {
				TextSettings.Height = -1;

				if (Locked) {
					_bSizeChanging = true;
					tbxWidth.Text = string.Empty;
					TextSettings.Width = -1;
					_bSizeChanging = false;
				}
			}
		}

		/// <summary>
		/// Recalculate and update the width or height
		/// </summary>
		private void UpdateValues() {
			if (_bWidthChangedLast)
				UpdateHeight();
			else
				UpdateWidth();
		}

		/// <summary>
		/// Recalculate the height from the current width
		/// </summary>
		/// <returns>Were we able to calculate the height?</returns>
		private bool UpdateHeight() {
			if (pbxMain.Image == null)
				return false;

			if ((!_bSizeChanging)&&(_Locked)) {
				// make sure nothing else will change the width
				_bSizeChanging = true;

				TextSettings.Height = AscgenConverter.CalculateOtherDimension(TextSettings.Width,
					InputSize.Width, InputSize.Height,
					TextSettings.CharacterSize.Width, TextSettings.CharacterSize.Height);

				if (TextSettings.Height > 999) {
					TextSettings.Height = -1;
					tbxHeight.Text = string.Empty;
					_bSizeChanging = false;
					return false;
				}
				else if (TextSettings.Height < 1) {
					TextSettings.Height = 1;
				}

				tbxHeight.Text = TextSettings.Height.ToString(Variables.Culture);						
				_bSizeChanging = false;
				tbxHeight.Invalidate();
                tstripOutputSize.Refresh();

				_InputChanged = true;
				_ImageSaved = false;
			}

			return true;
		}

		/// <summary>
		/// Recalculate the width from the current height
		/// </summary>
		/// <returns>Were we able to calculate the width?</returns>
		private bool UpdateWidth() {
			if (pbxMain.Image == null)
				return false;

			if ((!_bSizeChanging)&&(_Locked)) {
				// make sure nothing else will change the height
				_bSizeChanging = true;

				TextSettings.Width = AscgenConverter.CalculateOtherDimension(TextSettings.Height,
					InputSize.Height, InputSize.Width,
					TextSettings.CharacterSize.Height, TextSettings.CharacterSize.Width);

				if (TextSettings.Width > 999) {
					TextSettings.Width = -1;
					tbxWidth.Text = string.Empty;
					_bSizeChanging = false;
					return false;
				}
				else if (TextSettings.Width < 1) {
					TextSettings.Width = 1;
				}
					
				tbxWidth.Text = TextSettings.Width.ToString(Variables.Culture);
				_bSizeChanging = false;
                tbxWidth.Invalidate();
                tstripOutputSize.Refresh();

				_InputChanged = true;
				_ImageSaved = false;
			}

			return true;
		}

		private void btnFont_Click(object sender, System.EventArgs e) {
			ShowFontDialog();

			tabMain.Focus();
		}

		private bool CloseImage() {
			if (pbxMain.Image != null) {
				if (CheckCloseWithoutSaving()) {
					pbxMain.Image = null;

					rtbxConvertedText.Text = string.Empty;

					_Values = null;

					tabPageImage.Text = Resource.GetString("Image");
					tabPageText.Text = Resource.GetString("Text");

					// reset the brightness and contrast values
					BCWidgetImage.Brightness = Variables.DefaultImageBrightness;
					BCWidgetImage.Contrast = Variables.DefaultImageContrast;
					BCWidgetImage.Refresh();

					BCWidgetText.Brightness = Variables.DefaultTextBrightness;
					BCWidgetText.Contrast = Variables.DefaultTextContrast;
					BCWidgetText.Refresh();

					TextSettings.Levels.Minimum = LevelsWidget.Minimum = Variables.DefaultMinLevel;
					TextSettings.Levels.Maximum = LevelsWidget.Maximum = Variables.DefaultMaxLevel;
					TextSettings.Levels.Median = LevelsWidget.Median = Variables.DefaultMedianLevel;

					LevelsWidget.Enabled = BCWidgetImage.Enabled = BCWidgetText.Enabled = false;

					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
		}

		private bool CheckCloseWithoutSaving() {
			if (!_ImageSaved && pbxMain.Image != null && Variables.ConfirmOnClose) {
                switch (MessageBox.Show(Resource.GetString("Save the output before closing") + "?",
						Resource.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning,
						MessageBoxDefaultButton.Button1)) {
                    case DialogResult.Yes:	// save then close if save dialog ok
                        return SaveTextDialog();

					case DialogResult.No:	// close
                        return true;

					default:
					case DialogResult.Cancel:	// don't do anything
						return false;
				}
			}
			else {
				return true;
			}
		}

		private void menuFileClose_Click(object sender, System.EventArgs e) {
			if (CloseImage()) {
				LevelsWidget.Array = new int[256];

				if (Locked) {
					_bSizeChanging = true;
				
					if (_bWidthChangedLast) {
						if (tbxWidth.Text == Variables.DefaultWidth.ToString(Variables.Culture)) {
							tbxWidth.Text = string.Empty;
						}

						tbxHeight.Text = string.Empty;
					}
					else {
						if (tbxHeight.Text == Variables.DefaultHeight.ToString(Variables.Culture)) {
							tbxHeight.Text = string.Empty;
						}

						tbxWidth.Text = string.Empty;
					}

					_bSizeChanging = false;
				}

				_strFilename = String.Empty;
			}
		}

		private void cbxLocked_CheckedChanged(object sender, System.EventArgs e) {
			Locked = !Locked;
		}

		private void menuViewFullScreen_Click(object sender, System.EventArgs e) {
			SwitchFullScreen();
		}

		private void chkFullScreen_CheckedChanged(object sender, System.EventArgs e) {
			SwitchFullScreen();
		}

		private void SwitchFullScreen() {
			if (!_FullScreenChanging) {
				_FullScreenChanging = true;
				if (_PreviousFormPosition == Rectangle.Empty) {
					_PreviousWindowState = WindowState;

					if (WindowState == FormWindowState.Maximized) {
						WindowState = FormWindowState.Normal;
					}

					_PreviousFormPosition = new Rectangle(Location, Size);

					FormBorderStyle = FormBorderStyle.None;

					Location = new Point(0, 0);
					Size = new Size(Screen.PrimaryScreen.Bounds.Width,
						Screen.PrimaryScreen.Bounds.Height);

					chkFullScreen.Checked = true;
				}
				else {
					FormBorderStyle = FormBorderStyle.Sizable;

					Location = _PreviousFormPosition.Location;
					Size = _PreviousFormPosition.Size;

					WindowState = _PreviousWindowState;

					_PreviousFormPosition = Rectangle.Empty;

					chkFullScreen.Checked = false;

					Focus();
				}

				_FullScreenChanging = false;
			}
		}

		private void cmenuImageSelectionShow_Click(object sender, System.EventArgs e) {
			pbxMain.FillSelectionRectangle = !pbxMain.FillSelectionRectangle;
		}

		private void chkGenerate_CheckedChanged(object sender, System.EventArgs e) {
			TextSettings.IsGeneratedRamp = chkGenerate.Checked;

			cmbRamp.Enabled = !TextSettings.IsGeneratedRamp;

			if (TextSettings.IsFixedWidth) {
				TextSettings.Ramp = (TextSettings.IsGeneratedRamp) ?
					AsciiRampCreator.CreateRamp(TextSettings.Font, TextSettings.ValidCharacters) : cmbRamp.Text;

				_InputChanged = true;
				_ImageSaved = false;

				ApplyTextEffects();
			}
		}

		private void menuEditValidChars_Click(object sender, System.EventArgs e) {
			ValidRampCharsDialog dlgValidChars = new ValidRampCharsDialog();

			dlgValidChars.Font = TextSettings.Font;
			dlgValidChars.Characters = TextSettings.ValidCharacters;

			if (dlgValidChars.ShowDialog() == DialogResult.OK) {
				SetValidCharacters(dlgValidChars.Characters);
				cmbCharacters.Text = dlgValidChars.Characters;
			}
		}

		private void SetValidCharacters(string characters) {
			if (characters == null || TextSettings.ValidCharacters == characters) return;

			TextSettings.ValidCharacters = characters;

			if (TextSettings.IsGeneratedRamp && TextSettings.IsFixedWidth) {
				TextSettings.Ramp =
					AsciiRampCreator.CreateRamp(TextSettings.Font, TextSettings.ValidCharacters);
			}

			ApplyTextEffects();
		}

		private void cmbCharacters_TextChanged(object sender, System.EventArgs e) {
			if (cmbCharacters.Visible && cmbCharacters.Text.Length > 0) {
				SetValidCharacters(cmbCharacters.Text);
			}
		}

		private void menuFileImportClipboard_Click(object sender, System.EventArgs e) {
			_strFilename = string.Format(Variables.Culture, "Clipboard{0:yyyyMMddHHmmss}", System.DateTime.Now);

			IDataObject data = Clipboard.GetDataObject();

			if (data.GetDataPresent(DataFormats.Bitmap)) {
				LoadImage((Bitmap)data.GetData(DataFormats.Bitmap, true));
			}
		}

		private void chkBlackOnWhite_CheckedChanged(object sender, System.EventArgs e) {
			TextSettings.IsBlackTextOnWhite = !chkBlackOnWhite.Checked;

			rtbxConvertedText.BackColor = (TextSettings.IsBlackTextOnWhite) ? Color.White : Color.Black;
			rtbxConvertedText.ForeColor = (TextSettings.IsBlackTextOnWhite) ? Color.Black : Color.White;

			ApplyTextEffects();
		}

		private void cmenuTextHorizontal_Click(object sender, System.EventArgs e) {
			TextSettings.FlipHorizontally = !TextSettings.FlipHorizontally;
			ApplyTextEffects();
		}

		private void cmenuTextVertical_Click(object sender, System.EventArgs e) {
			TextSettings.FlipVertically = !TextSettings.FlipVertically;
			ApplyTextEffects();
		}

		private void ApplyTextBrightness() {
			TextSettings.Brightness = BCWidgetText.Brightness;
			ApplyTextEffects();
			UpdateLevelsArray();
		}

		private void ApplyTextContrast() {
			TextSettings.Contrast = BCWidgetText.Contrast;
			ApplyTextEffects();
			UpdateLevelsArray();
		}

		/// <summary>Method that fires when the levels widget value changes</summary>
		private void LevelsChanged() {
			TextSettings.Levels.Minimum = LevelsWidget.Minimum;
			TextSettings.Levels.Median = LevelsWidget.Median;
			TextSettings.Levels.Maximum = LevelsWidget.Maximum;
			ApplyTextEffects();
		}

		private void menuFileBatchConversion_Click(object sender, System.EventArgs e) {
			_BatchConverter.ShowDialog();
		}

		private void menuEditSpecifyCharSize_Click(object sender, EventArgs e) {
			CharacterSizeDialog characterDialog = new CharacterSizeDialog();

			characterDialog.DefaultCharacterSize = (TextSettings.CalculateCharacterSize && TextSettings.IsFixedWidth) ?
				TextSettings.CharacterSize : FontFunctions.GetFixedPitchFontSize(TextSettings.Font);

			if (!TextSettings.IsFixedWidth) {
				characterDialog.DefaultCharacterSize = new Size(ValuesToVariableWidthTextConverter.CharacterWidth,
					FontFunctions.MeasureText("W", TextSettings.Font).Height);
			}

			characterDialog.AutoCalculateSize = TextSettings.CalculateCharacterSize;

			characterDialog.CharacterSize = TextSettings.CharacterSize;

			if (characterDialog.ShowDialog() == DialogResult.OK) {
				TextSettings.CalculateCharacterSize = characterDialog.AutoCalculateSize;

				if (!characterDialog.AutoCalculateSize) {
					TextSettings.CharacterSize = characterDialog.CharacterSize;
				}

				UpdateValues();
				DoConvert();
			}
		}

		private void menuEdit_Popup(object sender, System.EventArgs e) {
			menuEditOutput.Enabled = (pbxMain.Image != null);
		}

		private void menuEditOutput_Popup(object sender, System.EventArgs e) {
			menuEditStretch.Checked = TextSettings.Stretch;
			menuEditFlipHorizontal.Checked = TextSettings.FlipHorizontally;
			menuEditFlipVertical.Checked = TextSettings.FlipVertically;
		}

        private void menuEditRamps_DropDownOpening(object sender, EventArgs e) {
            menuEditRampsCopyRamp.Enabled = TextSettings.IsFixedWidth;
        }

		private void menuEditSharpeningMethod_Popup(object sender, System.EventArgs e) {
			menuEditSharpeningMethodNone.Checked = !TextSettings.Sharpen && !TextSettings.Unsharp;
			menuEditSharpeningMethodSharpen.Checked = TextSettings.Sharpen;
			menuEditSharpeningMethodUnsharp.Checked = TextSettings.Unsharp;
		}

		private void menuEditSaveSettings_Click(object sender, System.EventArgs e) {
			WriteXML(Path.GetDirectoryName(Application.ExecutablePath) + Path.DirectorySeparatorChar +
				Path.GetFileNameWithoutExtension(Application.ExecutablePath) + ".xml");
		}

		private void cmbCharacters_DropDown(object sender, System.EventArgs e) {
			int iWidth = cmbCharacters.Width;

			foreach (string Characters in cmbCharacters.Items) {
                Size szWidth = FontFunctions.MeasureText(Characters + "  ", cmbCharacters.Font);

				if (szWidth.Width > iWidth)
					iWidth = szWidth.Width;
			}

			cmbCharacters.DropDownWidth = iWidth;
		}

		private void cmenuImageSelectionFillColor_Click(object sender, System.EventArgs e) {
			dialogSelectionColor.Color = pbxMain.SelectionFillColor;

			if (dialogSelectionColor.ShowDialog() == DialogResult.OK) {
				pbxMain.SelectionFillColor = dialogSelectionColor.Color;
			}
		}

		private void cmenuImageSelectionBorderColor_Click(object sender, System.EventArgs e) {
			dialogSelectionColor.Color = pbxMain.SelectionBorderColor;

			if (dialogSelectionColor.ShowDialog() == DialogResult.OK) {
				pbxMain.SelectionBorderColor = dialogSelectionColor.Color;
			}		
		}

		private void FormConvertImage_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			if (pbxMain.Image != null) {
				e.Cancel = !CheckCloseWithoutSaving();
			}
		}

        private void menuHelpDonate_Click(object sender, EventArgs e) {
            System.Diagnostics.Process.Start("https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=wardog1uk%40gmail%2ecom&item_name=Ascii%20Generator%20%2eNET&no_shipping=2&no_note=1&tax=0&currency_code=GBP&bn=PP%2dDonationsBF&charset=UTF%2d8");
        }

        private void menuEditEditSettings_Click(object sender, EventArgs e) {
            //FormEditSettings settingsDialog = new FormEditSettings();

            //if (settingsDialog.ShowDialog() == DialogResult.OK) {
            //}
        }

        private void menuHelpReportBug_Click(object sender, EventArgs e) {
            System.Diagnostics.Process.Start("http://sourceforge.net/tracker/?func=add&group_id=133786&atid=728164");
        }

        private void menuHelpRequestFeature_Click(object sender, EventArgs e) {
            System.Diagnostics.Process.Start("http://sourceforge.net/tracker/?func=add&group_id=133786&atid=728167");
        }

        private void menuFileSaveColourText_Click(object sender, EventArgs e) {
            if (CheckIfSavable() && TextSettings.IsFixedWidth) {
                dialogSaveColour.FileName = Variables.Prefix + Path.GetFileNameWithoutExtension(_strFilename);

                if (dialogSaveColour.ShowDialog() == DialogResult.OK) {
                    Rectangle Section = (pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
                        new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) : pbxMain.SelectedArea;

                    // create the array of Colors
                    Color[,] colors = AscgenConverter.ImageToColors((Bitmap)pbxMain.BCImage,
                        new Size(TextSettings.Width, TextSettings.Height), Section, (dialogSaveColour.FilterIndex == 1 || dialogSaveColour.FilterIndex == 2));

                    string[] strings = TextSettings.Apply(_Values);

                    string output;

                    System.Text.Encoding Encoding;

                    switch (dialogSaveColour.FilterIndex) {
                        case 2: // rtf 256 color
                        case 4: // rtf 24-bit
                            output = CreateRTF(strings, colors);
                            Encoding = System.Text.Encoding.ASCII;
                            break;

                        case 1: // html 256 color
                        case 3: // html 24-bit
                        default:
                            output = CreateHTML(strings, colors,
                                TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black);
                            Encoding = System.Text.Encoding.Unicode;
                            break;
                    }

                    using (StreamWriter writer = new StreamWriter(dialogSaveColour.FileName, false, Encoding)) {
                        writer.Write(output);
                    }

                    _ImageSaved = true;
                }
            }
        }

        private string CreateRTF(string[] strings, Color[,] colors) {
            if (!TextSettings.IsFixedWidth) return null;

            //--
            // Create the unique color array, and the array of int pointers
            //--
            int[,] CharToColor = new int[colors.GetLength(0), colors.GetLength(1)];

            ArrayList UniqueColors = new ArrayList();
            int colorid;
            int previous = -1;

            for (int y = 0; y < colors.GetLength(1); y++) {
                for (int x = 0; x < colors.GetLength(0); x++) {
                    colorid = UniqueColors.IndexOf(colors[x, y]);
                    CharToColor[x, y] = (colorid == -1) ? UniqueColors.Add(colors[x, y]) : colorid;

                    if (CharToColor[x, y] == previous) {
                        CharToColor[x, y] = -1;
                    }
                    else {
                        previous = CharToColor[x, y];
                    }
                }
            }

            //--
            // create and output the text
            //--

            System.Text.StringBuilder builder = new System.Text.StringBuilder();

            // the rtf header
            builder.Append(@"{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fnil\fcharset0 ");
            builder.Append(TextSettings.Font.Name);
            builder.Append(";}}");
            builder.Append(Environment.NewLine);

            // the rtf colortbl
            builder.Append(@"{\colortbl ;");

            foreach (Color c in UniqueColors) {
                builder.Append(@"\red");
                builder.Append(c.R);
                builder.Append(@"\green");
                builder.Append(c.G);
                builder.Append(@"\blue");
                builder.Append(c.B);
                builder.Append(";");
            }

            builder.Append("}");
            builder.Append(Environment.NewLine);
            builder.Append(@"{\*\generator Ascgen dotNET ");
            builder.Append(Variables.Version.GetVersion());
            builder.Append(";}");

            // the font settings
            builder.Append(@"\viewkind4\uc1\pard\lang2057\f0");
            if (TextSettings.Font.Bold) builder.Append(@"\b");
            if (TextSettings.Font.Italic) builder.Append(@"\i");
            if (TextSettings.Font.Underline) builder.Append(@"\ul");
            if (TextSettings.Font.Strikeout) builder.Append(@"\strike");
            builder.Append(@"\fs");
            builder.Append(TextSettings.Font.Size * 2);

            // the text
            for (int y = 0; y < TextSettings.Height; y++) {
                for (int x = 0; x < TextSettings.Width; x++) {
                    if (CharToColor[x, y] != -1) {
                        builder.Append(@"\cf");
                        builder.Append(CharToColor[x, y] + 1);
                        builder.Append(" ");
                    }

                    builder.Append(strings[y][x]);
                }

                builder.Append(@"\par");
                builder.Append(Environment.NewLine);
            }

            builder.Append("}");

            return builder.ToString();
        }

        private string CreateHTML(string[] strings, Color[,] colors, Color backgroundcolor) {
            bool UseColor = (colors != null) && TextSettings.IsFixedWidth;

            //--
            // Create the unique color array, and the array of int pointers
            //--
            int[,] CharToColor = null;

            ArrayList UniqueColors = new ArrayList();

            if (UseColor) {
                CharToColor = new int[colors.GetLength(0), colors.GetLength(1)];
                int colorid;
                int previous = -1;

                for (int y = 0; y < colors.GetLength(1); y++) {
                    for (int x = 0; x < colors.GetLength(0); x++) {
                        colorid = UniqueColors.IndexOf(colors[x, y]);
                        CharToColor[x, y] = (colorid == -1) ? UniqueColors.Add(colors[x, y]) : colorid;

                        if (CharToColor[x, y] == previous) {
                            CharToColor[x, y] = -1;
                        }
                        else {
                            previous = CharToColor[x, y];
                        }
                    }
                }
            }

            System.Text.StringBuilder builder = new System.Text.StringBuilder();

            builder.AppendLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">");
            builder.AppendLine("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">");
            builder.AppendLine("");
            builder.AppendLine("<head>");
            builder.AppendLine("");

            builder.Append("<title>");
            builder.Append(Path.GetFileNameWithoutExtension(_strFilename));
            builder.Append("</title>");
            builder.Append(Environment.NewLine);

            builder.AppendLine("");

            builder.Append("<meta name=\"generator\" content=\"Ascgen dotNET ");
            builder.Append(Variables.Version.GetVersion());
            builder.Append("\" />");
            builder.Append(Environment.NewLine);

            builder.AppendLine("");

            builder.AppendLine("<style type=\"text/css\">");
            builder.AppendLine("<!--");

            builder.AppendLine("#ascgen-image pre {");
            builder.Append("	font-family: \"");
            builder.Append(TextSettings.Font.Name);
            builder.Append("\", monospace;");
            builder.Append(Environment.NewLine);

            builder.Append("	font-size: ");
            builder.Append(TextSettings.Font.Size);
            builder.Append("pt;");
            builder.Append(Environment.NewLine);

            builder.Append("	background-color: #");
            builder.Append(backgroundcolor.R.ToString("X2", null));
            builder.Append(backgroundcolor.G.ToString("X2", null));
            builder.Append(backgroundcolor.B.ToString("X2", null));
            builder.Append(";");
            builder.Append(Environment.NewLine);

            Color forecolor = Color.FromArgb((byte)~(backgroundcolor.R), (byte)~(backgroundcolor.G), (byte)~(backgroundcolor.B));
            builder.Append("	color: #");
            builder.Append(forecolor.R.ToString("X2", null));
            builder.Append(forecolor.G.ToString("X2", null));
            builder.Append(forecolor.B.ToString("X2", null));
            builder.Append(";");
            builder.Append(Environment.NewLine);

            builder.AppendLine("	float: left;");     // avoids firefox problem with scrolling horizontally
            builder.Append("	line-height: ");  // fixes firefox problem with extra space between lines
            builder.Append(TextSettings.CharacterSize.Height);
            builder.Append("px;");
            builder.Append(Environment.NewLine);

            builder.AppendLine("	border: 1px solid #000000;");

            builder.AppendLine("}");

            if (UseColor) {
                builder.Append(Environment.NewLine);

                int count = 0;

                foreach (Color c in UniqueColors) {
                    builder.Append(".c");
                    builder.Append(count++);
                    builder.Append(" { color: #");
                    builder.Append(c.R.ToString("X2", null));
                    builder.Append(c.G.ToString("X2", null));
                    builder.Append(c.B.ToString("X2", null));
                    builder.Append("; }");
                    builder.Append(Environment.NewLine);
                }
            }

            builder.AppendLine("-->");
            builder.AppendLine("</style>");
            builder.AppendLine("");
            builder.AppendLine("</head>");
            builder.AppendLine("");
            builder.AppendLine("<body>");
            builder.AppendLine("");
            builder.AppendLine("<div id=\"ascgen-image\">");
            builder.Append("<pre>");

            bool spanopen = false;

            // the text
            if (TextSettings.IsFixedWidth) {
                for (int y = 0; y < TextSettings.Height; y++) {
                    for (int x = 0; x < TextSettings.Width; x++) {
                        if (UseColor && CharToColor[x, y] != -1) {
                            if (spanopen) {
                                builder.Append("</span>");
                                spanopen = false;
                            }

                            builder.Append("<span class=\"c");
                            builder.Append(CharToColor[x, y]);
                            builder.Append("\">");
                            spanopen = true;
                        }

                        builder.Append(strings[y][x]);
                    }

                    if (y < TextSettings.Height - 1) builder.Append(Environment.NewLine);
                }
            }
            else {
                foreach (string s in strings) {
                    builder.Append(s);
                    builder.Append(Environment.NewLine);
                }
            }

            if (UseColor) {
                builder.Append("</span>");
            }

            builder.Append("</pre>");
            builder.Append(Environment.NewLine);
            builder.AppendLine("</div>");
            builder.AppendLine("");
            builder.AppendLine("</body>");
            builder.AppendLine("");
            builder.Append("</html>");

            return builder.ToString();
        }

        /// <summary>
        /// Check if a new version of the program is available
        /// </summary>
        private void CheckForNewVersion() {
            CheckForIllegalCrossThreadCalls = false;

            byte[] buffer = new byte[8192];
            StringBuilder stringbuffer = new StringBuilder();

            try {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ascgen2.sourceforge.net/version.xml");
                request.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse()) {
                    using (Stream receiveStream = response.GetResponseStream()) {
                        int numbytes = 0;

                        do {
                            numbytes = receiveStream.Read(buffer, 0, buffer.Length);

                            if (numbytes != 0) {
                                stringbuffer.Append(Encoding.ASCII.GetString(buffer, 0, numbytes));
                            }
                        }
                        while (numbytes > 0);
                    }
                }
            }
            catch (System.Net.WebException) {
                stringbuffer = new StringBuilder();
            }

            if (stringbuffer.Length > 0) {
                XmlDocument doc = new XmlDocument();

                try {
                    doc.LoadXml(stringbuffer.ToString());

                    int major = ReadNode(doc.SelectSingleNode("version/major"), 0, 100, 0);
                    int minor = ReadNode(doc.SelectSingleNode("version/minor"), 0, 100, 0);
                    int patch = ReadNode(doc.SelectSingleNode("version/patch"), 0, 100, 0);
                    string suffix = ReadNode(doc.SelectSingleNode("version/suffix"), "", true);
                    int suffixnum = ReadNode(doc.SelectSingleNode("version/suffixnum"), 0, 100, 0);

                    if (major > Variables.Version.Major || minor > Variables.Version.Minor ||
                        patch > Variables.Version.Patch || suffixnum > Variables.Version.SuffixNumber) {
                        NewVersionDialog(major.ToString() + "." + minor.ToString() + "." + patch.ToString() + suffix,
                            "http://sourceforge.net/project/showfiles.php?group_id=133786");
                    }
                }
                catch (System.Xml.XmlException) {
                }
            }

            CheckForIllegalCrossThreadCalls = true;
        }

        private void NewVersionDialog(string version, string url) {
            string caption = Resource.GetString("Open the download page?");
            string text = string.Format(Resource.GetString("ASCGEN dotNET v{0} is available"), version);

            if (MessageBox.Show(caption, text, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK) {
                System.Diagnostics.Process.Start(url);
            }
        }

        private void menuEditRampCopyRamp_Click(object sender, EventArgs e) {
            Clipboard.SetDataObject(TextSettings.Ramp, true);
        }

		#region Properties and Variables

		/// <summary>The original image converted into an array of bytes</summary>
		private byte[,] _Values;

		/// <summary>Arguments passed when the program started</summary>
		private string[] _Args;

		/// <summary>Have the input settings changed so the output needs to be recalculated?</summary>
		private bool _InputChanged;

		/// <summary>The full filename of the input image</summary>
		private string _strFilename = String.Empty;

		/// <summary>Used for storing the size of the form</summary>
		private Size _ClientSize;

		/// <summary>Brightness/Contrast widget used by tabPageImage</summary>
		private WidgetBrightnessContrast BCWidgetImage = new WidgetBrightnessContrast();

		/// <summary>Brightness/Contrast widget used by tabPageText</summary>
		private WidgetBrightnessContrast BCWidgetText = new WidgetBrightnessContrast();

		/// <summary>Levels widget used by tabPageText</summary>
		private WidgetLevels LevelsWidget = new WidgetLevels();

		/// <summary>Used to store the settings used on the output image</summary>
		private TextProcessingSettings TextSettings;

		private bool _bSizeChanging;

		private bool _bWidthChangedLast = true;

		private bool _Locked = true;
		/// <summary>
		/// Are the output size dimensions locked to the correct aspect ratio?
		/// </summary>
		public bool Locked {
			get {
				return _Locked;
			}

			set {
				_Locked = value;

				if (_Locked) {
					UpdateValues();

					DoConvert();
				}
			}
		}

		/// <summary>Store the position and size of the form when going to full screen mode</summary>
		private Rectangle _PreviousFormPosition = Rectangle.Empty;

		/// <summary>Store the previous state of the window (workaround problem with maximized form</summary>
		private FormWindowState _PreviousWindowState = FormWindowState.Normal;

		/// <summary>True when changing to and from full screen mode</summary>
		private bool _FullScreenChanging;

		private FormBatchConvert _BatchConverter;

		/// <summary>Has the current image been saved?</summary>
		private bool _ImageSaved;
		
		private Thread _VersionCheckThread;

		#endregion
    }
}