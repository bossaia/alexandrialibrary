//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: ValidRampCharsDialog.cs,v 1.11 2006/06/03 23:29:11 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using JMSoftware.AsciiGeneratorDotNet;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for ValidRampCharsDialog.
	/// </summary>
	public class ValidRampCharsDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnDefault;
		private System.Windows.Forms.Label lblValid1;
		private System.Windows.Forms.Label lblValid2;
		private System.Windows.Forms.ComboBox cmbCharacters;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructor
		/// </summary>
		public ValidRampCharsDialog()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			UpdateUI();

			cmbCharacters.Items.Clear();
			cmbCharacters.Items.AddRange(Variables.DefaultValidCharacters.ToArray());
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOk = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.lblValid1 = new System.Windows.Forms.Label();
			this.lblValid2 = new System.Windows.Forms.Label();
			this.btnDefault = new System.Windows.Forms.Button();
			this.cmbCharacters = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// btnOk
			// 
			this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOk.Location = new System.Drawing.Point(8, 76);
			this.btnOk.Name = "btnOk";
			this.btnOk.TabIndex = 3;
			this.btnOk.Text = "btnOk";
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(232, 76);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 5;
			this.btnCancel.Text = "btnCancel";
			// 
			// lblValid1
			// 
			this.lblValid1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblValid1.Location = new System.Drawing.Point(8, 8);
			this.lblValid1.Name = "lblValid1";
			this.lblValid1.Size = new System.Drawing.Size(296, 16);
			this.lblValid1.TabIndex = 0;
			this.lblValid1.Text = "lblValid1";
			this.lblValid1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lblValid2
			// 
			this.lblValid2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblValid2.Location = new System.Drawing.Point(8, 52);
			this.lblValid2.Name = "lblValid2";
			this.lblValid2.Size = new System.Drawing.Size(296, 16);
			this.lblValid2.TabIndex = 2;
			this.lblValid2.Text = "lblValid2";
			this.lblValid2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// btnDefault
			// 
			this.btnDefault.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnDefault.Location = new System.Drawing.Point(120, 76);
			this.btnDefault.Name = "btnDefault";
			this.btnDefault.TabIndex = 4;
			this.btnDefault.Text = "btnDefault";
			this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
			// 
			// cmbCharacters
			// 
			this.cmbCharacters.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cmbCharacters.Location = new System.Drawing.Point(8, 29);
			this.cmbCharacters.Name = "cmbCharacters";
			this.cmbCharacters.Size = new System.Drawing.Size(299, 21);
			this.cmbCharacters.TabIndex = 6;
			this.cmbCharacters.DropDown += new System.EventHandler(this.cmbCharacters_DropDown);
			this.cmbCharacters.TextChanged += new System.EventHandler(this.cmbCharacters_TextChanged);
			// 
			// ValidRampCharsDialog
			// 
			this.AcceptButton = this.btnOk;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(314, 108);
			this.Controls.Add(this.btnDefault);
			this.Controls.Add(this.lblValid2);
			this.Controls.Add(this.lblValid1);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOk);
			this.Controls.Add(this.cmbCharacters);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(322, 134);
			this.Name = "ValidRampCharsDialog";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			lblValid1.Text = Resource.GetString("Enter the characters to be used for generating the ramp") + ":";
			lblValid2.Text = "(" + Resource.GetString("Some characters may not make it in to the ramp") + ")";

			btnOk.Text = Resource.GetString("&Ok");
			btnCancel.Text = Resource.GetString("&Cancel");
			btnDefault.Text = Resource.GetString("&Default");
		}

		private void cmbCharacters_TextChanged(object sender, System.EventArgs e) {
			btnOk.Enabled = (cmbCharacters.Text.Length > 0);
		}

		private void btnDefault_Click(object sender, System.EventArgs e) {
			cmbCharacters.Text = Variables.CurrentSelectedValidCharacters > -1 ?
				(string)Variables.DefaultValidCharacters[Variables.CurrentSelectedValidCharacters] :
				Variables.CurrentCharacters;

			cmbCharacters.Focus();
			cmbCharacters.SelectAll();
		}

		private void cmbCharacters_DropDown(object sender, System.EventArgs e) {
			int iWidth = cmbCharacters.Width;

			foreach (string Characters in cmbCharacters.Items) {
                Size size = FontFunctions.MeasureText(Characters + "  ", cmbCharacters.Font);

                if (size.Width > iWidth) {
                    iWidth = size.Width;
                }
			}

			cmbCharacters.DropDownWidth = iWidth;
		}

		/// <summary>Get and set the valid characters for the textbox</summary>
		public string Characters {
			get {
				return cmbCharacters.Text;
			}

			set {
				cmbCharacters.Text = value;
			}
		}

		/// <summary>Get and set the current font for the textbox</summary>
		public new Font Font {
			get {
				return cmbCharacters.Font;
			}

			set {
				cmbCharacters.Font = value;
				MinimumSize = new Size(MinimumSize.Width, cmbCharacters.Top + cmbCharacters.ItemHeight + 96);
			}
		}
	}
}