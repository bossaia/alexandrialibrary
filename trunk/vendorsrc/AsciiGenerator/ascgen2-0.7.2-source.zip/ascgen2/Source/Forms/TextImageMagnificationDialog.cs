//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: TextImageMagnificationDialog.cs,v 1.20 2006/09/24 11:23:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for TextImageMagnificationDialog.
	/// </summary>
	public class TextImageMagnificationDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TextBox tbxSampleText;
		private System.Windows.Forms.Label lblMagnification;
		private System.Windows.Forms.Panel pnlOutputImage;
		private System.Windows.Forms.PictureBox pbxOutputImage;
		private System.Windows.Forms.TrackBar trkMagnification;
		private System.Windows.Forms.TextBox tbxMagnification;
		private System.Windows.Forms.TabPage tabPageOutput;
		private System.Windows.Forms.TabControl tabSample;
		private System.Windows.Forms.TabPage tabPageInput;
		private System.Windows.Forms.Label lblOutputSize;
		private System.Windows.Forms.TextBox tbxOutputWidth;
		private System.Windows.Forms.TextBox tbxOutputHeight;
        private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructor
		/// </summary>
		public TextImageMagnificationDialog(Font font) {
			InitializeComponent();

			tbxSampleText.Font = font;

			UpdateUI();
			UpdateImage();

			tbxMagnification.Text = ((int)Value).ToString(Variables.Culture);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tbxSampleText = new System.Windows.Forms.TextBox();
            this.pnlOutputImage = new System.Windows.Forms.Panel();
            this.pbxOutputImage = new System.Windows.Forms.PictureBox();
            this.lblMagnification = new System.Windows.Forms.Label();
            this.tbxMagnification = new System.Windows.Forms.TextBox();
            this.trkMagnification = new System.Windows.Forms.TrackBar();
            this.tabSample = new System.Windows.Forms.TabControl();
            this.tabPageOutput = new System.Windows.Forms.TabPage();
            this.tabPageInput = new System.Windows.Forms.TabPage();
            this.lblOutputSize = new System.Windows.Forms.Label();
            this.tbxOutputWidth = new System.Windows.Forms.TextBox();
            this.tbxOutputHeight = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlOutputImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOutputImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkMagnification)).BeginInit();
            this.tabSample.SuspendLayout();
            this.tabPageOutput.SuspendLayout();
            this.tabPageInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(16, 208);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(80, 24);
            this.btnOk.TabIndex = 9;
            this.btnOk.Text = "btnOk";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(290, 208);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 24);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "btnCancel";
            // 
            // tbxSampleText
            // 
            this.tbxSampleText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbxSampleText.Location = new System.Drawing.Point(0, 0);
            this.tbxSampleText.Multiline = true;
            this.tbxSampleText.Name = "tbxSampleText";
            this.tbxSampleText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxSampleText.Size = new System.Drawing.Size(348, 90);
            this.tbxSampleText.TabIndex = 2;
            this.tbxSampleText.Text = "tbxSampleText1\r\ntbxSampleText2\r\ntbxSampleText3";
            this.tbxSampleText.WordWrap = false;
            this.tbxSampleText.TextChanged += new System.EventHandler(this.tbxSampleText_TextChanged);
            // 
            // pnlOutputImage
            // 
            this.pnlOutputImage.AutoScroll = true;
            this.pnlOutputImage.BackColor = System.Drawing.Color.White;
            this.pnlOutputImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOutputImage.Controls.Add(this.pbxOutputImage);
            this.pnlOutputImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOutputImage.Location = new System.Drawing.Point(0, 0);
            this.pnlOutputImage.Name = "pnlOutputImage";
            this.pnlOutputImage.Size = new System.Drawing.Size(348, 90);
            this.pnlOutputImage.TabIndex = 4;
            // 
            // pbxOutputImage
            // 
            this.pbxOutputImage.Location = new System.Drawing.Point(1, 2);
            this.pbxOutputImage.Name = "pbxOutputImage";
            this.pbxOutputImage.Size = new System.Drawing.Size(160, 40);
            this.pbxOutputImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbxOutputImage.TabIndex = 0;
            this.pbxOutputImage.TabStop = false;
            // 
            // lblMagnification
            // 
            this.lblMagnification.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMagnification.Location = new System.Drawing.Point(16, 176);
            this.lblMagnification.Name = "lblMagnification";
            this.lblMagnification.Size = new System.Drawing.Size(96, 20);
            this.lblMagnification.TabIndex = 6;
            this.lblMagnification.Text = "lblMagnification";
            this.lblMagnification.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbxMagnification
            // 
            this.tbxMagnification.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxMagnification.Location = new System.Drawing.Point(338, 176);
            this.tbxMagnification.MaxLength = 3;
            this.tbxMagnification.Name = "tbxMagnification";
            this.tbxMagnification.ReadOnly = true;
            this.tbxMagnification.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tbxMagnification.Size = new System.Drawing.Size(32, 20);
            this.tbxMagnification.TabIndex = 8;
            // 
            // trkMagnification
            // 
            this.trkMagnification.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.trkMagnification.AutoSize = false;
            this.trkMagnification.LargeChange = 10;
            this.trkMagnification.Location = new System.Drawing.Point(104, 173);
            this.trkMagnification.Maximum = 1000;
            this.trkMagnification.Minimum = 250;
            this.trkMagnification.Name = "trkMagnification";
            this.trkMagnification.Size = new System.Drawing.Size(234, 32);
            this.trkMagnification.TabIndex = 7;
            this.trkMagnification.TickFrequency = 50;
            this.trkMagnification.Value = 750;
            this.trkMagnification.ValueChanged += new System.EventHandler(this.trkMagnification_ValueChanged);
            // 
            // tabSample
            // 
            this.tabSample.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabSample.Controls.Add(this.tabPageOutput);
            this.tabSample.Controls.Add(this.tabPageInput);
            this.tabSample.Location = new System.Drawing.Point(16, 16);
            this.tabSample.Name = "tabSample";
            this.tabSample.SelectedIndex = 0;
            this.tabSample.Size = new System.Drawing.Size(356, 116);
            this.tabSample.TabIndex = 0;
            // 
            // tabPageOutput
            // 
            this.tabPageOutput.Controls.Add(this.pnlOutputImage);
            this.tabPageOutput.Location = new System.Drawing.Point(4, 22);
            this.tabPageOutput.Name = "tabPageOutput";
            this.tabPageOutput.Size = new System.Drawing.Size(348, 90);
            this.tabPageOutput.TabIndex = 0;
            this.tabPageOutput.Text = "tabPageOutput";
            // 
            // tabPageInput
            // 
            this.tabPageInput.Controls.Add(this.tbxSampleText);
            this.tabPageInput.Location = new System.Drawing.Point(4, 22);
            this.tabPageInput.Name = "tabPageInput";
            this.tabPageInput.Size = new System.Drawing.Size(348, 90);
            this.tabPageInput.TabIndex = 1;
            this.tabPageInput.Text = "tabPageInput";
            // 
            // lblOutputSize
            // 
            this.lblOutputSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblOutputSize.Location = new System.Drawing.Point(105, 142);
            this.lblOutputSize.Name = "lblOutputSize";
            this.lblOutputSize.Size = new System.Drawing.Size(72, 20);
            this.lblOutputSize.TabIndex = 1;
            this.lblOutputSize.Text = "lblOutputSize";
            this.lblOutputSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbxOutputWidth
            // 
            this.tbxOutputWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxOutputWidth.Location = new System.Drawing.Point(177, 142);
            this.tbxOutputWidth.Name = "tbxOutputWidth";
            this.tbxOutputWidth.ReadOnly = true;
            this.tbxOutputWidth.Size = new System.Drawing.Size(40, 20);
            this.tbxOutputWidth.TabIndex = 2;
            this.tbxOutputWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbxOutputHeight
            // 
            this.tbxOutputHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxOutputHeight.Location = new System.Drawing.Point(229, 142);
            this.tbxOutputHeight.Name = "tbxOutputHeight";
            this.tbxOutputHeight.ReadOnly = true;
            this.tbxOutputHeight.Size = new System.Drawing.Size(40, 20);
            this.tbxOutputHeight.TabIndex = 4;
            this.tbxOutputHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.Location = new System.Drawing.Point(215, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "x";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TextImageMagnificationDialog
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(386, 246);
            this.ControlBox = false;
            this.Controls.Add(this.tbxMagnification);
            this.Controls.Add(this.trkMagnification);
            this.Controls.Add(this.tbxOutputHeight);
            this.Controls.Add(this.tbxOutputWidth);
            this.Controls.Add(this.lblOutputSize);
            this.Controls.Add(this.tabSample);
            this.Controls.Add(this.lblMagnification);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(384, 232);
            this.Name = "TextImageMagnificationDialog";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "TextImageMagnificationDialog";
            this.pnlOutputImage.ResumeLayout(false);
            this.pnlOutputImage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOutputImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkMagnification)).EndInit();
            this.tabSample.ResumeLayout(false);
            this.tabPageOutput.ResumeLayout(false);
            this.tabPageInput.ResumeLayout(false);
            this.tabPageInput.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void tbxSampleText_TextChanged(object sender, System.EventArgs e) {
			_bUpdateImage = true;
			UpdateImage();
		}

		/// <summary>
		/// Create a new image for the picturebox
		/// </summary>
		private void UpdateImage() {
			if (_bUpdateImage && tbxSampleText.Lines.Length > 0) {
				using (Bitmap bmpFullSize = JMSoftware.FontFunctions.DrawText(tbxSampleText.Text, tbxSampleText.Font, TextColor, BackgroundColor)) {
					if (bmpFullSize != null) {
						float fMagnification = Value / 100f;

						Size newSize = new Size((int)(((float)bmpFullSize.Width * fMagnification) + 0.5f),
							(int)(((float)bmpFullSize.Height * fMagnification) + 0.5f));

						pbxOutputImage.Image = new Bitmap(newSize.Width, newSize.Height);

						using (ImageAttributes ia = new ImageAttributes()) {
							ia.SetColorMatrix(JMSoftware.Matrices.Grayscale());

							using (Graphics g = Graphics.FromImage(pbxOutputImage.Image)) {
								// select highest quality resize mode
								g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

								g.DrawImage(bmpFullSize, new Rectangle(0, 0, newSize.Width, newSize.Height),
									0, 0, bmpFullSize.Width, bmpFullSize.Height,
									GraphicsUnit.Pixel, ia);
							}
						}
					}
				}

				_bUpdateImage = false;

				pbxOutputImage.Refresh();
			}
		}

		private void trkMagnification_ValueChanged(object sender, System.EventArgs e) {
			_bUpdateImage = true;

			UpdateImage();
			
			tbxMagnification.Text = ((int)Value).ToString(Variables.Culture);

			UpdateOutputSize();
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {			
			this.Text = Resource.GetString("Choose the Magnification Level");

			tabPageInput.Text = Resource.GetString("Input Text Sample");
			tabPageOutput.Text = Resource.GetString("Output Image Sample");
			lblMagnification.Text = Resource.GetString("Magnification") + " (%):";
			btnOk.Text = Resource.GetString("&Ok");
			btnCancel.Text = Resource.GetString("&Cancel");
			lblOutputSize.Text = Resource.GetString("Output Size") + ":";

			string text = Resource.GetString("For The Best Effect This Text Should Be Readable");

			tbxSampleText.Lines = new string[] {	text,
													text.ToLower(Variables.Culture),
													text.ToUpper(Variables.Culture) };
		}

		private void UpdateOutputSize() {
			if (InputSize.Width > 0 && InputSize.Height > 0) {
				float ratio = (float)Value / 100f;
				_OutputSize.Width = (int)(((float)InputSize.Width * ratio) + 0.5f);
				_OutputSize.Height = (int)(((float)InputSize.Height * ratio) + 0.5f);

				tbxOutputWidth.Text = _OutputSize.Width.ToString(Variables.Culture);
				tbxOutputHeight.Text = _OutputSize.Height.ToString(Variables.Culture);

				tbxOutputWidth.Refresh();
				tbxOutputHeight.Refresh();
			}
		}

		private void cbxForceGreyscale_CheckedChanged(object sender, System.EventArgs e) {
			_bUpdateImage = true;
			UpdateImage();
		}

		#region Properties and Variables
		/// <summary>Do we need to recreate the image?</summary>
		private bool _bUpdateImage = true;

		/// <summary>
		/// Get and set the Font to be used
		/// </summary>
		public Font TextFont {
			get {
				return tbxSampleText.Font;
			}

			set {
				tbxSampleText.Font = value;
				UpdateImage();
			}
		}

		/// <summary>Get and set the zoom value (25 -> 100)</summary>
		public float Value {
			get {
				return (float)trkMagnification.Value / 10f;
			}

			set {
				trkMagnification.Value = (int)(value * 10f);
			}
		}

		private Size _InputSize = new Size(0, 0);
		/// <summary>The size of the input image</summary>
		public Size InputSize {
			get {
				return _InputSize;
			}

			set {
				_InputSize = value;
				UpdateOutputSize();
			}
		}

		private Size _OutputSize = new Size(0, 0);

		private Color _TextColor = Color.Black;
		/// <summary>Get and set the color used for the text</summary>
		public Color TextColor {
			get {
				return _TextColor;
			}

			set {
				_TextColor = tbxSampleText.ForeColor = value;
				_bUpdateImage = true;
				UpdateImage();
			}
		}

		private Color _BackgroundColor = Color.White;
		/// <summary>Get and set the color used for the background</summary>
		public Color BackgroundColor {
			get {
				return _BackgroundColor;
			}

			set {
				_BackgroundColor = tbxSampleText.BackColor = value;				
				_bUpdateImage = true;
				UpdateImage();
			}
		}

		#endregion
	}
}