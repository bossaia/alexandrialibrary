//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormBatchConvert.Designer.cs,v 1.2 2006/09/09 22:58:33 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using JMSoftware.AsciiConversion;

namespace JMSoftware.AsciiGeneratorDotNet
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    partial class FormBatchConvert : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.ListBox lbxLog;
        private System.Windows.Forms.Button btnOutputDirectory;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.FolderBrowserDialog dialogOpenDirectory;
        private System.Windows.Forms.TextBox tbxOutputDirectory;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.OpenFileDialog dialogAddFiles;
        private System.Windows.Forms.ContextMenuStrip cmenuFiles;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesAddDirectory;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesRemove;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesShowPath;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesShowExtension;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesSelectNone;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesSelectAll;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesInvertSelection;
        private System.Windows.Forms.ContextMenuStrip cmenuLog;
        private System.Windows.Forms.ToolStripMenuItem cmenuLogSaveAs;
        private System.Windows.Forms.ToolStripMenuItem cmenuLogClear;
        private System.Windows.Forms.SaveFileDialog dialogSaveLog;
        private System.Windows.Forms.FolderBrowserDialog dialogAddDirectory;
        private System.Windows.Forms.ProgressBar progressConversion;
        private System.Windows.Forms.Label lblOutputSize;
        private System.Windows.Forms.CheckBox cbxLocked;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnAddFile;
        private System.Windows.Forms.Button btnAddDirectory;
        private System.Windows.Forms.Label lblFiles;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TextBox tbxHeight;
        private JMSoftware.CustomControl.FileListbox lbxFiles;
        private System.Windows.Forms.TextBox tbxWidth;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ToolStripMenuItem cmenuFileAdd;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesRemoveAll;
        private System.Windows.Forms.ToolStripMenuItem cmenuFilesRemoveAfter;
        private System.Windows.Forms.RadioButton rbOutputAsText;
        private System.Windows.Forms.RadioButton rbOutputAsImage;
        private System.Windows.Forms.Label lblOutputAs;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.TextBox tbxPercent;
        private System.Windows.Forms.ComboBox cmbImageType;

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBatchConvert));
            this.cmenuFiles = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmenuFileAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesAddDirectory = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesRemoveAll = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesRemoveAfter = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesSelectNone = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesInvertSelection = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesShowPath = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuFilesShowExtension = new System.Windows.Forms.ToolStripMenuItem();
            this.dialogAddFiles = new System.Windows.Forms.OpenFileDialog();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxOutputDirectory = new System.Windows.Forms.TextBox();
            this.btnOutputDirectory = new System.Windows.Forms.Button();
            this.lbxLog = new System.Windows.Forms.ListBox();
            this.cmenuLog = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmenuLogClear = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuLogSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.lblOutput = new System.Windows.Forms.Label();
            this.dialogOpenDirectory = new System.Windows.Forms.FolderBrowserDialog();
            this.dialogSaveLog = new System.Windows.Forms.SaveFileDialog();
            this.dialogAddDirectory = new System.Windows.Forms.FolderBrowserDialog();
            this.progressConversion = new System.Windows.Forms.ProgressBar();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.cmbImageType = new System.Windows.Forms.ComboBox();
            this.rbOutputAsImage = new System.Windows.Forms.RadioButton();
            this.lblPercent = new System.Windows.Forms.Label();
            this.tbxPercent = new System.Windows.Forms.TextBox();
            this.cbxLocked = new System.Windows.Forms.CheckBox();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnAddFile = new System.Windows.Forms.Button();
            this.btnAddDirectory = new System.Windows.Forms.Button();
            this.lblFiles = new System.Windows.Forms.Label();
            this.btnRemove = new System.Windows.Forms.Button();
            this.tbxHeight = new System.Windows.Forms.TextBox();
            this.lbxFiles = new JMSoftware.CustomControl.FileListbox();
            this.tbxWidth = new System.Windows.Forms.TextBox();
            this.lblOutputSize = new System.Windows.Forms.Label();
            this.rbOutputAsText = new System.Windows.Forms.RadioButton();
            this.lblOutputAs = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cmenuFilesSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmenuFilesSep2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmenuFilesSep3 = new System.Windows.Forms.ToolStripSeparator();
            this.cmenuFiles.SuspendLayout();
            this.cmenuLog.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmenuFiles
            // 
            this.cmenuFiles.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmenuFileAdd,
            this.cmenuFilesAddDirectory,
            this.cmenuFilesSep1,
            this.cmenuFilesRemove,
            this.cmenuFilesRemoveAll,
            this.cmenuFilesRemoveAfter,
            this.cmenuFilesSep2,
            this.cmenuFilesSelectAll,
            this.cmenuFilesSelectNone,
            this.cmenuFilesInvertSelection,
            this.cmenuFilesSep3,
            this.cmenuFilesShowPath,
            this.cmenuFilesShowExtension});
            this.cmenuFiles.Name = "cmenuFiles";
            this.cmenuFiles.Size = new System.Drawing.Size(200, 242);
            this.cmenuFiles.Opened += new System.EventHandler(this.cmenuFiles_Popup);
            // 
            // cmenuFileAdd
            // 
            this.cmenuFileAdd.MergeIndex = 0;
            this.cmenuFileAdd.Name = "cmenuFileAdd";
            this.cmenuFileAdd.Size = new System.Drawing.Size(199, 22);
            this.cmenuFileAdd.Text = "cmenuFileAdd";
            this.cmenuFileAdd.Click += new System.EventHandler(this.cmenuFilesAdd_Click);
            // 
            // cmenuFilesAddDirectory
            // 
            this.cmenuFilesAddDirectory.MergeIndex = 1;
            this.cmenuFilesAddDirectory.Name = "cmenuFilesAddDirectory";
            this.cmenuFilesAddDirectory.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesAddDirectory.Text = "cmenuFilesAddDirectory";
            this.cmenuFilesAddDirectory.Click += new System.EventHandler(this.cmenuFilesAddDirectory_Click);
            // 
            // cmenuFilesRemove
            // 
            this.cmenuFilesRemove.MergeIndex = 3;
            this.cmenuFilesRemove.Name = "cmenuFilesRemove";
            this.cmenuFilesRemove.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesRemove.Text = "cmenuFilesRemove";
            this.cmenuFilesRemove.Click += new System.EventHandler(this.cmenuFilesRemove_Click);
            // 
            // cmenuFilesRemoveAll
            // 
            this.cmenuFilesRemoveAll.MergeIndex = 4;
            this.cmenuFilesRemoveAll.Name = "cmenuFilesRemoveAll";
            this.cmenuFilesRemoveAll.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesRemoveAll.Text = "cmenuFilesRemoveAll";
            this.cmenuFilesRemoveAll.Click += new System.EventHandler(this.cmenuFilesRemoveAll_Click);
            // 
            // cmenuFilesRemoveAfter
            // 
            this.cmenuFilesRemoveAfter.Checked = true;
            this.cmenuFilesRemoveAfter.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cmenuFilesRemoveAfter.MergeIndex = 5;
            this.cmenuFilesRemoveAfter.Name = "cmenuFilesRemoveAfter";
            this.cmenuFilesRemoveAfter.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesRemoveAfter.Text = "cmenuFilesRemoveAfter";
            this.cmenuFilesRemoveAfter.Click += new System.EventHandler(this.cmenuFilesRemoveAfter_Click);
            // 
            // cmenuFilesSelectAll
            // 
            this.cmenuFilesSelectAll.MergeIndex = 7;
            this.cmenuFilesSelectAll.Name = "cmenuFilesSelectAll";
            this.cmenuFilesSelectAll.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesSelectAll.Text = "cmenuFilesSelectAll";
            this.cmenuFilesSelectAll.Click += new System.EventHandler(this.cmenuFilesSelectAll_Click);
            // 
            // cmenuFilesSelectNone
            // 
            this.cmenuFilesSelectNone.MergeIndex = 8;
            this.cmenuFilesSelectNone.Name = "cmenuFilesSelectNone";
            this.cmenuFilesSelectNone.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesSelectNone.Text = "cmenuFilesSelectNone";
            this.cmenuFilesSelectNone.Click += new System.EventHandler(this.cmenuFilesSelectNone_Click);
            // 
            // cmenuFilesInvertSelection
            // 
            this.cmenuFilesInvertSelection.MergeIndex = 9;
            this.cmenuFilesInvertSelection.Name = "cmenuFilesInvertSelection";
            this.cmenuFilesInvertSelection.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesInvertSelection.Text = "cmenuFilesInvertSelection";
            this.cmenuFilesInvertSelection.Click += new System.EventHandler(this.cmenuFilesInvertSelection_Click);
            // 
            // cmenuFilesShowPath
            // 
            this.cmenuFilesShowPath.MergeIndex = 11;
            this.cmenuFilesShowPath.Name = "cmenuFilesShowPath";
            this.cmenuFilesShowPath.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesShowPath.Text = "cmenuFilesShowPath";
            this.cmenuFilesShowPath.Click += new System.EventHandler(this.cmenuFilesShowPath_Click);
            // 
            // cmenuFilesShowExtension
            // 
            this.cmenuFilesShowExtension.MergeIndex = 12;
            this.cmenuFilesShowExtension.Name = "cmenuFilesShowExtension";
            this.cmenuFilesShowExtension.Size = new System.Drawing.Size(199, 22);
            this.cmenuFilesShowExtension.Text = "cmenuFilesShowExtension";
            this.cmenuFilesShowExtension.Click += new System.EventHandler(this.cmenuFilesShowExtension_Click);
            // 
            // dialogAddFiles
            // 
            this.dialogAddFiles.Multiselect = true;
            // 
            // btnConvert
            // 
            this.btnConvert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnConvert.Enabled = false;
            this.btnConvert.Location = new System.Drawing.Point(12, 242);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "btnConvert";
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(203, 242);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "btnClose";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxOutputDirectory
            // 
            this.tbxOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputDirectory.Location = new System.Drawing.Point(0, 172);
            this.tbxOutputDirectory.Name = "tbxOutputDirectory";
            this.tbxOutputDirectory.Size = new System.Drawing.Size(228, 20);
            this.tbxOutputDirectory.TabIndex = 11;
            this.tbxOutputDirectory.TextChanged += new System.EventHandler(this.tbxOutputDirectory_TextChanged);
            // 
            // btnOutputDirectory
            // 
            this.btnOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOutputDirectory.Location = new System.Drawing.Point(234, 172);
            this.btnOutputDirectory.Name = "btnOutputDirectory";
            this.btnOutputDirectory.Size = new System.Drawing.Size(32, 22);
            this.btnOutputDirectory.TabIndex = 12;
            this.btnOutputDirectory.Text = "...";
            this.btnOutputDirectory.Click += new System.EventHandler(this.btnOutputDirectory_Click);
            // 
            // lbxLog
            // 
            this.lbxLog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbxLog.ContextMenuStrip = this.cmenuLog;
            this.lbxLog.Location = new System.Drawing.Point(12, 294);
            this.lbxLog.Name = "lbxLog";
            this.lbxLog.ScrollAlwaysVisible = true;
            this.lbxLog.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lbxLog.Size = new System.Drawing.Size(266, 43);
            this.lbxLog.TabIndex = 5;
            // 
            // cmenuLog
            // 
            this.cmenuLog.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmenuLogClear,
            this.cmenuLogSaveAs});
            this.cmenuLog.Name = "cmenuLog";
            this.cmenuLog.Size = new System.Drawing.Size(159, 48);
            this.cmenuLog.Opened += new System.EventHandler(this.cmenuLog_Popup);
            // 
            // cmenuLogClear
            // 
            this.cmenuLogClear.MergeIndex = 0;
            this.cmenuLogClear.Name = "cmenuLogClear";
            this.cmenuLogClear.Size = new System.Drawing.Size(158, 22);
            this.cmenuLogClear.Text = "cmenuLogClear";
            this.cmenuLogClear.Click += new System.EventHandler(this.cmenuLogClear_Click);
            // 
            // cmenuLogSaveAs
            // 
            this.cmenuLogSaveAs.MergeIndex = 1;
            this.cmenuLogSaveAs.Name = "cmenuLogSaveAs";
            this.cmenuLogSaveAs.Size = new System.Drawing.Size(158, 22);
            this.cmenuLogSaveAs.Text = "cmenuLogSaveAs";
            this.cmenuLogSaveAs.Click += new System.EventHandler(this.cmenuLogSaveAs_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOutput.Location = new System.Drawing.Point(0, 154);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(266, 15);
            this.lblOutput.TabIndex = 10;
            this.lblOutput.Text = "lblOutput";
            this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dialogSaveLog
            // 
            this.dialogSaveLog.DefaultExt = "txt";
            this.dialogSaveLog.Filter = "Plain Text|*.txt|All files|*.*";
            // 
            // dialogAddDirectory
            // 
            this.dialogAddDirectory.ShowNewFolderButton = false;
            // 
            // progressConversion
            // 
            this.progressConversion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressConversion.Location = new System.Drawing.Point(12, 271);
            this.progressConversion.Name = "progressConversion";
            this.progressConversion.Size = new System.Drawing.Size(266, 17);
            this.progressConversion.TabIndex = 4;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.Controls.Add(this.cmbImageType);
            this.pnlMain.Controls.Add(this.rbOutputAsImage);
            this.pnlMain.Controls.Add(this.lblPercent);
            this.pnlMain.Controls.Add(this.tbxPercent);
            this.pnlMain.Controls.Add(this.btnOutputDirectory);
            this.pnlMain.Controls.Add(this.cbxLocked);
            this.pnlMain.Controls.Add(this.btnSettings);
            this.pnlMain.Controls.Add(this.btnAddFile);
            this.pnlMain.Controls.Add(this.btnAddDirectory);
            this.pnlMain.Controls.Add(this.lblFiles);
            this.pnlMain.Controls.Add(this.btnRemove);
            this.pnlMain.Controls.Add(this.tbxHeight);
            this.pnlMain.Controls.Add(this.lbxFiles);
            this.pnlMain.Controls.Add(this.tbxWidth);
            this.pnlMain.Controls.Add(this.lblOutput);
            this.pnlMain.Controls.Add(this.tbxOutputDirectory);
            this.pnlMain.Controls.Add(this.lblOutputSize);
            this.pnlMain.Controls.Add(this.rbOutputAsText);
            this.pnlMain.Controls.Add(this.lblOutputAs);
            this.pnlMain.Location = new System.Drawing.Point(12, 12);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(266, 224);
            this.pnlMain.TabIndex = 0;
            // 
            // cmbImageType
            // 
            this.cmbImageType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbImageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbImageType.Enabled = false;
            this.cmbImageType.Items.AddRange(new object[] {
            "bmp",
            "gif",
            "jpg",
            "png",
            "tif"});
            this.cmbImageType.Location = new System.Drawing.Point(144, 203);
            this.cmbImageType.Name = "cmbImageType";
            this.cmbImageType.Size = new System.Drawing.Size(64, 21);
            this.cmbImageType.TabIndex = 14;
            // 
            // rbOutputAsImage
            // 
            this.rbOutputAsImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.rbOutputAsImage.Location = new System.Drawing.Point(126, 200);
            this.rbOutputAsImage.Name = "rbOutputAsImage";
            this.rbOutputAsImage.Size = new System.Drawing.Size(16, 24);
            this.rbOutputAsImage.TabIndex = 1;
            this.rbOutputAsImage.CheckedChanged += new System.EventHandler(this.rbOutputAsImage_CheckedChanged);
            // 
            // lblPercent
            // 
            this.lblPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPercent.Location = new System.Drawing.Point(250, 201);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(16, 24);
            this.lblPercent.TabIndex = 16;
            this.lblPercent.Text = "%";
            this.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbxPercent
            // 
            this.tbxPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxPercent.Enabled = false;
            this.tbxPercent.Location = new System.Drawing.Point(214, 203);
            this.tbxPercent.MaxLength = 3;
            this.tbxPercent.Name = "tbxPercent";
            this.tbxPercent.Size = new System.Drawing.Size(32, 20);
            this.tbxPercent.TabIndex = 15;
            this.tbxPercent.Text = "75";
            this.tbxPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxPercent.TextChanged += new System.EventHandler(this.tbxPercent_TextChanged);
            // 
            // cbxLocked
            // 
            this.cbxLocked.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbxLocked.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbxLocked.BackColor = System.Drawing.SystemColors.Control;
            this.cbxLocked.Checked = true;
            this.cbxLocked.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxLocked.Location = new System.Drawing.Point(112, 32);
            this.cbxLocked.Name = "cbxLocked";
            this.cbxLocked.Size = new System.Drawing.Size(18, 18);
            this.cbxLocked.TabIndex = 5;
            this.cbxLocked.TabStop = false;
            this.cbxLocked.Text = "X";
            this.cbxLocked.UseVisualStyleBackColor = false;
            this.cbxLocked.CheckedChanged += new System.EventHandler(this.cbxLocked_CheckedChanged);
            // 
            // btnSettings
            // 
            this.btnSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettings.Location = new System.Drawing.Point(191, 29);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(75, 23);
            this.btnSettings.TabIndex = 7;
            this.btnSettings.Text = "btnSettings";
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnAddFile
            // 
            this.btnAddFile.Location = new System.Drawing.Point(0, 0);
            this.btnAddFile.Name = "btnAddFile";
            this.btnAddFile.Size = new System.Drawing.Size(75, 23);
            this.btnAddFile.TabIndex = 0;
            this.btnAddFile.Text = "btnAddFile";
            this.btnAddFile.Click += new System.EventHandler(this.btnAddFile_Click);
            // 
            // btnAddDirectory
            // 
            this.btnAddDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddDirectory.Location = new System.Drawing.Point(171, 0);
            this.btnAddDirectory.Name = "btnAddDirectory";
            this.btnAddDirectory.Size = new System.Drawing.Size(95, 23);
            this.btnAddDirectory.TabIndex = 2;
            this.btnAddDirectory.Text = "btnAddDirectory";
            this.btnAddDirectory.Click += new System.EventHandler(this.btnAddDirectory_Click);
            // 
            // lblFiles
            // 
            this.lblFiles.Location = new System.Drawing.Point(0, 59);
            this.lblFiles.Name = "lblFiles";
            this.lblFiles.Size = new System.Drawing.Size(266, 16);
            this.lblFiles.TabIndex = 8;
            this.lblFiles.Text = "lblFiles";
            this.lblFiles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnRemove
            // 
            this.btnRemove.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRemove.Enabled = false;
            this.btnRemove.Location = new System.Drawing.Point(90, 0);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "btnRemove";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // tbxHeight
            // 
            this.tbxHeight.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbxHeight.BackColor = System.Drawing.SystemColors.Control;
            this.tbxHeight.Location = new System.Drawing.Point(133, 31);
            this.tbxHeight.MaxLength = 3;
            this.tbxHeight.Name = "tbxHeight";
            this.tbxHeight.Size = new System.Drawing.Size(32, 20);
            this.tbxHeight.TabIndex = 6;
            this.tbxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxHeight.TextChanged += new System.EventHandler(this.tbxHeight_TextChanged);
            // 
            // lbxFiles
            // 
            this.lbxFiles.AllowDrop = true;
            this.lbxFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbxFiles.ContextMenuStrip = this.cmenuFiles;
            this.lbxFiles.DisplayPath = false;
            this.lbxFiles.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lbxFiles.Location = new System.Drawing.Point(0, 78);
            this.lbxFiles.Name = "lbxFiles";
            this.lbxFiles.ScrollAlwaysVisible = true;
            this.lbxFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbxFiles.Size = new System.Drawing.Size(266, 69);
            this.lbxFiles.Sorted = true;
            this.lbxFiles.TabIndex = 9;
            this.lbxFiles.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbxFiles_DragDrop);
            this.lbxFiles.DragOver += new System.Windows.Forms.DragEventHandler(this.lbxFiles_DragOver);
            // 
            // tbxWidth
            // 
            this.tbxWidth.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbxWidth.Location = new System.Drawing.Point(77, 31);
            this.tbxWidth.MaxLength = 3;
            this.tbxWidth.Name = "tbxWidth";
            this.tbxWidth.Size = new System.Drawing.Size(32, 20);
            this.tbxWidth.TabIndex = 4;
            this.tbxWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxWidth.TextChanged += new System.EventHandler(this.tbxWidth_TextChanged);
            // 
            // lblOutputSize
            // 
            this.lblOutputSize.Location = new System.Drawing.Point(0, 30);
            this.lblOutputSize.Name = "lblOutputSize";
            this.lblOutputSize.Size = new System.Drawing.Size(72, 20);
            this.lblOutputSize.TabIndex = 3;
            this.lblOutputSize.Text = "lblOutputSize";
            this.lblOutputSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rbOutputAsText
            // 
            this.rbOutputAsText.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.rbOutputAsText.Checked = true;
            this.rbOutputAsText.Location = new System.Drawing.Point(64, 200);
            this.rbOutputAsText.Name = "rbOutputAsText";
            this.rbOutputAsText.Size = new System.Drawing.Size(56, 24);
            this.rbOutputAsText.TabIndex = 0;
            this.rbOutputAsText.TabStop = true;
            this.rbOutputAsText.Text = "Text";
            // 
            // lblOutputAs
            // 
            this.lblOutputAs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblOutputAs.Location = new System.Drawing.Point(0, 200);
            this.lblOutputAs.Name = "lblOutputAs";
            this.lblOutputAs.Size = new System.Drawing.Size(88, 24);
            this.lblOutputAs.TabIndex = 13;
            this.lblOutputAs.Text = "lblOutputAs";
            this.lblOutputAs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCancel.Enabled = false;
            this.btnCancel.Location = new System.Drawing.Point(108, 242);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "btnCancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cmenuFilesSep1
            // 
            this.cmenuFilesSep1.MergeIndex = 2;
            this.cmenuFilesSep1.Name = "cmenuFilesSep1";
            this.cmenuFilesSep1.Size = new System.Drawing.Size(196, 6);
            // 
            // cmenuFilesSep2
            // 
            this.cmenuFilesSep2.MergeIndex = 6;
            this.cmenuFilesSep2.Name = "cmenuFilesSep2";
            this.cmenuFilesSep2.Size = new System.Drawing.Size(196, 6);
            // 
            // cmenuFilesSep3
            // 
            this.cmenuFilesSep3.MergeIndex = 10;
            this.cmenuFilesSep3.Name = "cmenuFilesSep3";
            this.cmenuFilesSep3.Size = new System.Drawing.Size(196, 6);
            // 
            // FormBatchConvert
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(290, 352);
            this.ControlBox = false;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.progressConversion);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.lbxLog);
            this.Controls.Add(this.pnlMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(288, 360);
            this.Name = "FormBatchConvert";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormBatchConvert";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.FormBatchConvert_Closing);
            this.Load += new System.EventHandler(this.FormBatchConvert_Load);
            this.cmenuFiles.ResumeLayout(false);
            this.cmenuLog.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        private ToolStripSeparator cmenuFilesSep1;
        private ToolStripSeparator cmenuFilesSep2;
        private ToolStripSeparator cmenuFilesSep3;
        private IContainer components;
    }
}