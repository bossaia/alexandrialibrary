//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: WidgetBrightnessContrast.cs,v 1.16 2005/12/28 20:58:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using JMSoftware.AsciiGeneratorDotNet;

namespace JMSoftware.Widgets
{
	/// <summary>
	/// Widget to provide controls for adjusting Brightness/Contrast
	/// </summary>
	public class WidgetBrightnessContrast : BaseWidget
	{
		/// <summary>Definition of the delegated function (to specify the return type/parameters)</summary>
		public delegate void DelegatedFunction();

		/// <summary>Method to call when the brightness changes</summary>
		public event DelegatedFunction BrightnessChanged;

		/// <summary>Method to call when the contrast changes</summary>
		public event DelegatedFunction ContrastChanged;

		private System.Windows.Forms.TrackBar trkContrast;
		private System.Windows.Forms.TextBox tbxBrightness;
		private System.Windows.Forms.TextBox tbxContrast;
		private System.Windows.Forms.Label lblContrast;
		private System.Windows.Forms.Label lblBrightness;
		private System.Windows.Forms.TrackBar trkBrightness;

		/// <summary>
		/// Constructor
		/// </summary>
		public WidgetBrightnessContrast()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			UpdateUI();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.trkContrast = new System.Windows.Forms.TrackBar();
			this.tbxBrightness = new System.Windows.Forms.TextBox();
			this.tbxContrast = new System.Windows.Forms.TextBox();
			this.lblContrast = new System.Windows.Forms.Label();
			this.lblBrightness = new System.Windows.Forms.Label();
			this.trkBrightness = new System.Windows.Forms.TrackBar();
			((System.ComponentModel.ISupportInitialize)(this.trkContrast)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trkBrightness)).BeginInit();
			this.SuspendLayout();
			// 
			// trkContrast
			// 
			this.trkContrast.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.trkContrast.AutoSize = false;
			this.trkContrast.LargeChange = 10;
			this.trkContrast.Location = new System.Drawing.Point(-4, 65);
			this.trkContrast.Maximum = 100;
			this.trkContrast.Minimum = -100;
			this.trkContrast.Name = "trkContrast";
			this.trkContrast.Size = new System.Drawing.Size(120, 24);
			this.trkContrast.TabIndex = 17;
			this.trkContrast.TickFrequency = 10;
			this.trkContrast.Scroll += new System.EventHandler(this.trkContrast_Scroll);
			// 
			// tbxBrightness
			// 
			this.tbxBrightness.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.tbxBrightness.Location = new System.Drawing.Point(64, 4);
			this.tbxBrightness.Name = "tbxBrightness";
			this.tbxBrightness.Size = new System.Drawing.Size(40, 20);
			this.tbxBrightness.TabIndex = 13;
			this.tbxBrightness.Text = "0";
			this.tbxBrightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.tbxBrightness.TextChanged += new System.EventHandler(this.tbxBrightness_TextChanged);
			// 
			// tbxContrast
			// 
			this.tbxContrast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.tbxContrast.Location = new System.Drawing.Point(64, 48);
			this.tbxContrast.Name = "tbxContrast";
			this.tbxContrast.Size = new System.Drawing.Size(40, 20);
			this.tbxContrast.TabIndex = 16;
			this.tbxContrast.Text = "0";
			this.tbxContrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.tbxContrast.TextChanged += new System.EventHandler(this.tbxContrast_TextChanged);
			// 
			// lblContrast
			// 
			this.lblContrast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblContrast.Location = new System.Drawing.Point(4, 50);
			this.lblContrast.Name = "lblContrast";
			this.lblContrast.Size = new System.Drawing.Size(64, 16);
			this.lblContrast.TabIndex = 15;
			this.lblContrast.Text = "lblContrast";
			this.lblContrast.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblBrightness
			// 
			this.lblBrightness.Location = new System.Drawing.Point(4, 6);
			this.lblBrightness.Name = "lblBrightness";
			this.lblBrightness.Size = new System.Drawing.Size(64, 16);
			this.lblBrightness.TabIndex = 12;
			this.lblBrightness.Text = "lblBrightness";
			this.lblBrightness.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// trkBrightness
			// 
			this.trkBrightness.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.trkBrightness.AutoSize = false;
			this.trkBrightness.LargeChange = 10;
			this.trkBrightness.Location = new System.Drawing.Point(-4, 22);
			this.trkBrightness.Maximum = 150;
			this.trkBrightness.Minimum = -150;
			this.trkBrightness.Name = "trkBrightness";
			this.trkBrightness.Size = new System.Drawing.Size(120, 24);
			this.trkBrightness.TabIndex = 14;
			this.trkBrightness.TickFrequency = 15;
			this.trkBrightness.Scroll += new System.EventHandler(this.trkBrightness_Scroll);
			// 
			// WidgetBrightnessContrast
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(112, 90);
			this.Controls.Add(this.tbxContrast);
			this.Controls.Add(this.tbxBrightness);
			this.Controls.Add(this.lblContrast);
			this.Controls.Add(this.lblBrightness);
			this.Controls.Add(this.trkBrightness);
			this.Controls.Add(this.trkContrast);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MinimumSize = new System.Drawing.Size(120, 112);
			this.Name = "WidgetBrightnessContrast";
			((System.ComponentModel.ISupportInitialize)(this.trkContrast)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trkBrightness)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private bool _bBrightnessChanging;
		private bool _bContrastChanging;

		/// <summary>
		/// Update the controls with the current cultures resource strings
		/// </summary>
		public void UpdateUI() {
			lblBrightness.Text = Resource.GetString("Brightness") + ":";
			lblContrast.Text = Resource.GetString("Contrast") + ":";
		}

		private void trkBrightness_Scroll(object sender, System.EventArgs e) {
			if (!_bBrightnessChanging) {
				_bBrightnessChanging = true;

				tbxBrightness.Text = trkBrightness.Value.ToString(Variables.Culture);
				tbxBrightness.Refresh();

				_bBrightnessChanging = false;

				if (BrightnessChanged != null) BrightnessChanged();
			}
		}

		private void tbxBrightness_TextChanged(object sender, System.EventArgs e) {
			if (!_bBrightnessChanging) {
				_bBrightnessChanging = true;

				try {
					int iValue = Convert.ToInt32(tbxBrightness.Text, Variables.Culture);

					if (iValue < _MinimumBrightness) {
						iValue = _MinimumBrightness;
						tbxBrightness.Text = _MinimumBrightness.ToString(Variables.Culture);
					}
					
					if (iValue > _MaximumBrightness) {
						iValue = _MaximumBrightness;
						tbxBrightness.Text = _MaximumBrightness.ToString(Variables.Culture);
					}

					trkBrightness.Value = iValue;

					if (BrightnessChanged != null) BrightnessChanged();
				}
				catch (FormatException) {
				}
				finally {
					_bBrightnessChanging = false;
				}
			}
		}

		private void trkContrast_Scroll(object sender, System.EventArgs e) {
			if (!_bContrastChanging) {
				_bContrastChanging = true;

				tbxContrast.Text = trkContrast.Value.ToString(Variables.Culture);
				tbxContrast.Refresh();

				_bContrastChanging = false;

				if (ContrastChanged != null) ContrastChanged();
			}
		}

		private void tbxContrast_TextChanged(object sender, System.EventArgs e) {
			if (!_bContrastChanging) {
				_bContrastChanging = true;

				try {
					int iValue = Convert.ToInt32(tbxContrast.Text, Variables.Culture);

					if (iValue < _MinimumContrast) {
						iValue = _MinimumContrast;
						tbxContrast.Text = _MinimumBrightness.ToString(Variables.Culture);
					}
					
					if (iValue > _MaximumContrast) {
						iValue = _MaximumContrast;
						tbxContrast.Text = _MaximumContrast.ToString(Variables.Culture);
					}

					trkContrast.Value = iValue;

					if (ContrastChanged != null) ContrastChanged();
				}
				catch (FormatException) {
				}
				finally {
					_bContrastChanging = false;
				}
			}
		}

		/// <summary>
		/// Get and set the current Brightness
		/// </summary>
		public int Brightness {
			get {
				return trkBrightness.Value;
			}
			set {
				_bBrightnessChanging = true;
				trkBrightness.Value = value;
				tbxBrightness.Text = trkBrightness.Value.ToString(Variables.Culture);
				_bBrightnessChanging = false;
				if (BrightnessChanged != null) BrightnessChanged();
			}
		}

		/// <summary>
		/// Get and set the current Contrast
		/// </summary>
		public int Contrast {
			get {
				return trkContrast.Value;
			}
			set {
				_bContrastChanging = true;
				trkContrast.Value = value;
				tbxContrast.Text = trkContrast.Value.ToString(Variables.Culture);
				_bContrastChanging = false;
				if (ContrastChanged != null) ContrastChanged();
			}
		}

		private int _MaximumBrightness = 100;
		/// <summary>
		/// Get and set the maximum value
		/// </summary>
		public int MaximumBrightness {
			get {
				return _MaximumBrightness;
			}
			set {
				trkBrightness.Maximum = _MaximumBrightness = value;
				trkBrightness.TickFrequency = (_MaximumBrightness - _MinimumBrightness) / 20;
			}
		}

		private int _MinimumBrightness = -100;
		/// <summary>
		/// Get and set the minimum value
		/// </summary>
		public int MinimumBrightness {
			get {
				return _MinimumBrightness;
			}
			set {
				trkBrightness.Minimum = _MinimumBrightness = value;
				trkBrightness.TickFrequency = (_MaximumBrightness - _MinimumBrightness) / 20;
			}
		}

		private int _MaximumContrast = 100;
		/// <summary>
		/// Get and set the maximum value
		/// </summary>
		public int MaximumContrast {
			get {
				return _MaximumContrast;
			}
			set {
				trkContrast.Maximum = _MaximumContrast = value;
				trkContrast.TickFrequency = (_MaximumContrast - _MinimumContrast) / 20;
			}
		}

		private int _MinimumContrast = -100;
		/// <summary>
		/// Get and set the minimum value
		/// </summary>
		public int MinimumContrast {
			get {
				return _MinimumContrast;
			}
			set {
				trkContrast.Minimum = _MinimumContrast = value;
				trkContrast.TickFrequency = (_MaximumContrast - _MinimumContrast) / 20;
			}
		}
	}
}