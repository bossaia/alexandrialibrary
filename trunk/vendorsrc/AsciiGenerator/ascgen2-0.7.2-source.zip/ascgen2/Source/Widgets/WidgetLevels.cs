//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: WidgetLevels.cs,v 1.6 2006/06/12 12:59:31 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using JMSoftware.AsciiGeneratorDotNet;

namespace JMSoftware.Widgets
{
	/// <summary>
	/// Widget class to display the levels control
	/// </summary>
	public class WidgetLevels : BaseWidget
	{
		private JMSoftware.CustomControl.JMLevels jmLevels1;
		private System.Windows.Forms.ContextMenuStrip cmenuMain;
        private System.Windows.Forms.ToolStripMenuItem cmenuReset;
        private System.Windows.Forms.ToolStripMenuItem cmenuMinimum;
        private System.Windows.Forms.ToolStripMenuItem cmenuMedian;
        private System.Windows.Forms.ToolStripMenuItem cmenuMaximum;
        private ToolStripSeparator cmenuSep1;
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Constructor
		/// </summary>
		public WidgetLevels()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			UpdateUI();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>Get or set the array of values</summary>
		public int[] Array {
			get { return jmLevels1.Array; }

			set {
				jmLevels1.Array = value;
				jmLevels1.Refresh();
			}
		}

		/// <summary>
		/// Get or set the Minimum value
		/// </summary>
		public int Minimum {
			get {
				return jmLevels1.Minimum;
			}

			set {
				jmLevels1.Minimum = value;
			}
		}

		/// <summary>
		/// Get or set the Maximum value
		/// </summary>
		public int Maximum {
			get {
				return jmLevels1.Maximum;
			}

			set {
				jmLevels1.Maximum = value;
			}
		}

		/// <summary>
		/// Get or set the median value (0.0 to 1.0)
		/// </summary>
		public float Median {
			get {
				return jmLevels1.Median;
			}

			set {
				jmLevels1.Median = value;
			}
		}

		private bool _Enabled = true;
		/// <summary>
		/// Get or set whether the form is enabled
		/// </summary>
		public new bool Enabled {
			get { return _Enabled; }

			set {
				jmLevels1.Enabled = _Enabled = value;
			}
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.jmLevels1 = new JMSoftware.CustomControl.JMLevels();
            this.cmenuMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmenuReset = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuMinimum = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuMedian = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuMaximum = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmenuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // jmLevels1
            // 
            this.jmLevels1.Array = null;
            this.jmLevels1.BottomMargin = 5;
            this.jmLevels1.ContextMenuStrip = this.cmenuMain;
            this.jmLevels1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jmLevels1.Enabled = false;
            this.jmLevels1.LeftMargin = 5;
            this.jmLevels1.Location = new System.Drawing.Point(0, 0);
            this.jmLevels1.Name = "jmLevels1";
            this.jmLevels1.RightMargin = 5;
            this.jmLevels1.Size = new System.Drawing.Size(192, 94);
            this.jmLevels1.TabIndex = 0;
            this.jmLevels1.TopMargin = 5;
            this.jmLevels1.ValueChanged += new JMSoftware.CustomControl.ValueChangedEventHandler(this.jmLevels1_ValueChanged);
            // 
            // cmenuMain
            // 
            this.cmenuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmenuReset,
            this.cmenuSep1,
            this.cmenuMinimum,
            this.cmenuMedian,
            this.cmenuMaximum});
            this.cmenuMain.Name = "cmenuMain";
            this.cmenuMain.Size = new System.Drawing.Size(150, 98);
            this.cmenuMain.Opening += new System.ComponentModel.CancelEventHandler(this.cmenuMain_Opening);
            // 
            // cmenuReset
            // 
            this.cmenuReset.MergeIndex = 0;
            this.cmenuReset.Name = "cmenuReset";
            this.cmenuReset.Size = new System.Drawing.Size(149, 22);
            this.cmenuReset.Text = "cmenuReset";
            this.cmenuReset.Click += new System.EventHandler(this.cmenuReset_Click);
            // 
            // cmenuMinimum
            // 
            this.cmenuMinimum.Enabled = false;
            this.cmenuMinimum.MergeIndex = 2;
            this.cmenuMinimum.Name = "cmenuMinimum";
            this.cmenuMinimum.Size = new System.Drawing.Size(149, 22);
            this.cmenuMinimum.Text = "cmenuMinimum";
            // 
            // cmenuMedian
            // 
            this.cmenuMedian.Enabled = false;
            this.cmenuMedian.MergeIndex = 3;
            this.cmenuMedian.Name = "cmenuMedian";
            this.cmenuMedian.Size = new System.Drawing.Size(149, 22);
            this.cmenuMedian.Text = "cmenuMedian";
            // 
            // cmenuMaximum
            // 
            this.cmenuMaximum.Enabled = false;
            this.cmenuMaximum.MergeIndex = 4;
            this.cmenuMaximum.Name = "cmenuMaximum";
            this.cmenuMaximum.Size = new System.Drawing.Size(149, 22);
            this.cmenuMaximum.Text = "cmenuMaximum";
            // 
            // cmenuSep1
            // 
            this.cmenuSep1.MergeIndex = 1;
            this.cmenuSep1.Name = "cmenuSep1";
            this.cmenuSep1.Size = new System.Drawing.Size(146, 6);
            // 
            // WidgetLevels
            // 
            this.ClientSize = new System.Drawing.Size(192, 94);
            this.Controls.Add(this.jmLevels1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MinimumSize = new System.Drawing.Size(104, 72);
            this.Name = "WidgetLevels";
            this.cmenuMain.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		private void jmLevels1_ValueChanged() {
			if (ValueChanged != null) {
				ValueChanged();
			}
		}

		private void cmenuReset_Click(object sender, System.EventArgs e) {
			Minimum = 0;
			Maximum = 255;
			Median = 0.5f;

			jmLevels1.Refresh();

			if (ValueChanged != null) {
				ValueChanged();
			}
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		public void UpdateUI() {
			cmenuReset.Text = Resource.GetString("Reset");
		}

		private void UpdateContextMenu() {
			cmenuMinimum.Text = Resource.GetString("Minimum") + ": " + Minimum.ToString(Variables.Culture);
			cmenuMedian.Text = Resource.GetString("Median") + ": " + Math.Round(Median, 2).ToString(Variables.Culture);
			cmenuMaximum.Text = Resource.GetString("Maximum") + ": " + Maximum.ToString(Variables.Culture);
		}

		private void cmenuMain_Opening(object sender, CancelEventArgs e) {
			cmenuReset.Enabled = Enabled && (Minimum != 0 || Median != 0.5f || Maximum != 255);
			UpdateContextMenu();
		}

		/// <summary>Event that fires when the minimum, maximum, or median value changes</summary>
		[Browsable(true), Description("Fires when the minimum, maximum, or median value changes")]
		public event ValueChangedEventHandler ValueChanged; 

		/// <summary>Delegate for value changed events</summary>
		public delegate void ValueChangedEventHandler();
	}
}