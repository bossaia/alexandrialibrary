//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: JMSelectablePictureBox.cs,v 1.19 2006/10/03 18:22:06 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace JMSoftware.CustomControl
{
	/// <summary>
	/// JMPictureBox with added area selection function
	/// </summary>
	public class JMSelectablePictureBox : JMSoftware.CustomControl.JMPictureBox {
		/// <summary>
		/// Constructor
		/// </summary>
		public JMSelectablePictureBox() {
			SelectionFillColor = Color.LightBlue;
			SelectionBorderColor = Color.DarkBlue;
		}

		/// <summary>
		/// Handle painting the control
		/// </summary>
		/// <param name="e">Provides data for the Paint event</param>
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e) {
			base.OnPaint(e);

			if (DrawingImage) {
				if (SelectedArea.Width > 0 || SelectedArea.Height > 0) {
					Rectangle DrawRect = ConvertToPictureBoxCoordinates(_SelectedArea);

					// avoid problem caused by the DrawImage bug fix in parent's OnPaint
					if (ImageLocation.Width > Image.Width || ImageLocation.Width > Image.Width) {
						DrawRect.Offset(1, 1);
						DrawRect.Width -= 1;
						DrawRect.Height -= 1;
					}

					if (_FillSelectionRectangle)
						e.Graphics.FillRectangle(new SolidBrush(_SelectionFillColor), DrawRect);

					e.Graphics.DrawRectangle(new Pen(_SelectionBorderColor, 1), DrawRect);
                    Pen BorderPen = new Pen(_SelectionBorderColor, 1);

					if (_MovingRectangle) {
                        // Draw the "+" in the center of the selected area
                        int left = (DrawRect.Width / 2) + DrawRect.Left;
                        int top = (DrawRect.Height / 2) + DrawRect.Top;

                        e.Graphics.DrawLine(BorderPen, left - 2 - (ImageUpscaled ? 1 : 0), top, left + 2, top);
                        e.Graphics.DrawLine(BorderPen, left, top - 2 - (ImageUpscaled ? 1 : 0), left, top + 2);
                    }
                    else {
						if (SelectionLocked) {
							DrawRect.Inflate(-1, -1);
							e.Graphics.DrawRectangle(new Pen(Color.White, 1), DrawRect);
						}
						else {
							e.Graphics.FillRectangles(Brushes.White, _Modifiers);
                            e.Graphics.DrawRectangles(BorderPen, _Modifiers);
						}
					}
				}
			}
		}

		/// <summary>
		/// Take a point in the current picturebox and convert it to a point in Image
		/// </summary>
		/// <param name="p">A point on the picturebox</param>
		/// <returns>p converted to a point in Image</returns>
		private Point ConvertToImageCoordinates(Point p) {
			return ConvertToImageCoordinates(p.X, p.Y);
		}

		/// <summary>
		/// Take a point in the current picturebox and convert it to a point in Image
		/// </summary>
		/// <param name="x">The x coordinate of the point on the picturebox</param>
		/// <param name="y">The y coordinate of the point on the picturebox</param>
		/// <returns>(x, y) converted to a point in Image</returns>
		private Point ConvertToImageCoordinates(int x, int y) {
			float fXRatio = (float)Image.Width / (float)ImageLocation.Width;
			float fYRatio = (float)Image.Height / (float)ImageLocation.Height;

			return new Point((int)(((float)(x - ImageLocation.X) * fXRatio) + 0.5),
				(int)(((float)(y - ImageLocation.Y) * fYRatio) + 0.5));
		}

		/// <summary>
		/// Take a point in the current Image and convert it to a point in the picturebox
		/// </summary>
		/// <param name="p">A point on the Image</param>
		/// <returns>p converted to a point in the PictureBox</returns>
		private Point ConvertToPictureBoxCoordinates(Point p) {
			return ConvertToPictureBoxCoordinates(p.X, p.Y);
		}

		/// <summary>
		/// Take a point in the current Image and convert it to a point in the picturebox
		/// </summary>
		/// <param name="x">The x coordinate of the point on the Image</param>
		/// <param name="y">The y coordinate of the point on the Image</param>
		/// <returns>(x, y) converted to a point in the picturebox</returns>
		private Point ConvertToPictureBoxCoordinates(int x, int y) {
			float fXRatio = (float)ImageLocation.Width / (float)Image.Width;
			float fYRatio = (float)ImageLocation.Height / (float)Image.Height;

			return new Point((int)(((float)x * fXRatio) + 0.5) + ImageLocation.X,
				(int)(((float)y * fYRatio) + 0.5) + ImageLocation.Y);
		}

		/// <summary>
		/// Take a rectangle in the current Image and convert it to a rectangle in the picturebox
		/// </summary>
		/// <param name="r">A rectangle in Image</param>
		/// <returns>r converted to a Rectangle in the picturebox</returns>
		private Rectangle ConvertToPictureBoxCoordinates(Rectangle r) {
			Point start = ConvertToPictureBoxCoordinates(r.Location);
			Point end = ConvertToPictureBoxCoordinates(r.Right, r.Bottom);

			return new Rectangle(start, new Size(end.X - start.X, end.Y - start.Y));
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseDown event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e) {
			if (e.Button == MouseButtons.Left && Image != null && !SelectionLocked) {
				_Selecting = true;
				_XLocked = false;
				_YLocked = false;

				_StartPoint = new Point(e.X, e.Y);

				Point position = ConvertToImageCoordinates(_StartPoint);

				if (_Modifiers[0].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Bottom);
				}
				else if (_Modifiers[1].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Left, _SelectedArea.Bottom);
				}
				else if (_Modifiers[2].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Y);
				}
				else if (_Modifiers[3].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_Modifiers[4].Contains(_StartPoint)) {
					_XLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Left, _SelectedArea.Bottom);
				}
				else if (_Modifiers[5].Contains(_StartPoint)) {
					_XLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_Modifiers[6].Contains(_StartPoint)) {
					_YLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Y);
				}
				else if (_Modifiers[7].Contains(_StartPoint)) {
					_YLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_SelectedArea.Contains(position)) {
					_MovingRectangle = true;
					_MovingOffset = new Point(position.X - _SelectedArea.X, position.Y - _SelectedArea.Y);
					_Selecting = false;
				}
			}

			Refresh();

			base.OnMouseDown (e);
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseUp event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e) {
			if (Image != null) {
				if (_MovingRectangle) {
					_MovingRectangle = false;
				}
				else {
					_Selecting = false;

					if (_StartPoint.X == e.X && _StartPoint.Y == e.Y) {
						if (ImageLocation.Contains(_StartPoint) &&
								!_SelectedArea.Contains(ConvertToImageCoordinates(_StartPoint))) {
							SelectNothing();
						}
					}
				}
			}

			Refresh();

			base.OnMouseUp (e);
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseMove event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseMove(System.Windows.Forms.MouseEventArgs e) {
			if (Image != null) {
				Cursor = Cursors.Default;

				if (_MovingRectangle) {
					Point position = ConvertToImageCoordinates(e.X, e.Y);

					_SelectedArea.X = position.X - _MovingOffset.X;
					_SelectedArea.Y = position.Y - _MovingOffset.Y;

					if (_SelectedArea.X < 0)
						_SelectedArea.X = 0;

					if (_SelectedArea.Y < 0)
						_SelectedArea.Y = 0;

					if (_SelectedArea.Right > Image.Width)
						_SelectedArea.X = Image.Width - _SelectedArea.Width;

					if (_SelectedArea.Bottom > Image.Height)
						_SelectedArea.Y = Image.Height - _SelectedArea.Height;

					if (SelectionChanged != null)
						SelectionChanged(this, EventArgs.Empty);

					UpdateSelectionHandles();
					Refresh();
				}
				else if (_Selecting) {
					Point topleft = new Point(0, 0);
					Point bottomright = new Point(0, 0);

					if (_StartPoint.X < e.X) {
						topleft.X = _StartPoint.X;
						bottomright.X = e.X;
					}
					else {
						topleft.X = e.X;
						bottomright.X = _StartPoint.X;
					}

					if (_StartPoint.Y < e.Y) {
						topleft.Y = _StartPoint.Y;
						bottomright.Y = e.Y;
					}
					else {
						topleft.Y = e.Y;
						bottomright.Y = _StartPoint.Y;
					}

					topleft = ConvertToImageCoordinates(topleft);
					bottomright = ConvertToImageCoordinates(bottomright);

					if (topleft.X < 0)
						topleft.X = 0;

					if (topleft.Y < 0)
						topleft.Y = 0;

					if (bottomright.X < 0)
						bottomright.X = 0;

					if (bottomright.Y < 0)
						bottomright.Y = 0;

					if (topleft.X > Image.Width)
						topleft.X = Image.Width;

					if (topleft.Y > Image.Height)
						topleft.Y = Image.Height;

					if (bottomright.X > Image.Width)
						bottomright.X = Image.Width;

					if (bottomright.Y > Image.Height)
						bottomright.Y = Image.Height;

					if (_XLocked) {
						topleft.X = SelectedArea.X;
						bottomright.X = SelectedArea.Right;
					}

					if (_YLocked) {
						topleft.Y = SelectedArea.Y;
						bottomright.Y = SelectedArea.Bottom;
					}

					SelectedArea = new Rectangle(topleft, new Size(bottomright.X - topleft.X, bottomright.Y - topleft.Y));
				}
				else {	// not selecting or moving
					if (!_SelectionLocked && (_SelectedArea.Width > 0 || _SelectedArea.Height > 0)) {
						int position = -1;
						Point location = new Point(e.X, e.Y);

						for (int i = 0; i < 8; i++) {
							if (_Modifiers[i].Contains(location)) {
								position = i;
								break;
							}
						}

						switch (position) {
							case 0:
							case 3:
								Cursor = Cursors.SizeNWSE;
								break;

							case 1:
							case 2:
								Cursor = Cursors.SizeNESW;
								break;

							case 4:
							case 5:
								Cursor = Cursors.SizeNS;
								break;

							case 6:
							case 7:
								Cursor = Cursors.SizeWE;
								break;

							case -1:
							default:
								if (_SelectedArea.Contains(ConvertToImageCoordinates(location))) {
									Cursor = Cursors.Hand;
								}

								break;
						}
					}
				}
			}

			base.OnMouseMove (e);
		}

		/// <summary>
		/// Set the selected area to nothing selected
		/// </summary>
		public void SelectNothing() {
			SelectedArea = new Rectangle(0, 0, 0, 0);
			SelectionLocked = false;
		}

		/// <summary>
		/// Move the selection modifier squares into the correct positions
		/// </summary>
		private void UpdateSelectionHandles() {
			Rectangle Selected = ConvertToPictureBoxCoordinates(_SelectedArea);

			_Modifiers[0].X = Selected.X - 4;
			_Modifiers[0].Y = Selected.Y - 4;

			_Modifiers[1].X = Selected.Right - 4;
			_Modifiers[1].Y = Selected.Y - 4;

			_Modifiers[2].X = Selected.X - 4;
			_Modifiers[2].Y = Selected.Bottom - 4;

			_Modifiers[3].X = Selected.Right - 4;
			_Modifiers[3].Y = Selected.Bottom - 4;

			_Modifiers[4].X = Selected.X + ((Selected.Right - Selected.X) / 2) - 3;
			_Modifiers[4].Y = Selected.Y - 3;

			_Modifiers[5].X = Selected.X + ((Selected.Right - Selected.X) / 2) - 3;
			_Modifiers[5].Y = Selected.Bottom - 3;

			_Modifiers[6].X = Selected.X - 3;
			_Modifiers[6].Y = Selected.Y + ((Selected.Bottom - Selected.Y) / 2) - 3;

			_Modifiers[7].X = Selected.Right - 3;
			_Modifiers[7].Y = Selected.Y + ((Selected.Bottom - Selected.Y) / 2) - 3;
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.Resize event.
		/// </summary>
		/// <param name="e">An System.EventArgs that contains the event data.</param>
		protected override void OnResize(EventArgs e) {
			base.OnResize (e);

			if (Image != null)
				UpdateSelectionHandles();
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.LostFocus event.
		/// </summary>
		/// <param name="e">An System.EventArgs that contains the event data.</param>
		protected override void OnLostFocus(EventArgs e) {
			base.OnLostFocus (e);

			if (_MovingRectangle) Invalidate();

			_Selecting = false;
			_MovingRectangle = false;
		}

		#region Properties and Variables
		/// <summary>Get and set the image</summary>
		[DefaultValue(null), Category("Appearance"), Description("Image to be Displayed")]
		public new Image Image {
			get {
				return base.Image;
			}
			set {
				SelectionLocked = false;
				SelectNothing();

				base.Image = value;
			}
		}

		private Rectangle _SelectedArea;
		/// <summary>Get and set the selected area of the Image</summary>
		[Browsable(false)]
		public Rectangle SelectedArea {
			get {
				return _SelectedArea;
			}

			set {
				if (_SelectedArea != value) {
					_SelectedArea = value;

					if (SelectionChanged != null)
						SelectionChanged(this, EventArgs.Empty);

					UpdateSelectionHandles();

					Refresh();
				}
			}
		}

		private Color _SelectionFillColor;
		/// <summary>
		/// Get and set the color used for filling the selection rectangle
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("The color used to fill the selection rectangle")]
		public Color SelectionFillColor {
			get {
				return _SelectionFillColor;
			}

			set {
				if (value.A < 255) {
					_SelectionFillColor = value;
				}
				else {
					_SelectionFillColor = Color.FromArgb(128, value.R, value.G, value.B);
				}

				Refresh();
			}
		}

		private bool _FillSelectionRectangle;
		/// <summary>
		/// Should we fill the selected area with SelectionFillColor?
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("The color used to fill the selection rectangle")]
		public bool FillSelectionRectangle {
			get {
				return _FillSelectionRectangle;
			}

			set {
				_FillSelectionRectangle = value;

				Refresh();
			}
		}


		/// <summary>The point at which the left mouse button was pressed down in picturebox coordinates</summary>
		private Point _StartPoint;

		/// <summary>Are we in the middle of selecting an area of the image?</summary>
		private bool _Selecting;

		private Color _SelectionBorderColor;
		/// <summary>
		/// Get and set the color used for filling the selection rectangle
		/// </summary>
		[DefaultValue(true), Browsable(true), Category("Appearance"), Description("The color used for the selection rectangle's border")]
		public Color SelectionBorderColor {
			get {
				return _SelectionBorderColor;
			}

			set {
				_SelectionBorderColor = value;
				Refresh();
			}
		}

		/// <summary>
		/// Describes the signature of the function for the SelectionChanged event
		/// </summary>
		public delegate void SelectionChangedEventHandler(object sender, EventArgs e);

		/// <summary>
		/// Event fired when the selected area has changed
		/// </summary>
		public event SelectionChangedEventHandler SelectionChanged;

		/// <summary>Are we dragging the selection rectangle?</summary>
		private bool _MovingRectangle;

		/// <summary>Offset of the cursor postion to _SelectedArea top left corner when moving</summary>
		private Point _MovingOffset;

		/// <summary>Size and positions of the selection area modifying handles in picturebox coordinates</summary>
		private Rectangle[] _Modifiers = {new Rectangle(0, 0, 9, 9),		// Top Left
										   new Rectangle(0, 0, 9, 9),	// Top Right
										   new Rectangle(0, 0, 9, 9),	// Bottom Left
										   new Rectangle(0, 0, 9, 9),	// Bottom Right
										   new Rectangle(0, 0, 7, 7),	// Top Middle
										   new Rectangle(0, 0, 7, 7),	// Bottom Middle
										   new Rectangle(0, 0, 7, 7),	// Left Middle
										   new Rectangle(0, 0, 7, 7)};	// Right Middle

		/// <summary>Is the X dimension protected from changing?</summary>
		private bool _XLocked;

		/// <summary>Is the X dimension protected from changing?</summary>
		private bool _YLocked;

		private bool _SelectionLocked;
		/// <summary>
		/// Is the selection area locked from changing?
		/// </summary>
		public bool SelectionLocked {
			get {
				return _SelectionLocked;
			}
			set {
				_SelectionLocked = value;
				Refresh();
			}
		}

		#endregion
	}
}