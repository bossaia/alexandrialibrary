//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2005 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FileListbox.cs,v 1.2 2005/09/23 17:23:44 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace JMSoftware.CustomControl {
	/// <summary>
	/// Listbox specialized for displaying filenames
	/// </summary>
	public class FileListbox : System.Windows.Forms.ListBox {
		/// <summary>
		/// Constructor
		/// </summary>
		public FileListbox() {
			DrawMode = DrawMode.OwnerDrawFixed;
		}

		/// <summary>
		/// Raises the System.Windows.Forms.ListBox.DrawItem event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.DrawItemEventArgsthat contains the event data.</param>
		protected override void OnDrawItem(DrawItemEventArgs e) {
			e.DrawBackground();

			if (Items.Count < 1 || e.Index < 0)
				return;

			string item = Items[e.Index].ToString();

			if (System.IO.File.Exists(item)) {
				System.Text.StringBuilder builder = new System.Text.StringBuilder();

				if (DisplayPath) {
					if (Path.GetDirectoryName(item).Length > 0) {
						builder.Append(Path.GetDirectoryName(item) +
							Path.DirectorySeparatorChar.ToString());
					}
				}

				builder.Append(Path.GetFileNameWithoutExtension(item));

				if (DisplayExtension) {
					builder.Append(Path.GetExtension(item));
				}

				item = builder.ToString();
			}

			e.Graphics.DrawString(item, e.Font,
				Brushes.Black, e.Bounds, StringFormat.GenericDefault);			

			e.DrawFocusRectangle();
		}

		private bool _DisplayPath = true;
		/// <summary>
		/// Should we display any filenames in the list with their full path?
		/// </summary>
		[DefaultValue(true), Category("Behavior"), Description("Display the full path to any files in the list?")]
		public bool DisplayPath {
			get {
				return _DisplayPath;
			}

			set {
				_DisplayPath = value;
				Refresh();
			}
		}

		private bool _DisplayExtension = true;
		/// <summary>
		/// Should we display any filenames in the list with their extensions?
		/// </summary>
		[DefaultValue(true), Category("Behavior"), Description("Display the extensions for any files in the list?")]
		public bool DisplayExtension {
			get {
				return _DisplayExtension;
			}

			set {
				_DisplayExtension = value;
				Refresh();
			}
		}
	}
}